// Pay Rate Calculator — correct ADP formula
function rcCalc() {
  const biw = parseFloat(document.getElementById('rc-biwHrs')?.value) || 0;
  const rate = parseFloat(document.getElementById('rc-rate')?.value) || 0;
  if (!biw || !rate) return;

  const totalAmt = biw * rate;
  const otHrs = Math.max(0, biw - 80);
  const divisor = 80 + (otHrs * 1.5);
  const payRate = divisor > 0 ? totalAmt / divisor : 0;

  // Verification: pay_rate * 80 + pay_rate * 1.5 * otHrs = totalAmt
  const verify = payRate * 80 + payRate * 1.5 * otHrs;

  document.getElementById('rc-totalAmt').textContent = '$' + totalAmt.toFixed(2);
  document.getElementById('rc-otHrs').textContent = otHrs.toFixed(2) + ' hrs';
  document.getElementById('rc-divisor').textContent = divisor.toFixed(2);
  document.getElementById('rc-payRate').textContent = '$' + payRate.toFixed(2);
  document.getElementById('rc-verifyAmt').textContent = '$' + verify.toFixed(2);
  const match = Math.abs(verify - totalAmt) < 0.02;
  document.getElementById('rc-match').textContent = match ? '✅ MATCH' : '⚠ CHECK';
  document.getElementById('rc-match').style.color = match ? 'var(--success)' : 'var(--warn)';
}

// Open portal in new tab at specific view
function openPortal(view) {
  chrome.tabs.create({ url: chrome.runtime.getURL('tools.html') + (view ? '?v=' + view : '') });
}

// Brain AI needs the live portal's server (Gemini/Hugging Face/Stability API
// routes) — it can't run offline inside the extension like the other tools.
function openBrainAI() {
  chrome.tabs.create({ url: 'https://carecrafter-portal.vercel.app/?ext=1&v=brainai' });
}

const _dur30 = 30*24*60*60*1000;
const _dur1  = 1*24*60*60*1000;

// ── SUPABASE VIA BACKGROUND ──────────────────────────────────
async function _chk(code) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action:'checkCode', code }, r => {
      if (chrome.runtime.lastError) resolve({ ok:false, msg:'Extension error' });
      else resolve(r);
    });
  });
}

async function _mid() {
  return new Promise(r => {
    chrome.storage.local.get('_xid', d => {
      if (d._xid) return r(d._xid);
      const id = '_' + Date.now().toString(36) + Math.random().toString(36).substr(2,8);
      chrome.storage.local.set({ _xid: id }, () => r(id));
    });
  });
}

async function _activate(code, agencyName) {
  const clean = code.trim().toUpperCase();
  const isLifetime = clean === 'RADHA';
  // Offline lifetime code — never touches Supabase, so it works even if the
  // backend is unreachable. Checked entirely locally, no network call at all.
  const isOfflineLifetime = clean === 'RAMTIMSINA';
  if (isOfflineLifetime) {
    const machineId = await _mid();
    const dur = 999999 * 24 * 60 * 60 * 1000;
    const exp = Date.now() + dur;
    await new Promise(r => chrome.storage.local.set({
      _xa: true, _xe: exp, _xc: clean,
      _hha_agency: agencyName || '',
      _dur_days: 999999, _xid: machineId
    }, r));
    return { ok:true, expiry:exp, durationDays: 999999 };
  }
  // Accept CC- (30 day), CD- (1 day), or lifetime codes
  if (!isLifetime && !/^C[CD]-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(clean))
    return { ok:false, msg:'Invalid format. Use CC-XXXX-XXXX-XXXX or CD-XXXX-XXXX-XXXX' };

  const chk = await _chk(clean);
  if (!chk.ok) return chk;

  // Determine duration from prefix
  const isOneDay = clean.startsWith('CD-');
  const durationDays = isLifetime ? 999999 : (isOneDay ? 1 : 30);
  const dur = isLifetime ? 999999 * 24 * 60 * 60 * 1000 : (isOneDay ? _dur1 : _dur30);
  const machineId = await _mid();

  // Only mark as used for single-use codes (not lifetime)
  if (!isLifetime) {
    await new Promise(resolve => {
      chrome.runtime.sendMessage({
        action: 'markCodeUsed',
        id: chk.id,
        machineId,
        agencyName: agencyName || '',
        durationDays
      }, resolve);
    });
  }

  // Schedule agency data send after 5 min
  chrome.runtime.sendMessage({ action: 'scheduleAgencyCapture', codeId: chk.id });

  const exp = Date.now() + dur;
  await new Promise(r => chrome.storage.local.set({
    _xa: true, _xe: exp, _xc: clean,
    _hha_agency: agencyName || '',
    _dur_days: durationDays
  }, r));

  return { ok:true, expiry:exp, durationDays };
}

// ── INPUT FORMATTER ──────────────────────────────────────────
function _fmt(input) {
  input.addEventListener('input', () => {
    let v = input.value.toUpperCase().replace(/[^A-Z0-9]/g,'');
    // If it doesn't start with CC or CD, treat as a word code — no formatting
    if (!v.startsWith('CC') && !v.startsWith('CD')) { input.value = v; return; }
    let out = '';
    if (v.length >= 2) out = v.substring(0,2);
    if (v.length > 2) out += '-' + v.substring(2,6);
    if (v.length > 6) out += '-' + v.substring(6,10);
    if (v.length > 10) out += '-' + v.substring(10,14);
    input.value = out;
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const btn = input.id === 'codeInput'
        ? document.getElementById('activateBtn')
        : document.getElementById('renewBtn');
      btn && btn.click();
    }
  });
}

// ── TIMER HELPERS ────────────────────────────────────────────
function _remaining(expiry) {
  const ms = expiry - Date.now();
  if (ms <= 0) return null;
  return { ms, d:Math.floor(ms/86400000), h:Math.floor((ms%86400000)/3600000), m:Math.floor((ms%3600000)/60000), s:Math.floor((ms%60000)/1000) };
}

function _fmtCountdown(expiry, durDays) {
  if (durDays >= 999999) return '♾ Lifetime License';
  const t = _remaining(expiry);
  if (!t) return null;
  if (t.d > 1)  return `${t.d}d ${t.h}h remaining`;
  if (t.d === 1) return `1d ${t.h}h ${t.m}m remaining`;
  if (t.h > 0)  return `${t.h}h ${t.m}m ${t.s}s remaining`;
  return `${t.m}m ${t.s}s remaining`;
}

function _expiredSince(expiry) {
  const ms = Date.now()-expiry;
  const d=Math.floor(ms/86400000), h=Math.floor((ms%86400000)/3600000);
  return d>0 ? `Expired ${d}d ${h}h ago` : `Expired ${h}h ago`;
}

async function _state() {
  return new Promise(r => {
    chrome.storage.local.get(['_xa','_xe','_dur_days'], d =>
      r({ active:d._xa||false, expiry:d._xe||null, durDays:d._dur_days||30 }));
  });
}

// ── INIT ─────────────────────────────────────────────────────
async function init() {
  const s = await _state();
  if (!s.active||!s.expiry) { showActivation(); return; }
  if (Date.now()>s.expiry && (s.durDays||30) < 999999) {
    await new Promise(r => chrome.storage.local.set({_xa:false},r));
    showExpired(s.expiry); return;
  }
  showMain(s.expiry, s.durDays);
}

// ── ACTIVATION ───────────────────────────────────────────────
function showActivation() {
  document.getElementById('activationScreen').style.display='block';
  document.getElementById('expiredScreen').style.display='none';
  document.getElementById('mainApp').style.display='none';
  const inp=document.getElementById('codeInput');
  const agencyInp=document.getElementById('agencyInput');
  const btn=document.getElementById('activateBtn');
  const err=document.getElementById('actError');
  _fmt(inp); setTimeout(()=>inp.focus(),100);
  btn.addEventListener('click', async ()=>{
    err.textContent='';
    if (!inp.value.trim()){err.textContent='Please enter your activation code.';return;}
    btn.disabled=true; btn.textContent='CHECKING...';
    const agencyName = agencyInp ? agencyInp.value.trim() : '';
    const res=await _activate(inp.value, agencyName);
    if (res.ok){
      btn.textContent='✓ ACTIVATED!';
      setTimeout(()=>showMain(res.expiry, res.durationDays),700);
    } else {
      err.textContent=res.msg;
      btn.disabled=false; btn.textContent='ACTIVATE';
      inp.focus(); inp.select();
    }
  });
}

// ── EXPIRED ──────────────────────────────────────────────────
function showExpired(oldExpiry) {
  document.getElementById('activationScreen').style.display='none';
  document.getElementById('expiredScreen').style.display='block';
  document.getElementById('mainApp').style.display='none';
  const sinceEl=document.getElementById('expiredSince');
  if (sinceEl&&oldExpiry) sinceEl.textContent=_expiredSince(oldExpiry);
  const inp=document.getElementById('renewInput');
  const agencyInp=document.getElementById('renewAgencyInput');
  const btn=document.getElementById('renewBtn');
  const err=document.getElementById('renewError');
  _fmt(inp); setTimeout(()=>inp.focus(),100);
  btn.addEventListener('click', async ()=>{
    err.textContent='';
    if (!inp.value.trim()){err.textContent='Please enter your new code.';return;}
    btn.disabled=true; btn.textContent='CHECKING...';
    const agencyName = agencyInp ? agencyInp.value.trim() : '';
    const res=await _activate(inp.value, agencyName);
    if (res.ok){
      btn.textContent='✓ REACTIVATED!';
      setTimeout(()=>showMain(res.expiry, res.durationDays),700);
    } else {
      err.textContent=res.msg;
      btn.disabled=false; btn.textContent='REACTIVATE';
      inp.focus(); inp.select();
    }
  });
}

// ── MAIN APP ─────────────────────────────────────────────────
function showMain(expiry, durDays) {
  document.getElementById('activationScreen').style.display='none';
  document.getElementById('expiredScreen').style.display='none';
  document.getElementById('mainApp').style.display='block';

  const timerEl=document.getElementById('licenseTimer');
  const footerEl=document.getElementById('footerExpiry');

  function updateTimer() {
    if (durDays >= 999999) {
      if (timerEl){ timerEl.textContent='♾ Lifetime License'; timerEl.className='license-timer'; }
      if (footerEl){ footerEl.textContent='Lifetime • Never expires'; footerEl.style.color='var(--success)'; }
      return;
    }
    const t=_remaining(expiry);
    if (!t){chrome.storage.local.set({_xa:false},()=>showExpired(expiry));return;}
    const txt=_fmtCountdown(expiry, durDays);
    if (timerEl){
      timerEl.textContent=txt;
      timerEl.className='license-timer'+(t.d<=0?' danger':t.d<=5?' warn':'');
    }
    if (footerEl){
      footerEl.textContent=(durDays===1?'1-Day':'30-Day')+' • '+t.d+'d '+t.h+'h left';
      footerEl.style.color=t.d<=0?'var(--danger)':t.d<=5?'var(--warn)':'var(--success)';
    }
  }
  updateTimer();
  const tick=setInterval(updateTimer,1000);
  window.addEventListener('unload',()=>clearInterval(tick));
  initApp();
}

function initApp() {
  // Tabs
  document.querySelectorAll('.tab').forEach(tab=>{
    tab.addEventListener('click',()=>{
      document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c=>c.style.display='none');
      tab.classList.add('active');
      const el=document.getElementById('tab-'+tab.dataset.tab);
      if (el) el.style.display='block';
    });
  });

  // Rate calculator — attach listeners and run on load
  document.getElementById('rc-biwHrs').addEventListener('input', rcCalc);
  document.getElementById('rc-biwHrs').addEventListener('change', rcCalc);
  document.getElementById('rc-rate').addEventListener('input', rcCalc);
  document.getElementById('rc-rate').addEventListener('change', rcCalc);
  rcCalc();

  // Distance checker
  const docInput=document.getElementById('docFileInput');
  const docBar=document.getElementById('docFileBar');
  const docName=document.getElementById('docFileName');
  const docOpen=document.getElementById('docOpenFullBtn');
  const docTab=document.getElementById('docNewTabBtn');
  let storedFile=null;

  if (docInput) docInput.addEventListener('change',e=>{ if(e.target.files[0]) setDoc(e.target.files[0]); });
  function setDoc(f){
    storedFile=f;
    if(docName) docName.textContent=f.name;
    if(docBar) docBar.style.display='flex';
    if(docOpen) docOpen.disabled=false;
  }
  if(docTab) docTab.addEventListener('click',()=>{
    chrome.tabs.create({url:chrome.runtime.getURL('distance-checker.html')});
  });
  if(docOpen) docOpen.addEventListener('click',()=>{
    if (!storedFile) return;
    docOpen.disabled=true; docOpen.textContent='⏳ Opening...';
    const reader=new FileReader();
    reader.onload=e=>{
      const bytes=new Uint8Array(e.target.result);
      let bin=''; for(let i=0;i<bytes.byteLength;i++) bin+=String.fromCharCode(bytes[i]);
      chrome.storage.local.set({_df:{name:storedFile.name,data:btoa(bin)}},()=>{
        chrome.tabs.create({url:chrome.runtime.getURL('distance-checker.html?fs=1')});
        docOpen.disabled=false; docOpen.textContent='🔍 Open Full Checker';
      });
    };
    reader.readAsArrayBuffer(storedFile);
  });

  // EVV Scan
  const scanBtn=document.getElementById('scanBtn');
  if(scanBtn) scanBtn.addEventListener('click',()=>{
    chrome.tabs.query({active:true,currentWindow:true},tabs=>{
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id,{action:'scanPage'},response=>{
        const el=document.getElementById('scanResults');
        if (!el) return;
        if (chrome.runtime.lastError||!response){
          el.innerHTML='<div class="scan-item danger"><span class="scan-icon">❌</span><span class="scan-text">Navigate to HHAeXchange first.</span></div>';
          return;
        }
        const {overlaps=[],hourDiffs=[],totalVisits=0}=response.results||{};
        let html=`<div class="scan-item info"><span class="scan-icon">ℹ</span><span class="scan-text">Scanned ${totalVisits} rows</span></div>`;
        if (!overlaps.length&&!hourDiffs.length)
          html+='<div class="scan-item success"><span class="scan-icon">✓</span><span class="scan-text">No EVV issues detected</span></div>';
        overlaps.forEach(o=>{ html+=`<div class="scan-item danger"><span class="scan-icon">⚠</span><span class="scan-text"><b>${o.caregiver}</b> ${o.date}: ${o.client1} vs ${o.client2} (${Math.round(o.overlapMins)}min)</span></div>`; });
        hourDiffs.forEach(d=>{ html+=`<div class="scan-item danger"><span class="scan-icon">⏱</span><span class="scan-text"><b>${d.caregiver}</b> ${d.date}: ${d.diffMins}min diff</span></div>`; });
        el.innerHTML=html;
      });
    });
  });
}

init();
