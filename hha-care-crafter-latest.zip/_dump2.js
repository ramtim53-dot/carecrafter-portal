const XLSX = require('C:/Users/CCHC-EVV/Downloads/hha-extension-new/xlsx.min.js');
const files = [
  'C:/Users/CCHC-EVV/Downloads/9bbxxxx weeek1111.xlsx',
  'C:/Users/CCHC-EVV/Downloads/9bxxxx weekkkkk22222.xlsx'
];
files.forEach(fp => {
  console.log('\n\n========== FILE:', fp, '==========');
  const wb = XLSX.readFile(fp);
  console.log('Sheet names:', wb.SheetNames);
  wb.SheetNames.forEach(name => {
    const ws = wb.Sheets[name];
    console.log('\n--- SHEET:', name, '| ref:', ws['!ref'], '---');
    const rows = XLSX.utils.sheet_to_json(ws, {header:1, defval:'', raw:false});
    console.log('total rows:', rows.length);
    rows.slice(0, 25).forEach((r,i) => console.log(i, JSON.stringify(r.map(c=>String(c).slice(0,25)))));
  });
});
