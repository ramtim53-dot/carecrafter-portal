// Care Crafter Tools — standalone extension page
'use strict';

// ─── STATE ───────────────────────────────────────────────────────────────────
var pvW1=null,pvW2=null,pvData=[],pvFilter='all',pvSortCol='name',pvSortDir='asc';
var haFile=null,haRows=[],haTab='all',HA_RATE=22;
var ovFile=null,ovGroups={},ovData=[],ovTab='all';
var aaRows=[];

// ─── INIT ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {
  // Tab switching
  document.querySelectorAll('.tab').forEach(function(t) {
    t.addEventListener('click', function() {
      document.querySelectorAll('.tab').forEach(function(x){ x.classList.remove('on'); });
      document.querySelectorAll('.panel').forEach(function(x){ x.classList.remove('on'); });
      t.classList.add('on');
      var p = document.getElementById('panel-' + t.dataset.tab);
      if (p) p.classList.add('on');
    });
  });

  // Auto-navigate to ?v= param
  var v = new URLSearchParams(window.location.search).get('v');
  if (v) {
    var tab = document.querySelector('.tab[data-tab="' + v + '"]');
    if (tab) tab.click();
  }

  // Rate calc
  document.getElementById('rc-biwHrs').addEventListener('input', rcCalc);
  document.getElementById('rc-rate').addEventListener('input', rcCalc);
  rcCalc();

  // Payroll
  setupDrop('pv-drop1', 'pv-inp1', function(f){ pvSetFile(f,1); });
  setupDrop('pv-drop2', 'pv-inp2', function(f){ pvSetFile(f,2); });
  document.getElementById('pv-runBtn').addEventListener('click', pvProcess);
  document.getElementById('pv-resetBtn').addEventListener('click', pvReset);
  document.getElementById('pv-exportBtn').addEventListener('click', pvExport);
  document.getElementById('pv-search').addEventListener('input', pvRenderTable);
  document.querySelectorAll('[data-pvfilter]').forEach(function(b) {
    b.addEventListener('click', function() {
      pvFilter = b.dataset.pvfilter;
      document.querySelectorAll('[data-pvfilter]').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      pvRenderTable();
    });
  });

  // Hours Analysis
  setupDrop('ha-drop', 'ha-fileInp', function(f){ haSetFile(f); });
  document.getElementById('ha-analyzeBtn').addEventListener('click', haAnalyze);
  document.getElementById('ha-resetBtn').addEventListener('click', haReset);
  document.getElementById('ha-exportBtn').addEventListener('click', haExportExcel);
  document.querySelectorAll('[data-hatab]').forEach(function(b) {
    b.addEventListener('click', function() {
      haTab = b.dataset.hatab;
      document.querySelectorAll('[data-hatab]').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      haRenderTable();
    });
  });

  // Overlapping Shifts
  setupDrop('ov-drop', 'ov-fileInp', function(f){ ovSetFile(f); });
  document.getElementById('ov-analyzeBtn').addEventListener('click', ovAnalyze);
  document.getElementById('ov-resetBtn').addEventListener('click', ovReset);
  document.getElementById('ov-exportBtn').addEventListener('click', ovExportExcel);
  document.querySelectorAll('[data-ovtab]').forEach(function(b) {
    b.addEventListener('click', function() {
      ovTab = b.dataset.ovtab;
      document.querySelectorAll('[data-ovtab]').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      ovRenderTable();
    });
  });

  // Auth Analysis
  setupDrop('aa-drop', 'aa-fileInp', function(f){ aaSetFile(f); });
  document.getElementById('aa-analyzeBtn').addEventListener('click', aaAnalyze);
  document.getElementById('aa-resetBtn').addEventListener('click', aaReset);
  document.getElementById('aa-exportBtn').addEventListener('click', aaExport);
  document.getElementById('aa-search').addEventListener('input', aaFilter);
  document.querySelectorAll('[data-aafilter]').forEach(function(b) {
    b.addEventListener('click', function() {
      document.querySelectorAll('[data-aafilter]').forEach(function(x){ x.classList.remove('on'); });
      b.classList.add('on');
      aaFilter();
    });
  });

  // Distance Checker
  document.getElementById('dc-openBtn').addEventListener('click', function() {
    window.open(chrome.runtime.getURL('distance-checker.html'), '_blank');
  });

  // Letter Generator
  ['lv-type','lv-agency','lv-name','lv-addr','lv-start','lv-date','lv-emp-position','lv-client','lv-clientaddr'].forEach(function(id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('input', lvUpdate);
    if (el) el.addEventListener('change', lvUpdate);
  });
  document.getElementById('lv-sameaddr').addEventListener('change', lvUpdate);
  document.getElementById('lv-printBtn').addEventListener('click', lvPrint);
  var today = new Date().toISOString().split('T')[0];
  document.getElementById('lv-date').value = today;
  lvUpdate();

  // Quick Text
  qtRender();
});

// ─── UTIL ─────────────────────────────────────────────────────────────────────
function setupDrop(dropId, inputId, cb) {
  var drop = document.getElementById(dropId);
  var inp  = document.getElementById(inputId);
  if (!drop || !inp) return;
  drop.addEventListener('click', function(){ inp.click(); });
  inp.addEventListener('change', function(){ if(inp.files[0]) cb(inp.files[0]); });
  drop.addEventListener('dragover', function(e){ e.preventDefault(); drop.classList.add('over'); });
  drop.addEventListener('dragleave', function(){ drop.classList.remove('over'); });
  drop.addEventListener('drop', function(e){ e.preventDefault(); drop.classList.remove('over'); if(e.dataTransfer.files[0]) cb(e.dataTransfer.files[0]); });
}

function loadXLSX(cb) {
  if (window.XLSX) { cb(); return; }
  // xlsx.min.js is bundled — should already be loaded via script tag
  cb();
}

// ─── RATE CALC ────────────────────────────────────────────────────────────────
function rcCalc() {
  var biw  = parseFloat(document.getElementById('rc-biwHrs').value) || 0;
  var rate = parseFloat(document.getElementById('rc-rate').value)   || 0;
  var total = biw * rate;
  var otHrs = Math.max(0, biw - 80);
  var divisor = 80 + otHrs * 1.5;
  var payRate = divisor > 0 ? total / divisor : 0;
  var otRate  = payRate * 1.5;
  var verify  = payRate * 80 + otRate * otHrs;
  var match   = Math.abs(verify - total) < 0.02;
  var $ = function(n){ return '$' + n.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,','); };
  document.getElementById('rc-payRate').textContent    = $(payRate);
  document.getElementById('rc-totalAmt').textContent   = $(total);
  document.getElementById('rc-otHrs').textContent      = otHrs.toFixed(2) + ' hrs';
  document.getElementById('rc-otRate').textContent     = $(otRate);
  document.getElementById('rc-divisor').textContent    = divisor.toFixed(1);
  document.getElementById('rc-verifyAmt').textContent  = $(verify);
  var mEl = document.getElementById('rc-match');
  mEl.textContent = match ? '✅ MATCH' : '⚠ CHECK';
  mEl.style.color = match ? 'var(--green)' : 'var(--red)';
}

// ─── PAYROLL HOURS ────────────────────────────────────────────────────────────
function pvSetFile(f,n) {
  if (n===1){ pvW1=f; document.getElementById('pv-lbl1').textContent='✅ '+f.name; document.getElementById('pv-drop1').style.borderColor='var(--teal)'; }
  else      { pvW2=f; document.getElementById('pv-lbl2').textContent='✅ '+f.name; document.getElementById('pv-drop2').style.borderColor='var(--blue)'; }
  if (pvW1&&pvW2){ var b=document.getElementById('pv-runBtn'); b.disabled=false; b.style.opacity='1'; }
}
function pvReset() {
  pvW1=null; pvW2=null; pvData=[]; pvFilter='all';
  document.getElementById('pv-lbl1').textContent='Drop Week 1 .xlsx here or click';
  document.getElementById('pv-lbl2').textContent='Drop Week 2 .xlsx here or click';
  document.getElementById('pv-drop1').style.borderColor='';
  document.getElementById('pv-drop2').style.borderColor='';
  var b=document.getElementById('pv-runBtn'); b.disabled=true; b.style.opacity='0.35';
  ['pv-cards','pv-toolbar','pv-tableWrap'].forEach(function(id){ document.getElementById(id).style.display='none'; });
  document.getElementById('pv-exportBtn').style.display='none';
  document.getElementById('pv-status').textContent='';
  document.getElementById('pv-inp1').value=''; document.getElementById('pv-inp2').value='';
}
function pvParseHrs(v) {
  if (!v&&v!==0) return null;
  var s=String(v).trim(), m=s.match(/^(\d+):(\d{2})$/);
  if (m) return parseInt(m[1])+parseInt(m[2])/60;
  var n=parseFloat(s); return isNaN(n)?null:n;
}
function pvReadFile(file,cb) {
  var r=new FileReader();
  r.onload=function(e){ try{ var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'}); var sn=wb.SheetNames[0]; var rows=XLSX.utils.sheet_to_json(wb.Sheets[sn],{defval:'',range:15}); cb(null,rows); }catch(err){ cb(err,null); } };
  r.readAsArrayBuffer(file);
}
function pvExtract(rows) {
  var res={};
  rows.forEach(function(r){
    var keys=Object.keys(r); var name='',ssn='',vsh=null,phh=null;
    keys.forEach(function(k){ var kl=k.toLowerCase().replace(/\s+/g,''); var v=String(r[k]||'').trim();
      if(!name&&(kl.includes('caregivername')||kl==='caregivername'))name=v;
      if(!ssn&&kl==='ssn')ssn=v;
      if(vsh===null&&(kl.includes('visithour')||kl.includes('visithours')))vsh=pvParseHrs(r[k]);
      if(phh===null&&(kl.includes('payhour')||kl.includes('payhours')))phh=pvParseHrs(r[k]);
    });
    if(!name&&keys.length>0)name=String(r[keys[0]]||'').trim();
    if(!ssn&&keys.length>1)ssn=String(r[keys[1]]||'').trim();
    if(vsh===null&&keys.length>2)vsh=pvParseHrs(r[keys[2]]);
    if(phh===null&&keys.length>8)phh=pvParseHrs(r[keys[8]]);
    if(!name||name.length<2)return;
    var key=(ssn||name).replace(/\s/g,'');
    if(!res[key])res[key]={name:name,ssn:ssn,vsh:0,phh:0};
    if(vsh!==null)res[key].vsh+=vsh;
    if(phh!==null)res[key].phh+=phh;
  });
  return res;
}
function pvProcess() {
  if(!pvW1||!pvW2)return;
  document.getElementById('pv-status').textContent='⏳ Loading...';
  document.getElementById('pv-runBtn').disabled=true;
  pvReadFile(pvW1,function(e1,r1){
    if(e1){document.getElementById('pv-status').textContent='❌ Week 1: '+e1.message; document.getElementById('pv-runBtn').disabled=false; return;}
    pvReadFile(pvW2,function(e2,r2){
      if(e2){document.getElementById('pv-status').textContent='❌ Week 2: '+e2.message; document.getElementById('pv-runBtn').disabled=false; return;}
      var d1=pvExtract(r1),d2=pvExtract(r2);
      var allKeys=new Set([].concat(Object.keys(d1),Object.keys(d2)));
      pvData=[];
      allKeys.forEach(function(k){
        var w1=d1[k],w2=d2[k];
        var vsd1=w1?+(w1.vsh).toFixed(4):null,phd1=w1?+(w1.phh).toFixed(4):null;
        var vsd2=w2?+(w2.vsh).toFixed(4):null,phd2=w2?+(w2.phh).toFixed(4):null;
        var diff1=vsd1!==null&&phd1!==null?+(vsd1-phd1).toFixed(4):null;
        var diff2=vsd2!==null&&phd2!==null?+(vsd2-phd2).toFixed(4):null;
        var total=+((phd1||0)+(phd2||0)).toFixed(4);
        pvData.push({name:(w1||w2).name,ssn:(w1||w2).ssn||'',vsd1:vsd1,phd1:phd1,diff1:diff1,vsd2:vsd2,phd2:phd2,diff2:diff2,total:total,inW1:!!w1,inW2:!!w2});
      });
      document.getElementById('pv-cW1').textContent=Object.keys(d1).length;
      document.getElementById('pv-cW2').textContent=Object.keys(d2).length;
      document.getElementById('pv-cBoth').textContent=pvData.filter(function(x){return x.inW1&&x.inW2;}).length;
      document.getElementById('pv-cOne').textContent=pvData.filter(function(x){return !(x.inW1&&x.inW2);}).length;
      document.getElementById('pv-cards').style.display='grid';
      document.getElementById('pv-toolbar').style.display='flex';
      document.getElementById('pv-tableWrap').style.display='block';
      document.getElementById('pv-exportBtn').style.display='';
      document.getElementById('pv-status').textContent='✅ '+pvData.length+' caregivers';
      document.getElementById('pv-runBtn').disabled=false;
      pvRenderTable();
    });
  });
}
function pvRenderTable() {
  var q=(document.getElementById('pv-search').value||'').toLowerCase();
  var data=pvData.filter(function(r){
    if(pvFilter==='both'&&!(r.inW1&&r.inW2))return false;
    if(pvFilter==='w1only'&&!(r.inW1&&!r.inW2))return false;
    if(pvFilter==='w2only'&&!(!r.inW1&&r.inW2))return false;
    if(pvFilter==='bigdiff'&&Math.abs(r.diff1||0)<1&&Math.abs(r.diff2||0)<1)return false;
    if(q&&!r.name.toLowerCase().includes(q)&&!r.ssn.includes(q))return false;
    return true;
  });
  data.sort(function(a,b){return a.name<b.name?-1:a.name>b.name?1:0;});
  document.getElementById('pv-count').textContent=data.length+' caregivers';
  var fn=function(v,warn){
    if(v===null)return '<span style="color:var(--text3)">—</span>';
    var col='var(--text)';
    if(warn&&Math.abs(v)>=1)col=v>0?'var(--red)':'var(--green)';
    return '<span style="color:'+col+'">'+v.toFixed(2)+'</span>';
  };
  document.getElementById('pv-tbody').innerHTML=data.map(function(r){
    var badge=(!r.inW1||!r.inW2)?'<span style="font-size:9px;font-weight:700;margin-left:6px;color:var(--amber)">'+(r.inW1?'W1 ONLY':'W2 ONLY')+'</span>':'';
    return '<tr style="'+((!r.inW1||!r.inW2)?'background:rgba(245,158,11,.04)':'')+'"><td style="font-weight:600">'+r.name+badge+'</td><td style="font-family:var(--mono);font-size:11px;color:var(--text3)">'+r.ssn+'</td><td style="text-align:right;font-family:var(--mono)">'+fn(r.vsd1,false)+'</td><td style="text-align:right;font-family:var(--mono);font-weight:700;color:var(--teal)">'+fn(r.phd1,false)+'</td><td style="text-align:right;font-family:var(--mono)">'+fn(r.diff1,true)+'</td><td style="text-align:right;font-family:var(--mono)">'+fn(r.vsd2,false)+'</td><td style="text-align:right;font-family:var(--mono);font-weight:700;color:var(--blue2)">'+fn(r.phd2,false)+'</td><td style="text-align:right;font-family:var(--mono)">'+fn(r.diff2,true)+'</td><td style="text-align:right;font-family:var(--mono);font-weight:700;color:var(--green)">'+fn(r.total,false)+'</td></tr>';
  }).join('');
  var t1=data.reduce(function(s,r){return s+(r.phd1||0);},0);
  var t2=data.reduce(function(s,r){return s+(r.phd2||0);},0);
  var tA=data.reduce(function(s,r){return s+(r.total||0);},0);
  document.getElementById('pv-tfoot').innerHTML='<tr style="background:var(--bg3);font-weight:800;font-size:12px"><td colspan="3" style="padding:10px 14px;color:var(--text2)">TOTALS — '+data.length+' caregivers</td><td style="text-align:right;font-family:var(--mono);color:var(--teal);padding:10px 14px">'+t1.toFixed(2)+'</td><td></td><td></td><td style="text-align:right;font-family:var(--mono);color:var(--blue2);padding:10px 14px">'+t2.toFixed(2)+'</td><td></td><td style="text-align:right;font-family:var(--mono);color:var(--green);padding:10px 14px">'+tA.toFixed(2)+'</td></tr>';
}
function pvExport() {
  var hdr=['Caregiver Name','SSN','W1 VSD','W1 PHD','W1 DIFF','W2 VSD','W2 PHD','W2 DIFF','Grand Total PHD'];
  var rows=pvData.map(function(r){return[r.name,r.ssn,r.vsd1!=null?r.vsd1.toFixed(2):'',r.phd1!=null?r.phd1.toFixed(2):'',r.diff1!=null?r.diff1.toFixed(2):'',r.vsd2!=null?r.vsd2.toFixed(2):'',r.phd2!=null?r.phd2.toFixed(2):'',r.diff2!=null?r.diff2.toFixed(2):'',r.total.toFixed(2)];});
  var csv=[hdr].concat(rows).map(function(r){return r.map(function(v){return'"'+v+'"';}).join(',');}).join('\n');
  var a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download='payroll-'+new Date().toISOString().slice(0,10)+'.csv'; a.click();
}

// ─── HOURS ANALYSIS ───────────────────────────────────────────────────────────
function haSetFile(f) {
  haFile=f;
  document.getElementById('ha-fileName').textContent=f.name;
  document.getElementById('ha-fileBar').style.display='flex';
}
function haToMins(s) {
  if(!s||s.toString().trim()===''||s.toString().trim()==='00:00')return 0;
  var str=s.toString().trim(), neg=str.startsWith('-');
  str=str.replace(/[+-]/g,'').trim();
  var p=str.split(':'); if(p.length<2)return 0;
  return (neg?-1:1)*(parseInt(p[0])*60+parseInt(p[1]||0));
}
function haFmtHrs(mins) {
  if(mins===0)return '0:00';
  var abs=Math.abs(mins), h=Math.floor(abs/60), m=abs%60;
  return (mins<0?'-':'')+h+':'+(m<10?'0':'')+m;
}
function haAnalyze() {
  if(!haFile)return;
  document.getElementById('ha-loading').style.display='block';
  document.getElementById('ha-uploadWrap').style.display='none';
  var reader=new FileReader();
  reader.onload=function(e){
    try{
      var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});
      var sn=wb.SheetNames.find(function(n){return n==='Detail Data';})||wb.SheetNames.find(function(n){return /detail/i.test(n);})||wb.SheetNames[wb.SheetNames.length-1];
      var rows=XLSX.utils.sheet_to_json(wb.Sheets[sn],{defval:''});
      haRows=rows.map(function(r){
        var raw=(r['Member']||'').toString();
        var member=raw.split('\n')[0].trim();
        var admId=(raw.match(/\(([^)]+)\)/)||['',''])[1];
        return{member:member,admId:admId,mco:(r['MCO']||'').trim(),coord:(r['Coordinator']||'').trim(),period:(r['Weekly Period']||'').trim(),
          auth:haToMins(r['Auth. Hours']),sched:haToMins(r['Scheduled Hours']),conf:haToMins(r['Confirmed Hours']),bill:haToMins(r['Billable Hours']),
          unbilled:Math.max(0,haToMins(r['Auth. Hours'])-haToMins(r['Billable Hours'])),
          missed:Math.max(0,haToMins(r['Scheduled Hours'])-haToMins(r['Confirmed Hours']))};
      }).filter(function(r){return r.member&&r.auth>0;});
      haRenderDashboard();
    }catch(err){
      document.getElementById('ha-loading').style.display='none';
      document.getElementById('ha-uploadWrap').style.display='block';
      alert('Error: '+err.message);
    }
  };
  reader.readAsArrayBuffer(haFile);
}
function haRenderDashboard() {
  document.getElementById('ha-loading').style.display='none';
  document.getElementById('ha-dashboard').style.display='block';
  var totAuth=0,totSched=0,totConf=0,totBill=0,totUnbill=0,totMissed=0;
  haRows.forEach(function(r){totAuth+=r.auth;totSched+=r.sched;totConf+=r.conf;totBill+=r.bill;totUnbill+=r.unbilled;totMissed+=r.missed;});
  var unbilledDollars=Math.round((totUnbill/60)*HA_RATE);
  var missedDollars=Math.round((totMissed/60)*HA_RATE);
  var fh=function(m){var h=Math.floor(m/60),mn=m%60;return h+':'+(mn<10?'0':'')+mn;};
  var cards=[
    {label:'Authorized',  val:fh(totAuth),   color:'var(--blue2)', sub:'Total approved'},
    {label:'Scheduled',   val:fh(totSched),  color:'var(--text)',  sub:'Visits scheduled'},
    {label:'Confirmed',   val:fh(totConf),   color:'var(--green)', sub:'EVV confirmed'},
    {label:'Billed',      val:fh(totBill),   color:'var(--teal)',  sub:'Submitted'},
    {label:'💰 Unbilled', val:fh(totUnbill), color:'var(--red)',   sub:'~$'+unbilledDollars.toLocaleString()+' uncollected'},
    {label:'⚠ Missed',   val:fh(totMissed), color:'var(--amber)', sub:'~$'+missedDollars.toLocaleString()+' at risk'}
  ];
  document.getElementById('ha-summaryGrid').innerHTML=cards.map(function(c){
    return '<div class="card"><div style="font-size:10px;color:var(--text3);font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px">'+c.label+'</div><div style="font-size:24px;font-weight:800;color:'+c.color+';line-height:1">'+c.val+'</div><div style="font-size:11px;color:var(--text3);margin-top:4px">'+c.sub+'</div></div>';
  }).join('');
  var zeroBill=haRows.filter(function(r){return r.bill===0&&r.auth>0;}).sort(function(a,b){return b.auth-a.auth;});
  if(zeroBill.length>0){
    document.getElementById('ha-zeroBillSection').style.display='block';
    document.getElementById('ha-zeroBillList').innerHTML=zeroBill.slice(0,10).map(function(r){
      var rev=Math.round((r.auth/60)*HA_RATE);
      return '<div style="background:var(--bg3);border-radius:8px;padding:10px 12px;display:flex;justify-content:space-between;align-items:center"><div><div style="font-weight:700;font-size:13px">'+r.member+'</div><div style="font-size:11px;color:var(--text3)">'+r.admId+' · '+r.mco+'</div></div><div style="text-align:right"><div style="font-size:14px;font-weight:800;color:var(--red)">'+fh(r.auth)+' hrs</div><div style="font-size:11px;color:var(--amber)">~$'+rev+' uncollected</div></div></div>';
    }).join('');
  }
  haRenderTable();
}
function haRenderTable() {
  var rows=haRows.slice();
  if(haTab==='unbilled')rows=rows.filter(function(r){return r.unbilled>0;}).sort(function(a,b){return b.unbilled-a.unbilled;});
  else if(haTab==='missed')rows=rows.filter(function(r){return r.missed>60;}).sort(function(a,b){return b.missed-a.missed;});
  else rows.sort(function(a,b){return b.unbilled-a.unbilled;});
  document.getElementById('ha-tabCount').textContent=rows.length+' clients';
  var fh=function(m){var h=Math.floor(m/60),mn=m%60;return h+':'+(mn<10?'0':'')+mn;};
  document.getElementById('ha-tbody').innerHTML=rows.map(function(r){
    var uc=r.unbilled>120?'var(--red)':r.unbilled>30?'var(--amber)':'var(--text3)';
    var mc=r.missed>120?'var(--red)':r.missed>60?'var(--amber)':'var(--text3)';
    var rev=r.unbilled>0?'~$'+Math.round((r.unbilled/60)*HA_RATE).toLocaleString():'—';
    var zb=r.bill===0?'<span style="background:rgba(239,68,68,.15);color:var(--red);border-radius:3px;padding:1px 5px;font-size:9px;font-weight:800;margin-left:4px">$0 BILLED</span>':'';
    return '<tr><td><div style="font-weight:600;font-size:13px">'+r.member+zb+'</div><div style="font-size:11px;color:var(--text3)">'+r.admId+' · '+r.coord+'</div></td><td style="font-size:12px;color:var(--text2)">'+r.mco.replace('UPMC LTSS (','').replace(')','')+'</td><td style="text-align:center">'+fh(r.auth)+'</td><td style="text-align:center">'+fh(r.sched)+'</td><td style="text-align:center">'+fh(r.conf)+'</td><td style="text-align:center">'+fh(r.bill)+'</td><td style="text-align:center;font-weight:'+(r.unbilled>60?'700':'400')+';color:'+uc+'">'+fh(r.unbilled)+'</td><td style="text-align:center;color:'+mc+'">'+fh(r.missed)+'</td><td style="text-align:center;color:var(--green);font-weight:700">'+rev+'</td></tr>';
  }).join('');
}
function haReset() {
  haFile=null; haRows=[];
  document.getElementById('ha-uploadWrap').style.display='block';
  document.getElementById('ha-dashboard').style.display='none';
  document.getElementById('ha-fileBar').style.display='none';
  document.getElementById('ha-zeroBillSection').style.display='none';
  document.getElementById('ha-fileName').textContent='';
  document.getElementById('ha-fileInp').value='';
}
function haExportExcel() {
  if(!haRows.length)return;
  var ws=[['Member','ID','MCO','Coordinator','Period','Auth Hrs','Sched Hrs','Confirmed','Billed','Unbilled','Missed']];
  var fh=function(m){var h=Math.floor(m/60),mn=m%60;return h+':'+(mn<10?'0':'')+mn;};
  haRows.forEach(function(r){ws.push([r.member,r.admId,r.mco,r.coord,r.period,fh(r.auth),fh(r.sched),fh(r.conf),fh(r.bill),fh(r.unbilled),fh(r.missed)]);});
  var wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(ws),'Hours Analysis');
  XLSX.writeFile(wb,'hours-analysis-'+new Date().toISOString().slice(0,10)+'.xlsx');
}

// ─── OVERLAPPING SHIFTS ───────────────────────────────────────────────────────
function ovSetFile(f) {
  ovFile=f;
  document.getElementById('ov-fileName').textContent=f.name;
  document.getElementById('ov-fileBar').style.display='flex';
}
function ovAnalyze() {
  if(!ovFile)return;
  document.getElementById('ov-loading').style.display='block';
  document.getElementById('ov-uploadWrap').style.display='none';
  document.getElementById('ov-dashboard').style.display='none';
  var reader=new FileReader();
  reader.onload=function(e){
    try{
      var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});
      var raw=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1,defval:''});
      var hdrIdx=-1;
      for(var i=0;i<raw.length;i++){if(raw[i].join('|').includes('Caregiver Name')&&raw[i].join('|').includes('Patient Name')){hdrIdx=i;break;}}
      if(hdrIdx<0)throw new Error('Could not find header row');
      var headers=raw[hdrIdx], data=[];
      for(var j=hdrIdx+1;j<raw.length;j++){
        var r=raw[j]; if(!r[3])continue;
        var obj={}; headers.forEach(function(h,k){if(h&&h.toString().trim())obj[h.toString().trim()]=(r[k]||'').toString().trim();});
        if(obj['Visit Date']&&obj['Caregiver Name'])data.push(obj);
      }
      ovData=data; ovGroups={};
      data.forEach(function(r){var n=r['Overlap']||'?';if(!ovGroups[n])ovGroups[n]=[];ovGroups[n].push(r);});
      Object.keys(ovGroups).forEach(function(k){if(!ovIsRealOverlap(ovGroups[k]))delete ovGroups[k];});
      ovRenderDashboard();
    }catch(err){document.getElementById('ov-loading').style.display='none';document.getElementById('ov-uploadWrap').style.display='block';alert('Error: '+err.message);}
  };
  reader.readAsArrayBuffer(ovFile);
}
function ovParseVTime(field) {
  if(!field)return null;
  var s=field.toString().split('V:'); if(s.length<2)return null;
  var part=s[s.length-1].replace(/[^0-9\-]/g,' ').trim();
  var nums=part.match(/^(\d{3,4})[^0-9]+(\d{3,4})/); if(!nums)return null;
  function toM(t){var p=t.padStart(4,'0');return parseInt(p.slice(0,2))*60+parseInt(p.slice(2));}
  return{s:toM(nums[1]),e:toM(nums[2])};
}
function ovOverlapMins(g) {
  if(!g||g.length<2)return null;
  var t1=ovParseVTime(g[0]['Overlapping Visits']),t2=ovParseVTime(g[1]['Overlapping Visits']);
  if(!t1||!t2)return null;
  var e1=t1.e<t1.s?t1.e+1440:t1.e, e2=t2.e<t2.s?t2.e+1440:t2.e;
  return Math.max(0,Math.min(e1,e2)-Math.max(t1.s,t2.s));
}
function ovIsRealOverlap(g){var m=ovOverlapMins(g);return m===null||m>=5;}
function ovFmtOverlap(mins){if(mins===null||mins===undefined||mins<=0)return '—';if(mins<60)return mins+' min';var h=Math.floor(mins/60),m=mins%60;return h+'h'+(m>0?' '+m+'m':'');}
function ovRenderDashboard() {
  document.getElementById('ov-loading').style.display='none';
  document.getElementById('ov-dashboard').style.display='block';
  var totalGroups=Object.keys(ovGroups).length;
  var billedGroups=Object.values(ovGroups).filter(function(g){return g.some(function(r){return r['Billed']&&r['Billed'].toUpperCase()==='YES';});});
  var cgs=new Set(),pts=new Set();
  ovData.forEach(function(r){if(r['Caregiver Name'])cgs.add(r['Caregiver Name']);if(r['Patient Name'])pts.add(r['Patient Name']);});
  var cards=[
    {label:'Total Overlaps',      val:totalGroups,         color:'var(--text)',  sub:'Incidents found'},
    {label:'🚨 Already Billed',   val:billedGroups.length, color:'var(--red)',   sub:'Must correct NOW'},
    {label:'Not Yet Billed',      val:totalGroups-billedGroups.length, color:'var(--amber)', sub:'Do not bill'},
    {label:'Caregivers Involved', val:cgs.size,            color:'var(--blue2)', sub:'Unique DCWs'},
    {label:'Patients Affected',   val:pts.size,            color:'var(--teal)',  sub:'Unique clients'}
  ];
  document.getElementById('ov-summaryGrid').innerHTML=cards.map(function(c){
    return '<div class="card"><div style="font-size:10px;color:var(--text3);font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:6px">'+c.label+'</div><div class="card-num" style="color:'+c.color+'">'+c.val+'</div><div style="font-size:11px;color:var(--text3);margin-top:4px">'+c.sub+'</div></div>';
  }).join('');
  if(billedGroups.length>0){
    document.getElementById('ov-billedAlert').style.display='block';
    var byPt={};
    billedGroups.forEach(function(g){var k=(g[0]['Patient Name']||'?')+'||'+(g[0]['Admission ID']||'');if(!byPt[k])byPt[k]={name:g[0]['Patient Name'],count:0,pairs:[]};byPt[k].count++;if(g.length>=2){var pair=g[0]['Caregiver Name']+' & '+g[1]['Caregiver Name'];if(!byPt[k].pairs.includes(pair))byPt[k].pairs.push(pair);}});
    document.getElementById('ov-billedList').innerHTML=Object.values(byPt).sort(function(a,b){return b.count-a.count;}).map(function(x){return '<div style="background:var(--bg3);border-radius:8px;padding:10px 12px"><div style="font-weight:700;font-size:13px">'+x.name+'</div><div style="font-size:11px;color:var(--red);font-weight:700">'+x.count+' billed overlaps</div><div style="font-size:10px;color:var(--text3);margin-top:3px">'+x.pairs.slice(0,2).join(' · ')+'</div></div>';}).join('');
  }
  ovRenderTable();
}
function ovRenderTable() {
  var th='padding:10px 12px;text-align:left;font-size:10px;color:var(--text3);font-weight:700;letter-spacing:1px;text-transform:uppercase';
  var thead=document.getElementById('ov-thead'), tbody=document.getElementById('ov-tbody');
  if(ovTab==='patients'){
    var ptData={};
    Object.values(ovGroups).forEach(function(g){var k=(g[0]['Patient Name']||'?')+'||'+(g[0]['Admission ID']||'');if(!ptData[k])ptData[k]={patient:g[0]['Patient Name'],admId:g[0]['Admission ID'],incidents:[],billed:0,totalMins:0,pairs:[]};var d=ptData[k];var mins=ovOverlapMins(g);if(mins!==null)d.totalMins+=mins;var bil=g.some(function(r){return r['Billed']&&r['Billed'].toUpperCase()==='YES';});if(bil)d.billed++;d.incidents.push({date:g[0]['Visit Date']||'',cg1:g[0]?g[0]['Caregiver Name']:'',cg2:g[1]?g[1]['Caregiver Name']:'',mins:mins,billed:bil});var pair=g.length>=2?g[0]['Caregiver Name']+' & '+g[1]['Caregiver Name']:'';if(pair&&!d.pairs.includes(pair))d.pairs.push(pair);});
    var rows=Object.values(ptData).sort(function(a,b){return b.incidents.length-a.incidents.length;});
    document.getElementById('ov-tabCount').textContent=rows.length+' patients';
    thead.innerHTML='<tr style="background:var(--bg3)"><th style="'+th+'">Patient</th><th style="'+th+';text-align:center">Overlaps</th><th style="'+th+';text-align:center">🚨 Billed</th><th style="'+th+'">Dates &amp; Duration</th><th style="'+th+';text-align:center">⏱ Total</th><th style="'+th+'">CG Pairs</th></tr>';
    tbody.innerHTML=rows.map(function(r){
      var dates=r.incidents.map(function(inc){return '<div style="font-size:11px;white-space:nowrap">'+inc.date+(inc.mins!==null?'<span style="color:var(--teal);margin-left:4px;font-size:10px;font-weight:700">'+ovFmtOverlap(inc.mins)+'</span>':'')+(inc.billed?'<span style="background:rgba(239,68,68,.15);color:var(--red);border-radius:3px;padding:1px 4px;font-size:9px;font-weight:800;margin-left:4px">BILLED</span>':'')+'</div>';}).join('');
      return '<tr><td><div style="font-weight:700">'+r.patient+'</div><div style="font-size:11px;color:var(--text3)">'+r.admId+'</div></td><td style="text-align:center;font-weight:700;color:var(--amber)">'+r.incidents.length+'</td><td style="text-align:center;font-weight:700;color:'+(r.billed>0?'var(--red)':'var(--text3)')+'">'+r.billed+'</td><td>'+dates+'</td><td style="text-align:center">'+(r.totalMins>0?'<span style="background:rgba(168,85,247,.15);color:#a855f7;border-radius:4px;padding:3px 8px;font-size:12px;font-weight:700">'+ovFmtOverlap(r.totalMins)+'</span>':'—')+'</td><td style="font-size:10px;color:var(--text2)">'+r.pairs.slice(0,3).join('<br>')+'</td></tr>';
    }).join('');
  } else if(ovTab==='pairs'){
    var pairData={};
    Object.values(ovGroups).forEach(function(g){if(g.length<2)return;var names=g.map(function(r){return r['Caregiver Name'];}).sort();var k=names.join(' & ');if(!pairData[k])pairData[k]={pair:k,cg1:names[0],cg2:names[1],count:0,billed:0,patients:[],dates:[],totalMins:0};var d=pairData[k];d.count++;var pm=ovOverlapMins(g);if(pm!==null)d.totalMins+=pm;if(g.some(function(r){return r['Billed']&&r['Billed'].toUpperCase()==='YES';}))d.billed++;var pt=g[0]['Patient Name'];if(!d.patients.includes(pt))d.patients.push(pt);var dt=g[0]['Visit Date'];if(!d.dates.includes(dt))d.dates.push(dt);});
    var rows=Object.values(pairData).sort(function(a,b){return b.count-a.count;});
    document.getElementById('ov-tabCount').textContent=rows.length+' pairs';
    thead.innerHTML='<tr style="background:var(--bg3)"><th style="'+th+'">CG 1</th><th style="'+th+'">CG 2</th><th style="'+th+';text-align:center">Count</th><th style="'+th+';text-align:center">⏱ Total</th><th style="'+th+';text-align:center">🚨 Billed</th><th style="'+th+'">Patients</th><th style="'+th+'">Dates</th></tr>';
    tbody.innerHTML=rows.map(function(r){
      var sd=r.dates.slice().sort(); var dateRange=sd.length===1?sd[0]:sd[0]+' – '+sd[sd.length-1];
      return '<tr><td style="font-weight:600">'+r.cg1+'</td><td style="font-weight:600">'+r.cg2+'</td><td style="text-align:center;font-weight:700;color:var(--amber)">'+r.count+'</td><td style="text-align:center"><span style="background:rgba(239,68,68,.1);color:var(--red);border-radius:4px;padding:2px 8px;font-size:12px;font-weight:700">'+ovFmtOverlap(r.totalMins)+'</span></td><td style="text-align:center;font-weight:'+(r.billed>0?'700':'400')+';color:'+(r.billed>0?'var(--red)':'var(--text3)')+'">'+r.billed+'</td><td style="font-size:10px;color:var(--text2)">'+r.patients.slice(0,3).join('<br>')+'</td><td style="font-size:11px;color:var(--text2)">'+dateRange+'</td></tr>';
    }).join('');
  } else {
    var rows=Object.entries(ovGroups).sort(function(a,b){return a[0]-b[0];});
    document.getElementById('ov-tabCount').textContent=rows.length+' incidents';
    thead.innerHTML='<tr style="background:var(--bg3)"><th style="'+th+'">#</th><th style="'+th+'">Date</th><th style="'+th+'">Patient</th><th style="'+th+'">CG 1</th><th style="'+th+'">CG 2</th><th style="'+th+';text-align:center">⏱ Overlap</th><th style="'+th+';text-align:center">Billed</th></tr>';
    tbody.innerHTML=rows.map(function(e){
      var n=e[0],g=e[1];
      var billed=g.some(function(r){return r['Billed']&&r['Billed'].toUpperCase()==='YES';});
      return '<tr><td style="font-size:11px;color:var(--text3)">'+n+'</td><td style="font-size:12px;color:var(--text2)">'+((g[0]&&g[0]['Visit Date'])||'')+'</td><td style="font-weight:600">'+((g[0]&&g[0]['Patient Name'])||'')+'</td><td style="font-size:12px">'+(g[0]?g[0]['Caregiver Name']:'?')+'</td><td style="font-size:12px">'+(g[1]?g[1]['Caregiver Name']:'?')+'</td><td style="text-align:center"><span style="background:rgba(239,68,68,.1);color:var(--red);border-radius:4px;padding:2px 8px;font-size:11px;font-weight:700">'+ovFmtOverlap(ovOverlapMins(g))+'</span></td><td style="text-align:center">'+(billed?'<span style="background:rgba(239,68,68,.15);color:var(--red);border-radius:4px;padding:2px 8px;font-size:10px;font-weight:800">BILLED</span>':'<span style="color:var(--text3);font-size:11px">No</span>')+'</td></tr>';
    }).join('');
  }
}
function ovReset() {
  ovFile=null; ovGroups={}; ovData=[];
  document.getElementById('ov-uploadWrap').style.display='block';
  document.getElementById('ov-dashboard').style.display='none';
  document.getElementById('ov-fileBar').style.display='none';
  document.getElementById('ov-billedAlert').style.display='none';
  document.getElementById('ov-fileInp').value='';
}
function ovExportExcel() {
  if(!Object.keys(ovGroups).length)return;
  var ws=[['#','Date','Patient','Admission ID','CG 1','CG 2','Overlap Time','Billed']];
  Object.entries(ovGroups).sort(function(a,b){return a[0]-b[0];}).forEach(function(e){
    var n=e[0],g=e[1];
    var billed=g.some(function(r){return r['Billed']&&r['Billed'].toUpperCase()==='YES';});
    ws.push([n,(g[0]&&g[0]['Visit Date'])||'',(g[0]&&g[0]['Patient Name'])||'',(g[0]&&g[0]['Admission ID'])||'',g[0]?g[0]['Caregiver Name']:'?',g[1]?g[1]['Caregiver Name']:'?',ovFmtOverlap(ovOverlapMins(g)),billed?'YES':'NO']);
  });
  var wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(ws),'Overlapping Shifts');
  XLSX.writeFile(wb,'overlapping-shifts-'+new Date().toISOString().slice(0,10)+'.xlsx');
}

// ─── AUTH ANALYSIS ────────────────────────────────────────────────────────────
function aaSetFile(f) {
  aaRows=[];
  document.getElementById('aa-fileName').textContent=f.name;
  document.getElementById('aa-fileBar').style.display='flex';
  var reader=new FileReader();
  reader.onload=function(e){
    try{
      var wb=XLSX.read(new Uint8Array(e.target.result),{type:'array'});
      var sheet=wb.Sheets['Detail Data']||wb.Sheets[wb.SheetNames[0]];
      var data=XLSX.utils.sheet_to_json(sheet,{header:1});
      var hdrIdx=-1;
      for(var i=0;i<Math.min(data.length,10);i++){if(data[i]&&data[i].some(function(c){return typeof c==='string'&&c.includes('Auth');})){hdrIdx=i;break;}}
      if(hdrIdx<0){alert('Could not find header row.');return;}
      var hdrs=data[hdrIdx].map(function(h){return(h||'').toString().trim();});
      var ci={
        member:hdrs.findIndex(function(h){return h.toLowerCase().includes('member')&&!h.toLowerCase().includes('phone');}),
        period:hdrs.findIndex(function(h){return h.toLowerCase().includes('weekly period');}),
        authHrs:hdrs.findIndex(function(h){return h.toLowerCase().includes('auth')&&h.toLowerCase().includes('hour')&&!h.toLowerCase().includes('bill');}),
        schedHrs:hdrs.findIndex(function(h){return h.toLowerCase().includes('scheduled hours');}),
        authSched:hdrs.findIndex(function(h){return h.toLowerCase().includes('auth')&&h.toLowerCase().includes('sch')&&h.toLowerCase().includes('discrepancy');}),
        confHrs:hdrs.findIndex(function(h){return h.toLowerCase().includes('confirmed hours');}),
      };
      aaRows=[];
      for(var r=hdrIdx+1;r<data.length;r++){
        var row=data[r]; if(!row||!row[ci.member])continue;
        var mem=(row[ci.member]||'').toString().trim(); if(!mem)continue;
        aaRows.push({member:mem,period:ci.period>=0?(row[ci.period]||''):'',authHrs:ci.authHrs>=0?(row[ci.authHrs]||'0:00'):'0:00',schedHrs:ci.schedHrs>=0?(row[ci.schedHrs]||'0:00'):'0:00',confHrs:ci.confHrs>=0?(row[ci.confHrs]||'0:00'):'0:00',authSched:ci.authSched>=0?(row[ci.authSched]||'00:00'):'00:00'});
      }
    }catch(err){alert('Error: '+err.message);}
  };
  reader.readAsArrayBuffer(f);
}
function aaHrsToMins(s){s=(s||'').toString().trim();var neg=s.startsWith('-');s=s.replace(/^[+\-]/,'');var p=s.split(':');var m=(parseInt(p[0],10)||0)*60+(parseInt(p[1],10)||0);return neg?-m:m;}
function aaMinsToHrs(m){var neg=m<0;m=Math.abs(m);var h=Math.floor(m/60),mn=m%60;return(neg?'-':'')+h+':'+(mn<10?'0':'')+mn;}
function aaAnalyze() {
  if(!aaRows.length){alert('File not loaded yet. Please wait a moment.');return;}
  document.getElementById('aa-results').style.display='block';
  aaFilter();
}
function aaFilter() {
  var search=(document.getElementById('aa-search').value||'').toLowerCase();
  var filter=document.querySelector('[data-aafilter].on')?.dataset.aafilter||'all';
  var overCount=0,withinCount=0,totalOverMins=0;
  var filtered=aaRows.filter(function(r){
    var mins=aaHrsToMins(r.authSched), isOver=mins<0;
    if(isOver){overCount++;totalOverMins+=Math.abs(mins);}else withinCount++;
    if(filter==='over'&&!isOver)return false;
    if(filter==='within'&&isOver)return false;
    if(search&&!r.member.toLowerCase().includes(search))return false;
    return true;
  });
  document.getElementById('aa-totalMembers').textContent=aaRows.length;
  document.getElementById('aa-overCount').textContent=overCount;
  document.getElementById('aa-withinCount').textContent=withinCount;
  document.getElementById('aa-totalOver').textContent=aaMinsToHrs(totalOverMins);
  filtered.sort(function(a,b){return aaHrsToMins(a.authSched)-aaHrsToMins(b.authSched);});
  if(!filtered.length){document.getElementById('aa-tbody').innerHTML='<tr><td colspan="7" style="text-align:center;padding:2rem;color:var(--text3)">No records match</td></tr>';return;}
  document.getElementById('aa-tbody').innerHTML=filtered.map(function(r){
    var mins=aaHrsToMins(r.authSched), isOver=mins<0;
    var sbg=isOver?'rgba(239,68,68,.12)':'rgba(34,197,94,.12)';
    var sc=isOver?'#ef4444':'#22c55e';
    var slbl=isOver?'⚠ OVER-SCHEDULED':'✅ Within Auth';
    return '<tr style="background:'+(isOver?'rgba(239,68,68,.04)':'')+'"><td style="font-weight:600">'+r.member+'</td><td style="color:var(--text3);font-size:11px">'+r.period+'</td><td style="text-align:center">'+r.authHrs+'</td><td style="text-align:center">'+r.schedHrs+'</td><td style="text-align:center">'+r.confHrs+'</td><td style="text-align:center;font-weight:'+(isOver?'700':'400')+';color:'+(isOver?'var(--red)':'var(--green)')+'">'+r.authSched+'</td><td style="text-align:center"><span style="background:'+sbg+';color:'+sc+';padding:3px 10px;border-radius:999px;font-size:10px;font-weight:700;white-space:nowrap">'+slbl+'</span></td></tr>';
  }).join('');
}
function aaExport() {
  if(!aaRows.length)return;
  var ws=[['Member','Period','Auth Hours','Scheduled Hours','Confirmed Hours','Auth/Sched Gap','Status']];
  aaRows.forEach(function(r){ws.push([r.member,r.period,r.authHrs,r.schedHrs,r.confHrs,r.authSched,aaHrsToMins(r.authSched)<0?'OVER-SCHEDULED':'Within Auth']);});
  var wb=XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(ws),'Auth Analysis');
  XLSX.writeFile(wb,'auth-analysis-'+new Date().toISOString().slice(0,10)+'.xlsx');
}
function aaReset() {
  aaRows=[];
  document.getElementById('aa-fileBar').style.display='none';
  document.getElementById('aa-results').style.display='none';
  document.getElementById('aa-fileInp').value='';
  document.getElementById('aa-search').value='';
}

// ─── LETTER GENERATOR ─────────────────────────────────────────────────────────
function lvFmtDate(d){if(!d)return'';var x=new Date(d+'T00:00:00');return(x.getMonth()+1).toString().padStart(2,'0')+'/'+x.getDate().toString().padStart(2,'0')+'/'+x.getFullYear();}
function lvUpdate() {
  var type=document.getElementById('lv-type').value;
  var agEl=document.getElementById('lv-agency'); var agencyName=agEl.options[agEl.selectedIndex].text;
  var name=document.getElementById('lv-name').value.trim();
  var addr=document.getElementById('lv-addr').value.trim();
  var start=document.getElementById('lv-start').value;
  var date=document.getElementById('lv-date').value;
  var pos=document.getElementById('lv-emp-position').value;
  var client=(document.getElementById('lv-client')||{value:''}).value.trim();
  var sameAddr=document.getElementById('lv-sameaddr').checked;
  var clientAddr=(document.getElementById('lv-clientaddr')||{value:''}).value.trim()||addr;
  document.getElementById('lv-waiver-fields').style.display=type==='waiver'?'block':'none';
  document.getElementById('lv-emp-fields').style.display=type==='employment'?'block':'none';
  document.getElementById('lv-client-addr-wrap').style.display=sameAddr?'none':'block';
  document.getElementById('lv-hdr-name').textContent=agencyName;
  document.getElementById('lv-pAgency').textContent=agencyName;
  document.getElementById('lv-pDate').textContent=lvFmtDate(date)||'________';
  var N=name?'<strong>'+name+',</strong>':'<strong>[Employee Name]</strong>';
  var A=addr?'<strong>'+addr+',</strong>':'<strong>[Address]</strong>';
  var S=start?'<strong>'+lvFmtDate(start)+'</strong>':'<strong>[Start Date]</strong>';
  var C=client?'<strong>'+client+',</strong>':'<strong>[Client Name]</strong>';
  var CA=sameAddr?'the same address':(clientAddr?'<strong>'+clientAddr+'</strong>':'<strong>[Client Address]</strong>');
  if(type==='waiver'){
    document.getElementById('lv-pRe').textContent='Waiver';
    document.getElementById('lv-pBody').innerHTML='This is to confirm that '+N+' residing at '+A+' has been employed as a Direct Care Worker at '+agencyName+', since '+S+'. '+agencyName+' is a Licensed Home Care Agency providing Medicaid Waiver Services to Medicaid participants.';
    document.getElementById('lv-pBody2').style.display='block';
    document.getElementById('lv-pBody2').innerHTML=(name?'<strong>'+name+'</strong>':'[Employee]')+' provides Personal Care services for daily living to our client, '+C+' who resides at '+CA+'. '+(name?'<strong>'+name+"'s</strong>":"[Employee]'s")+' job responsibilities include providing personal care for daily living and companionship to elderly and disabled persons.';
    document.getElementById('lv-pBody3').style.display='block';
    document.getElementById('lv-pBody3').innerHTML='The client receives care approved under the <strong>Home and Community-Based Services (HCBS) Waiver Program</strong>. Income qualifies as Difficulty of Care Income per <strong>IRS Code 2014-7</strong> and is excluded from federal income tax.';
  }else{
    document.getElementById('lv-pRe').textContent='Employment Verification';
    document.getElementById('lv-pBody').innerHTML='This letter is to verify that '+N+' currently residing at '+A+' has been employed with <strong>'+agencyName+'</strong> as a <strong>'+pos+'</strong> since '+S+'.';
    document.getElementById('lv-pBody2').style.display='block';
    document.getElementById('lv-pBody2').innerHTML='Should you require any additional information or have questions, please feel free to contact us using the information provided below.';
    document.getElementById('lv-pBody3').style.display='none';
  }
}
function lvPrint() {
  var preview=document.getElementById('lv-preview');
  var w=window.open('','_blank','width=800,height=700');
  w.document.write('<!DOCTYPE html><html><head><title>Letter</title><style>body{font-family:Times New Roman,serif;font-size:13px;line-height:1.7;padding:48px;color:#111}strong{font-weight:700}</style></head><body>'+preview.innerHTML+'</body></html>');
  w.document.close(); w.focus(); setTimeout(function(){w.print();},400);
}

// ─── QUICK TEXT ───────────────────────────────────────────────────────────────
var QT_TEMPLATES=[
  {title:'Visit Not Confirmed — Reminder',text:'Hi [Caregiver Name], we noticed your visit for [Client Name] on [Date] has not been confirmed in EVV. Please log in and confirm your visit as soon as possible. If you have any issues, call the office at 412-618-8237. Thank you!'},
  {title:'Missed Visit — Follow Up',text:'Hi [Caregiver Name], it appears there was a missed visit for [Client Name] on [Date]. Please contact the office as soon as possible to provide an update. Missed visits must be reported within 24 hours. Call us at 412-618-8237.'},
  {title:'Schedule Reminder',text:'Hi [Caregiver Name], this is a reminder that you are scheduled to work with [Client Name] on [Date] from [Time]. Please make sure to clock in and out using the EVV app. Contact the office if you have any questions: 412-618-8237.'},
  {title:'Authorization Running Low',text:'Hi [Client/Family Name], we wanted to let you know that the authorization for home care services is running low and will expire soon. Please contact your MCO or case manager to request a renewal so services are not interrupted. Call our office at 412-618-8237 for assistance.'},
  {title:'New Hire Welcome',text:'Welcome to the Care Crafter team, [Name]! We are so glad to have you. Your orientation is scheduled for [Date/Time]. Please bring your ID and any required documents. If you have any questions before then, call us at 412-618-8237. We look forward to working with you!'},
  {title:'Clock-In Issue',text:'Hi [Caregiver Name], we noticed an issue with your clock-in/out for [Date]. Please contact the office at your earliest convenience so we can correct the record before payroll. Call 412-618-8237. Thank you!'},
  {title:'Payroll Reminder',text:'Hi team, a reminder that payroll cut-off for this period is [Date]. Please ensure all visits are confirmed in EVV and any time corrections are submitted by end of day. Contact the office with any questions: 412-618-8237.'},
  {title:'Client No-Show',text:'Hi [Caregiver Name], we understand that [Client Name] was not home when you arrived on [Date]. Please document your arrival time in the EVV system and contact the office right away so we can follow up with the client. Thank you for letting us know.'},
];
function qtRender() {
  var grid=document.getElementById('qt-grid');
  grid.innerHTML=QT_TEMPLATES.map(function(t,i){
    return '<div class="qt-card"><div class="qt-card-title">'+t.title+'</div><div class="qt-card-text">'+t.text+'</div><button class="qt-copy" data-qi="'+i+'">📋 Copy</button></div>';
  }).join('');
  grid.querySelectorAll('.qt-copy').forEach(function(btn){
    btn.addEventListener('click',function(){
      var txt=QT_TEMPLATES[+btn.dataset.qi].text;
      navigator.clipboard.writeText(txt).then(function(){
        btn.textContent='✅ Copied!'; btn.classList.add('qt-copied');
        setTimeout(function(){btn.textContent='📋 Copy';btn.classList.remove('qt-copied');},2000);
      });
    });
  });
}
