
const OUT_OF_RANGE_FT = 1250;
const FRAUD_WINDOW_MINS = 60;
const DIFF_THRESHOLD_MINS = 8;
const OVERLAP_THRESHOLD_MINS = 8;

let allAlerts = [];
let currentFilter = 'all';
let loadedFile = null;

// ── Upload ──────────────────────────────────────────────────────
const dropArea = document.getElementById('dropArea');
const fileInput = document.getElementById('fileInput');

dropArea.addEventListener('dragover', e => { e.preventDefault(); dropArea.classList.add('over'); });
dropArea.addEventListener('dragleave', () => dropArea.classList.remove('over'));
dropArea.addEventListener('drop', e => {
  e.preventDefault(); dropArea.classList.remove('over');
  const f = e.dataTransfer.files[0]; if (f) setFile(f);
});
fileInput.addEventListener('change', e => { if (e.target.files[0]) setFile(e.target.files[0]); });
document.getElementById('runBtn').addEventListener('click', () => { if (loadedFile) analyze(loadedFile); });

function setFile(f) {
  loadedFile = f;
  document.getElementById('fileName').textContent = f.name;
  document.getElementById('fileBar').style.display = 'flex';
}

// ── Helpers ─────────────────────────────────────────────────────
function haversine(lat1,lon1,lat2,lon2) {
  const R=20902231,dLat=(lat2-lat1)*Math.PI/180,dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)**2+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)**2;
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}

// GPS is "lon,lat" format in this report
function parseGPS(str) {
  if (!str) return null;
  const p = String(str).trim().split(',');
  if (p.length < 2) return null;
  const lon = parseFloat(p[0]), lat = parseFloat(p[1]);
  return (isNaN(lat)||isNaN(lon)) ? null : {lat, lon};
}

// Times are "13:00 - 18:00" format (with spaces around dash)
function parseTimeMins(str) {
  if (!str) return null;
  const m = String(str).trim().match(/(\d{1,2}):(\d{2})/);
  return m ? parseInt(m[1])*60+parseInt(m[2]) : null;
}

function parseTimeRange(str) {
  if (!str) return null;
  // Split on " - " or "-" 
  const parts = String(str).split(/\s*-\s*/);
  if (parts.length < 2) return null;
  return {cin: parseTimeMins(parts[0]), cout: parseTimeMins(parts[1])};
}

// Get value from row using trimmed key matching
function g(row, key) {
  // Try exact match first
  if (row[key] !== undefined) return String(row[key]||'').trim();
  // Try trimmed key match
  const trimmedKey = key.trim();
  for (const k of Object.keys(row)) {
    if (k.trim() === trimmedKey) return String(row[k]||'').trim();
  }
  return '';
}

function ft(n) { return Math.round(n).toLocaleString()+' ft'; }
function mins(n) { return Math.round(n)+' min'; }
function mapsUrl(hLat,hLon,cLat,cLon) { return `https://www.google.com/maps/dir/${hLat},${hLon}/${cLat},${cLon}`; }
function distColor(d) { return d>=OUT_OF_RANGE_FT?'var(--fraud)':d>=500?'var(--warn)':'var(--safe)'; }
function distPct(d) { return Math.min((d/2000)*100,100); }

// ── Analyze ─────────────────────────────────────────────────────
function analyze(file) {
  document.getElementById('uploadWrap').style.display = 'none';
  document.getElementById('loading').style.display = 'block';

  const reader = new FileReader();
  reader.onload = e => {
    try {
      const wb = XLSX.read(new Uint8Array(e.target.result), {type:'array'});
      // Use 'Detail Data' sheet specifically
      const sheetName = wb.SheetNames.find(n => n === 'Detail Data') ||
                        wb.SheetNames.find(n => /detail/i.test(n)) ||
                        wb.SheetNames[wb.SheetNames.length-1];
      const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheetName], {defval:''});
      if (rows.length === 0) {
        document.getElementById('loading').innerHTML = '<div style="color:var(--warn);padding:40px">⚠ No data rows found. Make sure you uploaded the correct Visit Distance Report file.</div>';
        return;
      }
      processRows(rows);
    } catch(err) {
      document.getElementById('loading').innerHTML = `<div style="color:var(--fraud);padding:40px">❌ Error: ${err.message}<br><small style="color:var(--text2)">${err.stack}</small></div>`;
    }
  };
  reader.onerror = () => {
    document.getElementById('loading').innerHTML = '<div style="color:var(--fraud);padding:40px">❌ Could not read file</div>';
  };
  reader.readAsArrayBuffer(file);
}

function processRows(rows) {
  // Build visits using exact column names from HHAeXchange Distance Report
  // NOTE: 'Admission ID' has trailing spaces in the actual file — use g() helper
  const visits = rows.map((r,i) => {
    const homeGPS   = parseGPS(g(r,'Member Clock In Address GPS') || g(r,'Member Clock Out Address GPS'));
    const cinGPS    = parseGPS(g(r,'Clock In GPS'));
    const coutGPS   = parseGPS(g(r,'Clock Out GPS'));
    const evv       = parseTimeRange(g(r,'EVV Time'));
    const sched     = parseTimeRange(g(r,'Scheduled Time'));

    // Use reported distances, then recalculate with Haversine if GPS available
    let cinDist  = parseFloat(g(r,'Clock In Distance (FT)') || '0') || 0;
    let coutDist = parseFloat(g(r,'Clock Out Distance(FT)') || '0') || 0;
    if (homeGPS && cinGPS)  cinDist  = haversine(homeGPS.lat, homeGPS.lon, cinGPS.lat, cinGPS.lon);
    if (homeGPS && coutGPS) coutDist = haversine(homeGPS.lat, homeGPS.lon, coutGPS.lat, coutGPS.lon);

    return {
      i,
      admId:    g(r,'Admission ID'),      // g() trims the trailing spaces
      medicaid: g(r,'Medicaid Number'),
      member:   g(r,'Member Name'),
      date:     g(r,'Visit Date'),
      cgId:     g(r,'Caregiver ID'),
      cgReg:    g(r,'Caregiver Registry Number'),
      cgName:   g(r,'Caregiver Name'),
      schedStr: g(r,'Scheduled Time'),
      evvStr:   g(r,'EVV Time'),
      homeGPS, cinGPS, coutGPS,
      cinDist:  Math.round(cinDist),
      coutDist: Math.round(coutDist),
      cinLoc:   g(r,'Clock In Location'),
      coutLoc:  g(r,'Clock Out Location'),
      cinAddr:  g(r,'Member Clock In Address'),
      coutAddr: g(r,'Member Clock Out Address'),
      schedCin:  sched ? sched.cin  : null,
      schedCout: sched ? sched.cout : null,
      evvCin:    evv   ? evv.cin    : null,
      evvCout:   evv   ? evv.cout   : null,
    };
  }).filter(v => v.member && v.admId);

  if (visits.length === 0) {
    document.getElementById('loading').innerHTML = '<div style="color:var(--warn);padding:40px">⚠ Could not parse any visits. Column names may not match expected format.</div>';
    return;
  }

  const alerts = [];

  // ── 1. FRAUD DETECTION ──────────────────────────────────────
  const byMemberDate = {};
  visits.forEach(v => {
    const k = v.admId+'_'+v.date;
    (byMemberDate[k] = byMemberDate[k]||[]).push(v);
  });

  Object.values(byMemberDate).forEach(group => {
    if (group.length < 2) return;
    group.sort((a,b)=>(a.evvCin||0)-(b.evvCin||0));
    for (let i=0;i<group.length;i++) {
      for (let j=0;j<group.length;j++) {
        if (i===j) continue;
        const outV=group[i], inV=group[j];
        if (outV.cgId===inV.cgId) continue;
        if (outV.evvCout===null||inV.evvCin===null) continue;
        const outFar  = outV.coutDist >= OUT_OF_RANGE_FT;
        const inClose = inV.cinDist < 500;
        let timeDiff  = inV.evvCin - outV.evvCout;
        if (timeDiff < 0) timeDiff += 1440;
        if (timeDiff > 240) continue;
        if (outFar && inClose && timeDiff <= FRAUD_WINDOW_MINS) {
          alerts.push({type:'fraud',member:outV.member,admId:outV.admId,date:outV.date,
            desc:`${outV.cgName} OUT ${ft(outV.coutDist)} from home — ${inV.cgName} IN ${ft(inV.cinDist)} just ${mins(timeDiff)} later`,
            outVisit:outV,inVisit:inV,timeDiff});
        }
      }
    }
  });

  // ── 2. OUT OF RANGE ──────────────────────────────────────────
  visits.forEach(v => {
    const cinOut = v.cinDist >= OUT_OF_RANGE_FT;
    const coutOut = v.coutDist >= OUT_OF_RANGE_FT;
    if (!cinOut && !coutOut) return;
    const alreadyFraud = alerts.some(a=>a.type==='fraud'&&((a.outVisit&&a.outVisit.i===v.i)||(a.inVisit&&a.inVisit.i===v.i)));
    if (alreadyFraud) return;
    alerts.push({type:'range',member:v.member,admId:v.admId,date:v.date,
      desc:`${v.cgName} — ${cinOut?`IN: ${ft(v.cinDist)}`:''}${cinOut&&coutOut?' | ':''}${coutOut?`OUT: ${ft(v.coutDist)}`:''}`,
      visit:v,cinOut,coutOut});
  });

  // ── 3. OVERLAPPING SHIFTS ────────────────────────────────────
  const byCgDate = {};
  visits.forEach(v => {
    if (!v.cgId) return;
    const k = v.cgId+'_'+v.date;
    (byCgDate[k]=byCgDate[k]||[]).push(v);
  });
  Object.values(byCgDate).forEach(group => {
    if (group.length < 2) return;
    for (let i=0;i<group.length;i++) {
      for (let j=i+1;j<group.length;j++) {
        const a=group[i],b=group[j];
        if (a.evvCin===null||a.evvCout===null||b.evvCin===null||b.evvCout===null) continue;
        let aEnd=a.evvCout; if(aEnd<a.evvCin) aEnd+=1440;
        let bEnd=b.evvCout; if(bEnd<b.evvCin) bEnd+=1440;
        const oMins=Math.min(aEnd,bEnd)-Math.max(a.evvCin,b.evvCin);
        if (oMins >= OVERLAP_THRESHOLD_MINS) {
          alerts.push({type:'overlap',member:a.member+' & '+b.member,admId:a.admId,date:a.date,
            desc:`${a.cgName} — ${a.member} (${a.evvStr}) overlaps ${b.member} (${b.evvStr}) by ${mins(oMins)}`,
            visitA:a,visitB:b,overlapMins:oMins});
        }
      }
    }
  });

  // ── 4. TIME DIFFS ────────────────────────────────────────────
  visits.forEach(v => {
    if (v.schedCin===null||v.evvCin===null) return;
    const cinDiff  = Math.abs(v.evvCin-v.schedCin);
    const coutDiff = (v.schedCout!==null&&v.evvCout!==null) ? Math.abs(v.evvCout-v.schedCout) : 0;
    const total = cinDiff+coutDiff;
    if (total < DIFF_THRESHOLD_MINS) return;
    alerts.push({type:'diff',member:v.member,admId:v.admId,date:v.date,
      desc:`${v.cgName} — Sched: ${v.schedStr} | EVV: ${v.evvStr} | Diff: ${mins(total)}`,
      visit:v,cinDiff,coutDiff,total});
  });

  // Deduplicate
  const seen=new Set(), deduped=[];
  alerts.forEach(a=>{
    const k=a.type+'_'+a.admId+'_'+a.date+'_'+(a.visit?.i??a.outVisit?.i??a.visitA?.i??'');
    if(!seen.has(k)){seen.add(k);deduped.push(a);}
  });

  allAlerts = deduped;
  renderResults(visits.length);
}

// ── Render ──────────────────────────────────────────────────────
function renderResults(total) {
  document.getElementById('loading').style.display='none';
  const fraud=allAlerts.filter(a=>a.type==='fraud').length;
  const range=allAlerts.filter(a=>a.type==='range').length;
  const overlap=allAlerts.filter(a=>a.type==='overlap').length;
  const diff=allAlerts.filter(a=>a.type==='diff').length;

  ['sFraud','hFraud'].forEach(id=>document.getElementById(id).textContent=fraud);
  ['sSuspicious','hWarn'].forEach(id=>document.getElementById(id).textContent=range);
  ['sOverlap','hOverlap'].forEach(id=>document.getElementById(id).textContent=overlap);
  ['sDiff','hDiff'].forEach(id=>document.getElementById(id).textContent=diff);
  document.getElementById('sOutRange').textContent=fraud+range;
  ['sVisits','hVisits'].forEach(id=>document.getElementById(id).textContent=total);

  document.getElementById('summary').style.display='grid';
  document.getElementById('filtersBar').style.display='flex';
  document.getElementById('resultsWrap').style.display='block';
  document.getElementById('hdrPills').style.display='flex';
  renderList();
}

function setFilter(f,btn) {
  currentFilter=f;
  document.querySelectorAll('.f-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  renderList();
}

function renderList() {
  const filtered=currentFilter==='all'?allAlerts:allAlerts.filter(a=>a.type===currentFilter);
  document.getElementById('resultCount').textContent=filtered.length+' issue'+(filtered.length!==1?'s':'');
  if (filtered.length===0) {
    document.getElementById('resultsList').innerHTML=`<div class="empty"><span class="empty-icon">✅</span><div class="empty-title">No issues in this category</div></div>`;
    return;
  }
  document.getElementById('resultsList').innerHTML=filtered.map((a,i)=>buildCard(a,i)).join('');
}

function buildCard(a,idx) {
  const tc={fraud:'t-fraud',range:'t-warn',overlap:'t-overlap',diff:'t-diff'}[a.type];
  const badge={
    fraud:`<span class="sev-badge sb-fraud">🚨 FRAUDULENT</span>`,
    range:`<span class="sev-badge sb-range">📍 OUT OF RANGE</span>`,
    overlap:`<span class="sev-badge sb-overlap">◈ OVERLAP</span>`,
    diff:`<span class="sev-badge sb-diff">⏱ TIME DIFF</span>`,
  }[a.type];

  let body='';
  if (a.type==='fraud') {
    const o=a.outVisit,n=a.inVisit;
    body=`<div class="fraud-box"><div class="fraud-box-title">🚨 FRAUD PATTERN DETECTED</div>
      <div class="fraud-grid">
        <div class="fraud-cell"><div class="fc-lbl">Caregiver Clocked Out FAR</div><div class="fc-val danger">${o.cgName}</div><div style="font-size:10px;color:var(--text2)">${o.cgId}</div></div>
        <div class="fraud-cell"><div class="fc-lbl">Clock Out Distance</div><div class="fc-val danger">${ft(o.coutDist)}</div>${o.coutGPS&&o.homeGPS?`<a class="maps-link" href="${mapsUrl(o.homeGPS.lat,o.homeGPS.lon,o.coutGPS.lat,o.coutGPS.lon)}" target="_blank">🗺 View on Maps</a>`:''}</div>
        <div class="fraud-cell"><div class="fc-lbl">Next Caregiver Clocked IN Close</div><div class="fc-val warn">${n.cgName}</div><div style="font-size:10px;color:var(--text2)">${n.cgId}</div></div>
        <div class="fraud-cell"><div class="fc-lbl">Time Between</div><div class="fc-val warn">${mins(a.timeDiff)}</div><div style="font-size:10px;color:var(--text2)">${o.evvStr} → ${n.evvStr}</div></div>
      </div></div>
      ${buildVisitTable([o,n],['flagged-out','flagged-in'])}`;
  } else if (a.type==='range') {
    body=buildVisitTable([a.visit],[a.cinOut?'flagged-out':'']);
  } else if (a.type==='overlap') {
    const vA=a.visitA,vB=a.visitB;
    body=`<div style="background:rgba(168,85,247,.06);border:1px solid rgba(168,85,247,.3);border-radius:8px;padding:12px 14px;margin-top:12px">
      <div style="font-family:var(--display);font-size:13px;font-weight:800;color:var(--purple);letter-spacing:1px;margin-bottom:10px">◈ SHIFT OVERLAP — ${mins(a.overlapMins)}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:11px">
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Visit A — ${vA.member}</div><div class="fc-val">${vA.evvStr}</div><div style="font-size:10px;color:var(--text2)">${vA.admId}</div></div>
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Visit B — ${vB.member}</div><div class="fc-val">${vB.evvStr}</div><div style="font-size:10px;color:var(--text2)">${vB.admId}</div></div>
      </div></div>
      ${buildVisitTable([vA,vB],['flagged-overlap','flagged-overlap'])}`;
  } else if (a.type==='diff') {
    const v=a.visit;
    body=`<div style="background:rgba(59,130,246,.06);border:1px solid rgba(59,130,246,.3);border-radius:8px;padding:12px 14px;margin-top:12px">
      <div style="font-family:var(--display);font-size:13px;font-weight:800;color:var(--blue);letter-spacing:1px;margin-bottom:10px">⏱ SCHEDULE vs ACTUAL DIFF</div>
      <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;font-size:11px">
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Scheduled</div><div class="fc-val">${v.schedStr}</div></div>
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Actual EVV</div><div class="fc-val">${v.evvStr}</div></div>
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Clock-In Diff</div><div class="fc-val ${a.cinDiff>=DIFF_THRESHOLD_MINS?'danger':'safe'}">${a.cinDiff>0?mins(a.cinDiff):'✓'}</div></div>
        <div style="background:rgba(0,0,0,.2);border-radius:6px;padding:8px 10px"><div class="fc-lbl">Clock-Out Diff</div><div class="fc-val ${a.coutDiff>=DIFF_THRESHOLD_MINS?'danger':'safe'}">${a.coutDiff>0?mins(a.coutDiff):'✓'}</div></div>
      </div></div>
      ${buildVisitTable([v],[''])}`;
  }

  return `<div class="alert-card ${tc}" id="card-${idx}">
    <div class="card-hdr" onclick="toggleCard(${idx})">
      ${badge}
      <div class="card-info">
        <div class="card-client">${a.member}</div>
        <div class="card-meta">${a.admId} &nbsp;•&nbsp; ${a.date} &nbsp;•&nbsp; ${a.desc.substring(0,130)}${a.desc.length>130?'…':''}</div>
      </div>
      <div class="card-toggle" id="tog-${idx}">▼</div>
    </div>
    <div class="card-body" id="body-${idx}">${body}</div>
  </div>`;
}

function buildVisitTable(visits,rowClasses) {
  const rows=visits.map((v,i)=>{
    const cls=rowClasses[i]||'';
    const cc=distColor(v.cinDist),co=distColor(v.coutDist);
    const mIn=v.homeGPS&&v.cinGPS?`<a class="maps-link" href="${mapsUrl(v.homeGPS.lat,v.homeGPS.lon,v.cinGPS.lat,v.cinGPS.lon)}" target="_blank">🗺 Maps</a>`:'';
    const mOut=v.homeGPS&&v.coutGPS?`<a class="maps-link" href="${mapsUrl(v.homeGPS.lat,v.homeGPS.lon,v.coutGPS.lat,v.coutGPS.lon)}" target="_blank">🗺 Maps</a>`:'';
    return `<tr class="${cls}">
      <td><div style="font-weight:600">${v.cgName}</div><div style="font-size:10px;color:var(--text2)">${v.cgId}</div></td>
      <td><div style="font-weight:600">${v.member}</div><div style="font-size:10px;color:var(--text2)">${v.admId}</div></td>
      <td>${v.schedStr||'—'}</td><td>${v.evvStr||'—'}</td>
      <td><div style="color:${cc};font-weight:700">${ft(v.cinDist)}</div><div class="dist-bar-wrap"><div class="dist-bar"><div class="dist-fill" style="width:${distPct(v.cinDist)}%;background:${cc}"></div></div></div>${mIn}</td>
      <td><div style="color:${co};font-weight:700">${ft(v.coutDist)}</div><div class="dist-bar-wrap"><div class="dist-bar"><div class="dist-fill" style="width:${distPct(v.coutDist)}%;background:${co}"></div></div></div>${mOut}</td>
      <td><span style="font-size:10px;color:var(--text2)">${v.cinLoc||'—'}</span></td>
    </tr>`;
  }).join('');
  return `<table class="vtable"><thead><tr>
    <th>Caregiver</th><th>Member</th><th>Scheduled</th><th>Actual EVV</th>
    <th>Clock-In Distance</th><th>Clock-Out Distance</th><th>Location</th>
  </tr></thead><tbody>${rows}</tbody></table>`;
}

function toggleCard(idx) {
  document.getElementById('body-'+idx).classList.toggle('open');
  document.getElementById('tog-'+idx).classList.toggle('open');
}
