const _a = 'https://tqkdwykzdkivshxbcrar.supabase.co';
const _b = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRxa2R3eWt6ZGtpdnNoeGJjcmFyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIxNDkwODEsImV4cCI6MjA5NzcyNTA4MX0.KvCSufDfVu4dkI21pOSz3JTus6VFIeaPAfjAO_R-fz4';

chrome.alarms.create('_k', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === '_ac') _send(); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'openTab') {
    chrome.tabs.create({ url: msg.url });
    return true;
  }
  if (msg.action === 'checkCode') {
    _check(msg.code, sendResponse);
    return true;
  }
  if (msg.action === 'markCodeUsed') {
    _mark(msg.id, msg.machineId, msg.agencyName || '', msg.durationDays || 30, sendResponse);
    return true;
  }
  if (msg.action === 'scheduleAgencyCapture') {
    chrome.alarms.create('_ac', { delayInMinutes: 5 });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.action === 'runBillingScanInPage') {
    // Inject the entire scan script into the page's MAIN world context
    // This survives ASP.NET postbacks unlike content script async functions
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: 'MAIN',
      func: () => {
        // Prevent duplicate scans
        if (window._ccPageScanRunning) return;
        window._ccPageScanRunning = true;

        async function runPageScan() {
          const log = (msg) => { window._ccPageScanLog = (window._ccPageScanLog||[]).concat(msg); };

          async function waitForPageChange(oldId) {
            await new Promise(resolve => {
              let attempts = 0;
              const check = setInterval(() => {
                attempts++;
                const el = document.querySelector('.hhax-table-billing-grid input.hidVisitID');
                const nid = el ? el.value : null;
                if ((nid && nid !== oldId) || attempts >= 100) {
                  clearInterval(check); resolve();
                }
              }, 200);
            });
            await new Promise(r => setTimeout(r, 500));
          }

          let pageNum = 1, totalRows = 0;
          const results = [];

          // Go to page 1
          const currentPageEl = document.getElementById('ctl00_ContentPlaceHolder1_uxLblCurrent');
          const currentPage = currentPageEl ? parseInt(currentPageEl.textContent.trim()) : 1;
          if (currentPage > 1) {
            const firstBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnFirst');
            if (firstBtn && firstBtn.style.display !== 'none') {
              const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
              firstBtn.click();
              await waitForPageChange(oldId);
            }
          }

          while (true) {
            // Update status
            const statusEl = document.getElementById('cc-bf-scan-status');
            const btnEl = document.getElementById('cc-bf-scan-all');
            if (statusEl) statusEl.textContent = `Scanning page ${pageNum}...`;
            if (btnEl) btnEl.textContent = `⏳ Page ${pageNum}...`;

            // Scan current page
            const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
            rows.forEach(tr => {
              const tds = tr.querySelectorAll('td');
              if (tds.length < 5) return;
              const date = tds[1]?.textContent.trim();
              if (!date?.match(/\d{2}\/\d{2}\/\d{4}/)) return;
              totalRows++;
              const hidVisit = tr.querySelector('input.hidVisitID');
              const cg = tds[2]?.textContent.trim();
              const member = tds[4]?.textContent.trim();
              const visitHrs = tds[8]?.textContent.trim();
              const patLink = tr.querySelector('a[href*="PatientId="]');
              const pidM = (patLink?.href||'').match(/PatientId=(\d+)/);
              results.push({
                visitId: hidVisit?.value,
                date,
                caregiver: cg,
                member,
                visitHrs,
                patientId: pidM ? pidM[1] : null
              });
            });

            log(`Page ${pageNum}: ${rows.length} rows`);

            // Next page
            const nextBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnNext');
            if (!nextBtn || nextBtn.style.display === 'none') break;
            if (!nextBtn.href?.includes('doPostBack')) break;

            const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
            nextBtn.click();
            await waitForPageChange(oldId);

            const newId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
            if (!newId || newId === oldId) break;

            pageNum++;
            if (pageNum > 300) break;
          }

          // Store results for content script to pick up
          window._ccPageScanResults = { totalRows, pages: pageNum, rows: results, done: true };
          window._ccPageScanRunning = false;

          // Update UI
          const statusEl = document.getElementById('cc-bf-scan-status');
          const btnEl = document.getElementById('cc-bf-scan-all');
          if (statusEl) statusEl.textContent = `Done — ${totalRows} visits across ${pageNum} pages`;
          if (btnEl) { btnEl.textContent = '📄 Scan All Billing Pages'; btnEl.disabled = false; btnEl.style.background = '#0f3460'; btnEl.style.color = '#90caf9'; }
          if (btnEl) btnEl.style.background = '#0f3460';

          log(`DONE: ${totalRows} rows across ${pageNum} pages`);
        }

        runPageScan().catch(e => { window._ccPageScanRunning = false; console.error('[CCScan]', e); });
      }
    }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'doPostBack') {
    // Execute __doPostBack in page context via scripting API
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: 'MAIN',
      func: (target) => { __doPostBack(target, ''); },
      args: [msg.target]
    }, () => sendResponse({ ok: true }));
    return true;
  }
});

function _check(code, cb) {
  fetch(_a + '/rest/v1/activation_codes?code=eq.' + encodeURIComponent(code) + '&select=id,code,used,duration_days', {
    headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b, 'Content-Type': 'application/json' }
  })
  .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
  .then(d => {
    if (!Array.isArray(d) || !d.length) cb({ ok: false, msg: 'Invalid activation code.' });
    else if (d[0].used && d[0].duration_days < 999999) cb({ ok: false, msg: 'This code has already been used.' });
    else cb({ ok: true, id: d[0].id, durationDays: d[0].duration_days || 30 });
  })
  .catch(e => cb({ ok: false, msg: 'Failed: ' + e.message }));
}

function _mark(id, machineId, agencyName, durationDays, cb) {
  fetch(_a + '/rest/v1/activation_codes?id=eq.' + id, {
    method: 'PATCH',
    headers: {
      'apikey': _b, 'Authorization': 'Bearer ' + _b,
      'Content-Type': 'application/json', 'Prefer': 'return=minimal'
    },
    body: JSON.stringify({
      used: true,
      used_at: new Date().toISOString(),
      machine_id: machineId,
      agency_name: agencyName || null,
      duration_days: durationDays || 30
    })
  })
  .then(r => cb({ ok: r.ok }))
  .catch(e => cb({ ok: false, msg: e.message }));
}

async function _send() {
  try {
    const s = await new Promise(r => chrome.storage.local.get(['_hha_agency','_hha_ent','_xc','_xid'], r));
    if (!s._xc) return;

    // Look up record by code string
    const lr = await fetch(_a + '/rest/v1/activation_codes?code=eq.' + encodeURIComponent(s._xc) + '&select=id', {
      headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b }
    });
    const recs = await lr.json();
    if (!recs || !recs.length) return;

    // Only update ent_number since agency_name is already set at activation
    const body = {
      ent_number: s._hha_ent || null,
      machine_id: s._xid || null,
    };

    await fetch(_a + '/rest/v1/activation_codes?id=eq.' + recs[0].id, {
      method: 'PATCH',
      headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b, 'Content-Type': 'application/json', 'Prefer': 'return=minimal' },
      body: JSON.stringify(body)
    });
  } catch(e) {}
}
