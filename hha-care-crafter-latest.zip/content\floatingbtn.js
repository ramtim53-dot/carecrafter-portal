(function() {
  if (document.getElementById('cc-fab')) return;

  // FAB button
  const fab = document.createElement('button');
  fab.id = 'cc-fab';
  fab.title = 'Care Crafter Tools';
  const fabImg = document.createElement('img');
  fabImg.src = chrome.runtime.getURL('icons/icon48.png');
  fabImg.style.cssText = 'width:36px;height:36px;border-radius:50%;object-fit:cover;pointer-events:none';
  fab.appendChild(fabImg);
  document.body.appendChild(fab);

  // Panel
  const panel = document.createElement('div');
  panel.id = 'cc-panel';
  panel.innerHTML = `
    <div id="cc-panel-header">
      <div id="cc-panel-logo"><img src="${chrome.runtime.getURL('icons/icon48.png')}" style="width:20px;height:20px;object-fit:cover;border-radius:4px"></div>
      <div id="cc-panel-title">Care Crafter</div>
      <button id="cc-panel-min" title="Minimize">─</button>
      <button id="cc-panel-close" title="Close">✕</button>
    </div>
    <div id="cc-panel-body">
      <div class="cc-section-label">🧮 Pay Rate Calculator</div>
      <div class="cc-rc-grid">
        <div><label class="cc-label">Bi-Weekly Hours</label><input type="number" id="cc-biwHrs" class="cc-input" value="224"></div>
        <div><label class="cc-label">Bill Rate ($/hr)</label><input type="number" id="cc-rate" class="cc-input" value="16.00" step="0.01"></div>
      </div>
      <div class="cc-result-box">
        <div class="cc-result-label">✅ TYPE INTO ADP</div>
        <div id="cc-payRate" class="cc-result-big">$0.00</div>
        <div class="cc-result-sub">= (BiW Hrs × Rate) ÷ (80 + OT Hrs × 1.5)</div>
      </div>
      <div class="cc-breakdown">
        <div class="cc-breakdown-row"><span>Total Bi-Weekly Pay</span><span id="cc-totalAmt" class="cc-val">$0.00</span></div>
        <div class="cc-breakdown-row"><span>OT Hours (BiW − 80)</span><span id="cc-otHrs" class="cc-val">0</span></div>
        <div class="cc-breakdown-row"><span>Divisor (80 + OT×1.5)</span><span id="cc-divisor" class="cc-val">0</span></div>
      </div>

      <hr class="cc-divider">

      <div class="cc-section-label">Portal Tools</div>
      <div class="cc-tools-grid">
        <button class="cc-tool-btn" data-view="distance"><span class="cc-icon">📍</span>Distance Checker</button>
        <button class="cc-tool-btn" data-view="payroll"><span class="cc-icon">💰</span>Payroll Hours</button>
        <button class="cc-tool-btn" data-view="hours"><span class="cc-icon">📊</span>Hours Analysis</button>
        <button class="cc-tool-btn" data-view="overlaps"><span class="cc-icon">🔄</span>Overlapping Shifts</button>
        <button class="cc-tool-btn" data-view="authanalysis"><span class="cc-icon">🔐</span>Auth Analysis</button>
        <button class="cc-tool-btn" data-view="letters"><span class="cc-icon">📄</span>Letter Generator</button>
        <button class="cc-tool-btn" data-view="news"><span class="cc-icon">📰</span>Industry News</button>
        <button class="cc-tool-btn" data-view="quicktext"><span class="cc-icon">💬</span>Quick Text</button>
        <button class="cc-tool-btn" data-view="pdftool"><span class="cc-icon">📑</span>PDF Tool</button>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // FAB — drag or click
  let fabDragging = false, fabMoved = false, fox = 0, foy = 0;
  fab.addEventListener('mousedown', e => {
    fabDragging = true; fabMoved = false;
    fox = e.clientX - fab.getBoundingClientRect().left;
    foy = e.clientY - fab.getBoundingClientRect().top;
    fab.style.right = 'auto'; fab.style.bottom = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!fabDragging) return;
    if (Math.abs(e.clientX - (fab.getBoundingClientRect().left + fox)) > 5 ||
        Math.abs(e.clientY - (fab.getBoundingClientRect().top + foy)) > 5) fabMoved = true;
    if (fabMoved) {
      fab.style.left = (e.clientX - fox) + 'px';
      fab.style.top = (e.clientY - foy) + 'px';
    }
  });
  document.addEventListener('mouseup', () => { fabDragging = false; });

  fab.addEventListener('click', () => {
    if (fabMoved) { fabMoved = false; return; } // was a drag, not a click
    const open = panel.classList.toggle('visible');
    fab.classList.toggle('open', open);
    if (open) ccRcCalc();
  });

  // Panel close
  document.getElementById('cc-panel-close').addEventListener('click', () => {
    panel.classList.remove('visible');
    fab.classList.remove('open');
  });

  // Minimize
  let minimized = false;
  const body = document.getElementById('cc-panel-body');
  const minBtn = document.getElementById('cc-panel-min');
  minBtn.addEventListener('click', () => {
    minimized = !minimized;
    body.style.display = minimized ? 'none' : '';
    panel.style.resize = minimized ? 'none' : 'both';
    minBtn.textContent = minimized ? '▲' : '─';
    minBtn.title = minimized ? 'Restore' : 'Minimize';
  });

  // Drag panel by header
  const header = document.getElementById('cc-panel-header');
  let dragging = false, ox = 0, oy = 0;
  header.addEventListener('mousedown', e => {
    if (e.target === minBtn || e.target === document.getElementById('cc-panel-close')) return;
    dragging = true;
    ox = e.clientX - panel.getBoundingClientRect().left;
    oy = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto'; panel.style.bottom = 'auto';
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    panel.style.left = (e.clientX - ox) + 'px';
    panel.style.top = (e.clientY - oy) + 'px';
  });
  document.addEventListener('mouseup', () => { dragging = false; });

  // Rate calc
  function ccRcCalc() {
    const biw = parseFloat(document.getElementById('cc-biwHrs')?.value) || 0;
    const rate = parseFloat(document.getElementById('cc-rate')?.value) || 0;
    if (!biw || !rate) return;
    const total = biw * rate;
    const otHrs = Math.max(0, biw - 80);
    const divisor = 80 + otHrs * 1.5;
    const payRate = divisor > 0 ? total / divisor : 0;
    document.getElementById('cc-payRate').textContent = '$' + payRate.toFixed(2);
    document.getElementById('cc-totalAmt').textContent = '$' + total.toFixed(2);
    document.getElementById('cc-otHrs').textContent = otHrs.toFixed(2) + ' hrs';
    document.getElementById('cc-divisor').textContent = divisor.toFixed(2);
  }

  function ccOpen(view) {
    chrome.runtime.sendMessage({ action: 'openTab', url: chrome.runtime.getURL('tools.html') + (view ? '?v=' + view : '') });
  }

  // Wire up rate calc inputs with event listeners (not inline onclick)
  document.getElementById('cc-biwHrs').addEventListener('input', ccRcCalc);
  document.getElementById('cc-rate').addEventListener('input', ccRcCalc);

  // Wire up tool buttons with event listeners (not inline onclick)
  document.querySelectorAll('.cc-tool-btn').forEach(btn => {
    btn.addEventListener('click', () => ccOpen(btn.dataset.view));
  });

  ccRcCalc();
})();
