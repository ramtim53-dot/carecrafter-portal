(function() {
  if (document.getElementById('cc-fab')) return;

  // FAB button
  const fab = document.createElement('button');
  fab.id = 'cc-fab';
  fab.title = 'Care Crafter Tools';
  const fabImg = document.createElement('img');
  fabImg.src = chrome.runtime.getURL('icons/icon48.png');
  fabImg.style.cssText = 'width:36px;height:36px;border-radius:50%;object-fit:cover;pointer-events:none';
  fab.appendChild(fabImg);
  document.body.appendChild(fab);

  // Panel
  const panel = document.createElement('div');
  panel.id = 'cc-panel';
  panel.innerHTML = `
    <div id="cc-panel-header">
      <div id="cc-panel-logo"><img src="${chrome.runtime.getURL('icons/icon48.png')}" style="width:20px;height:20px;object-fit:cover;border-radius:4px"></div>
      <div id="cc-panel-title">Care Crafter</div>
      <button id="cc-panel-min" title="Minimize">─</button>
      <button id="cc-panel-close" title="Close">✕</button>
    </div>
    <div id="cc-panel-body">
      <div class="cc-section-label">🧮 Pay Rate Calculator</div>
      <div class="cc-rc-grid">
        <div><label class="cc-label">Bi-Weekly Hours</label><input type="number" id="cc-biwHrs" class="cc-input" value="224"></div>
        <div><label class="cc-label">Bill Rate ($/hr)</label><input type="number" id="cc-rate" class="cc-input" value="16.00" step="0.01"></div>
      </div>
      <div class="cc-result-box">
        <div class="cc-result-label">✅ TYPE INTO ADP</div>
        <div id="cc-payRate" class="cc-result-big">$0.00</div>
        <div class="cc-result-sub">= (BiW Hrs × Rate) ÷ (80 + OT Hrs × 1.5)</div>
      </div>
      <div class="cc-breakdown">
        <div class="cc-breakdown-row"><span>Total Bi-Weekly Pay</span><span id="cc-totalAmt" class="cc-val">$0.00</span></div>
        <div class="cc-breakdown-row"><span>OT Hours (BiW − 80)</span><span id="cc-otHrs" class="cc-val">0</span></div>
        <div class="cc-breakdown-row"><span>Divisor (80 + OT×1.5)</span><span id="cc-divisor" class="cc-val">0</span></div>
      </div>

      <hr class="cc-divider">

      <div class="cc-section-label">🧠 AI Chat</div>
      <div id="cc-chat-scroll">
        <div id="cc-chat-wrap"></div>
      </div>
      <div id="cc-chat-bar">
        <textarea id="cc-chat-input" placeholder="Message AI..." rows="1"></textarea>
        <button id="cc-chat-send">Send</button>
      </div>

      <hr class="cc-divider">

      <div class="cc-section-label">Portal Tools</div>
      <div class="cc-tools-grid">
        <button class="cc-tool-btn" data-view="distance"><span class="cc-icon">📍</span>Distance Checker</button>
        <button class="cc-tool-btn" data-view="payroll"><span class="cc-icon">💰</span>Payroll Hours</button>
        <button class="cc-tool-btn" data-view="hours"><span class="cc-icon">📊</span>Hours Analysis</button>
        <button class="cc-tool-btn" data-view="overlaps"><span class="cc-icon">🔄</span>Overlapping Shifts</button>
        <button class="cc-tool-btn" data-view="authanalysis"><span class="cc-icon">🔐</span>Auth Analysis</button>
        <button class="cc-tool-btn" data-view="letters"><span class="cc-icon">📄</span>Letter Generator</button>
        <button class="cc-tool-btn" data-view="news"><span class="cc-icon">📰</span>Industry News</button>
        <button class="cc-tool-btn" data-view="quicktext"><span class="cc-icon">💬</span>Quick Text</button>
        <button class="cc-tool-btn" data-view="pdftool"><span class="cc-icon">📑</span>PDF Tool</button>
        <button class="cc-tool-btn" data-view="brainai" data-portal="1"><span class="cc-icon">🎨</span>Image/OCR/PDF AI</button>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // FAB — drag or click
  let fabDragging = false, fabMoved = false, fox = 0, foy = 0;
  fab.addEventListener('mousedown', e => {
    fabDragging = true; fabMoved = false;
    fox = e.clientX - fab.getBoundingClientRect().left;
    foy = e.clientY - fab.getBoundingClientRect().top;
    fab.style.right = 'auto'; fab.style.bottom = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!fabDragging) return;
    if (Math.abs(e.clientX - (fab.getBoundingClientRect().left + fox)) > 5 ||
        Math.abs(e.clientY - (fab.getBoundingClientRect().top + foy)) > 5) fabMoved = true;
    if (fabMoved) {
      fab.style.left = (e.clientX - fox) + 'px';
      fab.style.top = (e.clientY - foy) + 'px';
    }
  });
  document.addEventListener('mouseup', () => { fabDragging = false; });

  fab.addEventListener('click', () => {
    if (fabMoved) { fabMoved = false; return; } // was a drag, not a click
    const open = panel.classList.toggle('visible');
    fab.classList.toggle('open', open);
    if (open) ccRcCalc();
  });

  // Panel close
  document.getElementById('cc-panel-close').addEventListener('click', () => {
    panel.classList.remove('visible');
    fab.classList.remove('open');
  });

  // Minimize
  let minimized = false;
  const body = document.getElementById('cc-panel-body');
  const minBtn = document.getElementById('cc-panel-min');
  minBtn.addEventListener('click', () => {
    minimized = !minimized;
    body.style.display = minimized ? 'none' : '';
    panel.style.resize = minimized ? 'none' : 'both';
    minBtn.textContent = minimized ? '▲' : '─';
    minBtn.title = minimized ? 'Restore' : 'Minimize';
  });

  // Drag panel by header
  const header = document.getElementById('cc-panel-header');
  let dragging = false, ox = 0, oy = 0;
  header.addEventListener('mousedown', e => {
    if (e.target === minBtn || e.target === document.getElementById('cc-panel-close')) return;
    dragging = true;
    ox = e.clientX - panel.getBoundingClientRect().left;
    oy = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto'; panel.style.bottom = 'auto';
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    panel.style.left = (e.clientX - ox) + 'px';
    panel.style.top = (e.clientY - oy) + 'px';
  });
  document.addEventListener('mouseup', () => { dragging = false; });

  // Rate calc
  function ccRcCalc() {
    const biw = parseFloat(document.getElementById('cc-biwHrs')?.value) || 0;
    const rate = parseFloat(document.getElementById('cc-rate')?.value) || 0;
    if (!biw || !rate) return;
    const total = biw * rate;
    const otHrs = Math.max(0, biw - 80);
    const divisor = 80 + otHrs * 1.5;
    const payRate = divisor > 0 ? total / divisor : 0;
    document.getElementById('cc-payRate').textContent = '$' + payRate.toFixed(2);
    document.getElementById('cc-totalAmt').textContent = '$' + total.toFixed(2);
    document.getElementById('cc-otHrs').textContent = otHrs.toFixed(2) + ' hrs';
    document.getElementById('cc-divisor').textContent = divisor.toFixed(2);
  }

  function ccOpen(view) {
    chrome.runtime.sendMessage({ action: 'openTab', url: chrome.runtime.getURL('tools.html') + (view ? '?v=' + view : '') });
  }

  // Brain AI needs the live portal's server (Gemini/Hugging Face/Stability API
  // routes) — it can't run offline inside the extension like the other tools.
  function ccOpenPortal(view) {
    chrome.runtime.sendMessage({ action: 'openTab', url: 'https://carecrafter-portal.vercel.app/?ext=1&v=' + view });
  }

  // Wire up rate calc inputs with event listeners (not inline onclick)
  document.getElementById('cc-biwHrs').addEventListener('input', ccRcCalc);
  document.getElementById('cc-rate').addEventListener('input', ccRcCalc);

  // Wire up tool buttons with event listeners (not inline onclick)
  document.querySelectorAll('.cc-tool-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.portal === '1') ccOpenPortal(btn.dataset.view);
      else ccOpen(btn.dataset.view);
    });
  });

  // ── AI Chat (runs inline in the panel — calls the portal's live Gemini API) ──
  const API_BASE = 'https://carecrafter-portal.vercel.app';
  const CHAT_KEY = 'cc_fab_chat_history';
  let ccChatHistory = [];
  try { ccChatHistory = JSON.parse(localStorage.getItem(CHAT_KEY) || '[]'); } catch (e) { ccChatHistory = []; }

  function ccSaveChat() { try { localStorage.setItem(CHAT_KEY, JSON.stringify(ccChatHistory)); } catch (e) {} }

  function ccAddBubble(role, text) {
    const wrap = document.getElementById('cc-chat-wrap');
    const div = document.createElement('div');
    div.className = 'cc-msg cc-msg-' + role;
    div.textContent = text;
    wrap.appendChild(div);
    const scroll = document.getElementById('cc-chat-scroll');
    scroll.scrollTop = scroll.scrollHeight;
    return div;
  }

  ccChatHistory.forEach(m => ccAddBubble(m.role, m.text));

  const CC_PERSONA = "You are Care Crafter's AI assistant, a helpful, direct personal AI. Answer clearly and concisely.";

  async function ccSendChat() {
    const input = document.getElementById('cc-chat-input');
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    ccChatHistory.push({ role: 'user', text });
    ccAddBubble('user', text);
    const thinking = ccAddBubble('assistant', 'thinking…');
    document.getElementById('cc-chat-send').disabled = true;
    try {
      const contents = ccChatHistory.map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.text }]
      }));
      const r = await fetch(API_BASE + '/api/gemini', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'gemini-2.5-flash', payload: { contents, systemInstruction: { parts: [{ text: CC_PERSONA }] } } })
      });
      const data = await r.json();
      if (data.error) throw new Error(data.error.message || 'Server error');
      const parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
      const reply = parts ? parts.map(p => p.text || '').join('') : '';
      if (!reply.trim()) throw new Error('Empty response');
      ccChatHistory.push({ role: 'assistant', text: reply });
      thinking.textContent = reply;
      ccSaveChat();
    } catch (err) {
      ccChatHistory.pop();
      thinking.textContent = '⚠️ ' + err.message;
    }
    document.getElementById('cc-chat-send').disabled = false;
  }

  document.getElementById('cc-chat-send').addEventListener('click', ccSendChat);
  document.getElementById('cc-chat-input').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); ccSendChat(); }
  });

  ccRcCalc();
})();
