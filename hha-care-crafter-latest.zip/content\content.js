// ─── HHA Care Crafter Content Script ─────────────────────────────

// License check — stop everything if expired or not activated
(function() {
  chrome.storage.local.get(['_xa', '_xe'], result => {
    const activated = result._xa || false;
    const expiry    = result._xe    || null;
    const expired   = !expiry || Date.now() > expiry;
    if (!activated || expired) {
      return;
    }
    initExtension();
  });
})();

function initExtension() {


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'evvScan')    { sendResponse({ items: runEVVScan() });    return true; }
  if (message.action === 'claimScan') { sendResponse({ items: runClaimScan() });  return true; }
  if (message.action === 'missedScan'){ sendResponse({ items: runMissedScan() }); return true; }
});

// ─── INIT ─────────────────────────────────────────────────────────
function init() {
  if (!window.location.href.includes('hhaexchange.com')) return;
  setTimeout(detectPageAndRun, 800);
  setTimeout(detectPageAndRun, 2000);
  setTimeout(detectPageAndRun, 4000);

  // ── Watch for calendar month navigation ───────────────────────────────
  // Hook the Go button directly AND watch the UpdatePanel for DOM changes
  let calRescanTimer = null;

  function rerunCalendar() {
    clearTimeout(calRescanTimer);
    calRescanTimer = setTimeout(() => {
      // Remove old CC injections so they get rebuilt fresh
      document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
      document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
        el.style.removeProperty('outline');
        el.style.removeProperty('background-color');
        el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
      });
      const bodyText = document.body.innerText;
      const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
      const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
      if (hasClientCal) runClientCalendar();
      else if (hasCaregiverCal) runCaregiverCalendar();
      // If no cells found yet, retry once more after longer delay
      else setTimeout(() => {
        const bt = document.body.innerText;
        if (bt.includes('Billed:') && bt.includes('S:')) runClientCalendar();
        else if (bt.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bt.includes('IO')) runCaregiverCalendar();
      }, 2000);
    }, 1500);
  }

  // Hook Go button click directly — most reliable trigger
  function hookCalGoButton() {
    const goBtn = document.getElementById('uxbtnSearch') ||
                  document.getElementById('ctl00_ContentPlaceHolder1_uxBtnGo') ||
                  document.querySelector('input[value="Go"]');
    if (goBtn && !goBtn._ccHooked) {
      goBtn._ccHooked = true;
      goBtn.addEventListener('click', () => setTimeout(rerunCalendar, 1500));
    }
    // Also hook prev/next arrow buttons
    document.querySelectorAll('#btnPrevMonth, #btnNextMonth, input[value="<"], input[value=">"]').forEach(btn => {
      if (!btn._ccHooked) {
        btn._ccHooked = true;
        btn.addEventListener('click', () => setTimeout(rerunCalendar, 1500));
      }
    });

    // Inject "⏱ Hour Counter" button next to Go button
    if (goBtn && !document.getElementById('cc-hour-counter-btn')) {
      const btn = document.createElement('button');
      btn.id = 'cc-hour-counter-btn';
      btn.textContent = '⏱ Hour Counter';
      btn.title = 'Calculate scheduled vs actual hours per caregiver for this month';
      btn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:12px;font-weight:bold;cursor:pointer;margin-left:8px;vertical-align:middle;';
      btn.addEventListener('click', () => {
        // Clean up old injections first
        document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner,.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
        document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
          el.style.removeProperty('outline');
          el.style.removeProperty('background-color');
          el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
        });
        document.querySelectorAll('table').forEach(t => {
          t.style.removeProperty('outline');
          t.style.removeProperty('background-color');
        });
        btn.textContent = '⏳ Calculating...';
        btn.disabled = true;
        setTimeout(() => {
          const bodyText = document.body.innerText;
          const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
          const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
          if (hasClientCal) runClientCalendar();
          else if (hasCaregiverCal) runCaregiverCalendar();
          btn.textContent = '⏱ Hour Counter';
          btn.disabled = false;
        }, 300);
      });
      // Insert right after Go button
      goBtn.parentNode.insertBefore(btn, goBtn.nextSibling);
    }
  }
  hookCalGoButton();
  setTimeout(hookCalGoButton, 2000); // retry after page settles

  // Also watch UpdatePanel for AJAX reloads
  const calObs = new MutationObserver(() => rerunCalendar());
  const updatePanel = document.getElementById('ctl00_ContentPlaceHolder1_UpdatePanel1') ||
                      document.getElementById('ContentPlaceHolder1_UpdatePanel1') ||
                      document.querySelector('[id*="UpdatePanel"]');
  if (updatePanel) {
    calObs.observe(updatePanel, { childList: true, subtree: false });
  }

  // ── Watch for Visit Maintenance page to load (Angular SPA navigation) ──
  let vmCheckTimer = null;
  const spaObs = new MutationObserver(() => {
    clearTimeout(vmCheckTimer);
    vmCheckTimer = setTimeout(() => {
      if (document.querySelector('hhax-visits-filter-result') && !document.getElementById('cc-vm-init')) {
        initVisitMaintenanceScanner();
      }
    }, 1500);
  });
  spaObs.observe(document.body, { childList: true, subtree: false });
}

function detectPageAndRun() {
  const bodyText = document.body.innerText;
  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
  const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
  const isAppointmentsPage  = window.location.href.includes('Appointments_ns.aspx');
  const isMasterWeekPage    = window.location.href.includes('InternalPatientMasterWeekIFrame_ns.aspx');
  const isPatientSearchPage = window.location.href.includes('PatientSearchXSLTIFrame_ns.aspx') || window.location.href.includes('PatientSearch_ns.aspx');
  const isPatientResultsPage = window.location.href.includes('PatientSearchXSLTIFrame_ns.aspx');
  const isCaregiverSearchPage = window.location.href.includes('CaregiverSearch_ns.aspx') || window.location.href.includes('CaregiverSearch.aspx');
  const isPrebillingPage = window.location.href.includes('PrebillingReport');
  const isVisitMaintenancePage = window.location.href.includes('VisitMaintenance') || document.querySelector('hhax-visits-filter-result') !== null;
  const isBatchInvoicePage = window.location.href.includes('BillProcessInternal') || window.location.href.includes('AddInternalBatchInvoice') || !!document.querySelector('.hhax-table-billing-grid');


  // Client-level Master Week auth table
  const mwAuthTable = document.getElementById('uxUclMasterWeek_PatientAuthorizations_uxGvAuthorization');
  if (mwAuthTable && !document.querySelector('.cc-mw-auth-info')) {
    runMasterWeekAuthOverlay();
  }

  if (authTable && !document.querySelector('.cc-auth-info')) {
    runAuthOverlay();
    injectAuthExpiryBanners();
  }
  if (isBatchInvoicePage && !document.getElementById('cc-billing-init')) { initBatchInvoiceOverlay(); return; }
  if (hasClientCal || hasCaregiverCal) {
    // Keep retrying until button appears — timing varies by page
    let attempts = 0;
    const tryInject = () => {
      if (document.getElementById('cc-hour-counter-btn')) return;
      injectHourCounterBtn();
      attempts++;
      if (attempts < 20) setTimeout(tryInject, 500);
    };
    setTimeout(tryInject, 300);
  }
  if (hasClientCal) {
    document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    runClientCalendar();
  } else if (hasCaregiverCal) {
    document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    runCaregiverCalendar();
  }

  // ── For Aide page: watch for calendar to finish loading then auto-run ──
  if (window.location.href.includes('Aide_ns.aspx') && !window._ccAideCalObs) {
    window._ccAideCalObs = true;
    const aideObs = new MutationObserver(() => {
      clearTimeout(window._ccAideCalTimer);
      window._ccAideCalTimer = setTimeout(() => {
        const bt = document.body.innerText;
        const hasCal = !bt.includes('Billed:') && !!bt.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bt.includes('IO');
        if (hasCal && !document.querySelector('.cc-week-hrs-cell')) {
          document.querySelectorAll('.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
          runCaregiverCalendar();
        }
      }, 1500);
    });
    // Watch the calendar table area specifically
    const calArea = document.querySelector('.hhax-main-content, #mainContentRegion, [role="main"]') || document.body;
    aideObs.observe(calArea, { childList: true, subtree: true });
    // Disconnect after 30s to avoid running forever
    setTimeout(() => aideObs.disconnect(), 30000);
  }
  if (isAppointmentsPage) initAppointmentsScanner();
  if (isMasterWeekPage && !document.getElementById('cc-mw-panel')) initMasterWeekScanner();
  if (isPatientSearchPage && !document.getElementById('cc-patient-search-init')) initPatientSearchEnhancements();
  if (isPatientResultsPage && !document.getElementById('cc-results-init')) initPatientSearchResultsPage();
  if (isCaregiverSearchPage && !document.getElementById('cc-cgsearch-init')) initCaregiverSearchScanner();
  if (isPrebillingPage && !document.getElementById('cc-prebilling-init')) initPrebillingEnhancements();
  if (isVisitMaintenancePage && !document.getElementById('cc-vm-init')) initVisitMaintenanceScanner();
}

// ─── UTILITIES ────────────────────────────────────────────────────
function parseDate(str) {
  if (!str) return null;
  const m = str.trim().match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (!m) return null;
  return new Date(parseInt(m[3]), parseInt(m[1]) - 1, parseInt(m[2]));
}

function daysBetween(from, to) {
  if (!from || !to) return null;
  return Math.round((to - from) / 86400000) + 1;
}

function parseHours(str) {
  if (!str) return null;
  const m = str.replace(/,/g, '').match(/([\d.]+)\s*hrs?/i);
  if (m) return parseFloat(m[1]);
  const n = parseFloat(str.replace(/,/g, ''));
  return isNaN(n) ? null : n;
}

function timeToMinutes(t) {
  if (!t) return null;
  const s = t.toString().trim().replace(/\D/g, '').padStart(4, '0');
  if (s.length < 4) return null;
  const h = parseInt(s.substring(0, 2));
  const mn = parseInt(s.substring(2, 4));
  if (isNaN(h) || isNaN(mn)) return null;
  return h * 60 + mn;
}

function parseVisitHours(rangeStr) {
  if (!rangeStr) return null;
  const m = rangeStr.trim().match(/(\d{3,4})\s*[-\u2013]\s*(\d{3,4})/);
  if (!m) return null;
  const start = timeToMinutes(m[1]);
  const end   = timeToMinutes(m[2]);
  if (start === null || end === null) return null;
  let diff = end - start;
  if (diff < 0) diff += 1440;
  return Math.round((diff / 60) * 100) / 100;
}

function parseRangeToInterval(rangeStr) {
  if (!rangeStr) return null;
  const m = rangeStr.trim().match(/(\d{3,4})\s*[-\u2013]\s*(\d{3,4})/);
  if (!m) return null;
  const s = timeToMinutes(m[1]);
  let e = timeToMinutes(m[2]);
  if (s === null || e === null) return null;
  if (e < s) e += 1440;
  return { start: s, end: e };
}

function fmt(n) {
  if (n === null || n === undefined) return 'N/A';
  return parseFloat(n).toFixed(2);
}

function fmtTime(mins) {
  return String(Math.floor(mins / 60)).padStart(2, '0') + String(mins % 60).padStart(2, '0');
}

function getClientName() {
  try {
    const el = window.parent.document.querySelector('[id*="uxLblPatientName"], h1 .headinfo');
    if (el) return el.innerText.trim().split('\n')[0];
  } catch(e) {}
  return 'Unknown Client';
}

// ─── 1. AUTH OVERLAY ─────────────────────────────────────────────
// Global store for auth data so calendar can compare
window._ccAuthData = null;

function runAuthOverlay() {
  document.querySelectorAll('.cc-auth-info').forEach(el => el.remove());
  document.querySelectorAll('.cc-injected').forEach(el => el.remove());

  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  if (!authTable) return;

  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));
  const authData = [];
  const DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const DAY_COLS  = [10,11,12,13,14,15,16];
  const today = new Date(); today.setHours(0,0,0,0);

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 10) return;

    const authNum = cells[1]  ? cells[1].innerText.trim()  : '';
    const fromStr = cells[2]  ? cells[2].innerText.trim()  : '';
    const toStr   = cells[3]  ? cells[3].innerText.trim()  : '';
    const maxStr  = cells[9]  ? cells[9].innerText.trim()  : '';

    const fromDate = parseDate(fromStr);
    const toDate   = parseDate(toStr);
    const maxHrs   = parseHours(maxStr);
    if (!fromDate || !toDate || !maxHrs) return;

    const totalDays        = daysBetween(fromDate, toDate);
    const dailyHrs         = maxHrs / totalDays;
    const weeklyHrs        = dailyHrs * 7;
    const daysRemaining    = Math.max(0, daysBetween(today, toDate));
    const projectedRemain  = daysRemaining * dailyHrs;

    // Inject daily hours under Mon-Sun columns
    DAY_COLS.forEach(ci => {
      if (cells[ci] && !cells[ci].querySelector('.cc-injected')) {
        const div = document.createElement('div');
        div.className = 'cc-injected';
        div.style.cssText = 'color:#00695c;font-size:11px;font-weight:700;font-family:monospace;margin-top:3px;';
        div.textContent = fmt(dailyHrs) + 'h';
        cells[ci].appendChild(div);
      }
    });

    // Replace Remaining Auth cell
    const remCell = cells[17];
    if (remCell) {
      const remColor = projectedRemain <= 0 ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
      const remFlag  = projectedRemain <= 0 ? '🚨 EXHAUSTED' : projectedRemain < maxHrs * 0.15 ? '⚠ LOW' : '✓';
      remCell.innerHTML = `
        <span style="font-weight:700;color:${remColor};">${fmt(projectedRemain)}h ${remFlag}</span>
        <div style="font-size:10px;color:#888;font-family:monospace;">${daysRemaining} days left</div>
      `;
    }

    const infoRow = document.createElement('tr');
    infoRow.className = 'cc-auth-info';
    const td = document.createElement('td');
    td.colSpan = cells.length;
    td.style.cssText = 'background:#e8f5e9;padding:7px 14px;font-family:monospace;font-size:12px;border-bottom:2px solid #81c784;';
    const rc = projectedRemain <= 0 ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
    td.innerHTML = `
      <b style="color:#1b5e20;">⚕ ${authNum}</b> &nbsp;&nbsp;
      <span style="color:#555">${fromStr} – ${toStr} | <b>${totalDays} total days</b></span> &nbsp;&nbsp;
      Daily: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b> &nbsp;&nbsp;
      Weekly: <b style="color:#2e7d32">${fmt(weeklyHrs)}h</b> &nbsp;&nbsp;
      Remaining: <b style="color:${rc}">${fmt(projectedRemain)}h (${daysRemaining} days left)</b>
      <br>
      <span style="color:#777;font-size:11px;">
        ${DAY_NAMES.map(d => `${d}: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b>`).join(' | ')}
      </span>
    `;
    infoRow.appendChild(td);
    row.parentNode.insertBefore(infoRow, row.nextSibling);
    authData.push({ authNum, fromStr, toStr, toDate, totalDays, maxHrs, dailyHrs, weeklyHrs, projectedRemain, daysRemaining });
  });

  if (authData.length > 0) {
    window._ccAuthData = authData; // store globally for calendar mismatch check
    logToSheets({ type: 'auth', clientName: getClientName(), auths: authData });
    saveAuthToBackground(getClientName(), authData);
  }
}

// ─── 2. CLIENT CALENDAR ───────────────────────────────────────────
function parseClientVisitsFromCell(cell) {
  const visits = [];
  const lines = (cell.innerText || '').split('\n').map(l => l.trim()).filter(l => l);

  for (let i = 0; i < lines.length; i++) {
    const sMatch = lines[i].match(/^S:\s*(\d{3,4}[-\u2013]\d{3,4})/);
    if (!sMatch) continue;

    const scheduledRange = sMatch[1];
    const nextLine = lines[i + 1] || '';
    const vMatch = nextLine.match(/^V:\s*(\d{3,4}[-\u2013]\d{3,4})/);
    const visitRange = vMatch ? vMatch[1] : null;

    let dcw = 'Unknown';
    for (let j = i + 2; j < Math.min(i + 8, lines.length); j++) {
      const l = lines[j];
      if (/^[A-Za-z]/.test(l) && !/^(Billed|S:|V:|IO$|Not Auth|Authorized|Partial)/i.test(l) && l.length > 3) {
        dcw = l; break;
      }
    }

    let billed = null;
    for (let j = i + 1; j < Math.min(i + 8, lines.length); j++) {
      const bm = lines[j].match(/Billed:\s*([YN])/i);
      if (bm) { billed = bm[1]; break; }
    }

    const schedInterval = parseRangeToInterval(scheduledRange);
    const visitInterval  = visitRange ? parseRangeToInterval(visitRange) : null;
    const schedHrs = parseVisitHours(scheduledRange);
    const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

    let svDiffMins = 0;
    if (schedInterval && visitInterval) {
      svDiffMins = Math.abs(schedInterval.start - visitInterval.start) +
                   Math.abs(schedInterval.end   - visitInterval.end);
    }

    visits.push({ scheduled: scheduledRange, visit: visitRange, schedHrs, visitHrs, schedInterval, visitInterval, svDiffMins, dcw, billed });
    i += 2;
  }
  return visits;
}


function injectHourCounterBtn() {
  if (document.getElementById('cc-hour-counter-btn')) return true;
  const goBtn = document.getElementById('uxbtnSearch') ||
                document.getElementById('uxBtnCalendarSearch') ||
                document.getElementById('ctl00_ContentPlaceHolder1_uxBtnGo') ||
                document.querySelector('input[value="Go"]');
  if (!goBtn) return false;

  function cleanupCalendar() {
    document.querySelectorAll('.cc-week-hrs-cell,.cc-week-hrs-header,.cc-diff-banner,.cc-overlap-banner,.cc-dup-banner,.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    document.querySelectorAll('table').forEach(t => { t.style.removeProperty('outline'); t.style.removeProperty('background-color'); });
  }

  // Hook prev/next month buttons
  ['btnPrevMonth','btnNextMonth'].forEach(id => {
    const btn = document.getElementById(id);
    if (btn && !btn._ccMonthHooked) {
      btn._ccMonthHooked = true;
      btn.addEventListener('click', () => {
        setTimeout(() => {
          cleanupCalendar();
          const old = document.getElementById('cc-hour-counter-btn');
          if (old) old.remove();
          setTimeout(injectHourCounterBtn, 800);
        }, 1500);
      });
    }
  });

  // Hook Go button for month change cleanup
  if (!goBtn._ccGoHooked) {
    goBtn._ccGoHooked = true;
    goBtn.addEventListener('click', () => setTimeout(cleanupCalendar, 1500));
  }

  const hcBtn = document.createElement('button');
  hcBtn.id = 'cc-hour-counter-btn';
  hcBtn.type = 'button';
  hcBtn.textContent = '⏱ Hour Counter';
  hcBtn.title = 'Calculate scheduled vs actual hours per caregiver for this month';
  hcBtn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:12px;font-weight:bold;cursor:pointer;margin-left:8px;vertical-align:middle;';

  hcBtn.addEventListener('click', () => {
    cleanupCalendar();
    hcBtn.textContent = '⏳ Calculating...';
    hcBtn.disabled = true;
    setTimeout(() => {
      const bodyText = document.body.innerText;
      const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
      const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
      if (hasClientCal) runClientCalendar();
      else if (hasCaregiverCal) runCaregiverCalendar();
      hcBtn.textContent = '⏱ Hour Counter';
      hcBtn.disabled = false;
    }, 300);
  });

  goBtn.parentNode.insertBefore(hcBtn, goBtn.nextSibling);
  return true;
}

function runClientCalendar() {
  injectHourCounterBtn();
  // Clean up previous
  document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
  document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
    el.style.removeProperty('outline');
    el.style.removeProperty('background-color');
    el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
  });

  // Find all calendar day cells
  const allTds = [...document.querySelectorAll('td')];
  const dayCells = [];

  allTds.forEach(td => {
    const text = td.innerText || '';
    if (!text.includes('Billed:') || !text.includes('S:')) return;
    const lines = text.split('\n').map(l => l.trim()).filter(l => l);
    const dayNum = parseInt(lines[0]);
    if (isNaN(dayNum) || dayNum < 1 || dayNum > 31) return;
    const visits = parseClientVisitsFromCell(td);
    if (visits.length > 0) dayCells.push({ dayNum, td, visits });
  });

  if (dayCells.length === 0) return;

  // Run duplicate visit check
  document.querySelectorAll('.cc-dup-banner').forEach(el => el.remove());
  runDuplicateVisitCheck(dayCells);
  dayCells.forEach(({ dayNum, td, visits }) => {
    let hasOverlap = false;
    let hasDiff = false;
    const overlapDetails = [];
    const diffDetails = [];

    visits.forEach(v => {
      if (v.svDiffMins > 15) {
        hasDiff = true;
        diffDetails.push(`${v.dcw}: S=${v.scheduled} V=${v.visit||'N/A'} (${v.svDiffMins}min diff)`);
      }
    });

    const intervals = [];
    visits.forEach(v => {
      if (v.schedInterval) intervals.push({ ...v.schedInterval, dcw: v.dcw, type: 'S' });
      if (v.visitInterval) intervals.push({ ...v.visitInterval, dcw: v.dcw, type: 'V' });
    });

    for (let i = 0; i < intervals.length; i++) {
      for (let j = i + 1; j < intervals.length; j++) {
        const a = intervals[i], b = intervals[j];
        if (a.dcw === b.dcw) continue;
        const oStart = Math.max(a.start, b.start);
        const oEnd   = Math.min(a.end, b.end);
        if (oEnd - oStart >= 8) {
          hasOverlap = true;
          overlapDetails.push(`🚨 ${fmtTime(oStart)}–${fmtTime(oEnd)} (${oEnd-oStart}min)\n${a.dcw} & ${b.dcw} [${a.type}+${b.type}]`);
        }
      }
    }

    if (hasOverlap) {
      td.style.setProperty('outline','3px solid #c62828','important');
      td.style.setProperty('background-color','rgba(198,40,40,0.10)','important');
      td.classList.add('cc-overlap-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-overlap-banner';
      banner.style.cssText = 'background:#c62828;color:white;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = overlapDetails.join('\n\n');
      td.appendChild(banner);
      logToSheets({ type: 'overlap', clientName: getClientName(), dayNum, overlaps: overlapDetails });
      saveOverlapToBackground(getClientName(), dayNum, overlapDetails.join(' | '));
    } else if (hasDiff) {
      td.style.setProperty('outline','3px solid #f9a825','important');
      td.style.setProperty('background-color','rgba(249,168,37,0.12)','important');
      td.classList.add('cc-diff-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-diff-banner';
      banner.style.cssText = 'background:#f9a825;color:#333;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = '⚠ SCHED DIFF >15MIN\n' + diffDetails.join('\n');
      td.appendChild(banner);
    }
  });

  // ── Build weekly hours column ──────────────────────────────────
  // Find the calendar table — it has week rows (tr) with day cells (td)
  // Group dayCells by the table row they belong to
  const calTable = dayCells[0]?.td?.closest('table');
  if (!calTable) return;

  // Add header cell to header row
  const headerRow = calTable.querySelector('tr');
  if (headerRow && !headerRow.querySelector('.cc-week-hrs-header')) {
    const th = document.createElement('th');
    th.className = 'cc-week-hrs-header';
    th.style.cssText = `
      background:#002447; color:white; font-size:11px;
      font-family:monospace; padding:6px 8px;
      text-align:left; white-space:nowrap;
      border-left:2px solid #4caf50; min-width:140px;
    `;
    th.textContent = 'CC Hours';
    headerRow.appendChild(th);
  }

  // Group day cells by their parent tr (week row)
  const rowMap = new Map();
  dayCells.forEach(({ td, visits }) => {
    const tr = td.parentElement;
    if (!tr) return;
    if (!rowMap.has(tr)) rowMap.set(tr, []);
    rowMap.get(tr).push(...visits);
  });

  // For each week row, calculate per-DCW sched/visit/diff and inject a td
  rowMap.forEach((visits, tr) => {
    if (tr.querySelector('.cc-week-hrs-cell')) return;

    // Aggregate by DCW
    const byDCW = {};
    visits.forEach(v => {
      const dcw = v.dcw || 'Unknown';
      if (!byDCW[dcw]) byDCW[dcw] = { sched: 0, visit: 0 };
      byDCW[dcw].sched += v.schedHrs || 0;
      byDCW[dcw].visit += v.visitHrs || 0;
    });

    const td = document.createElement('td');
    td.className = 'cc-week-hrs-cell';
    td.style.cssText = `
      vertical-align: top;
      border-left: 2px solid #4caf50;
      padding: 6px 8px;
      background: #f1f8f1;
      font-family: monospace;
      font-size: 11px;
      min-width: 140px;
    `;

    let html = '';
    Object.entries(byDCW).forEach(([dcw, hrs]) => {
      const diff = hrs.visit - hrs.sched;
      const diffColor = diff < -0.25 ? '#c62828' : diff > 0.25 ? '#1565c0' : '#2e7d32';
      const diffSign  = diff >= 0 ? '+' : '';
      html += `
        <div style="margin-bottom:8px;border-bottom:1px solid #c8e6c9;padding-bottom:6px;">
          <div style="font-weight:700;color:#1b5e20;font-size:11px;margin-bottom:3px;">${dcw}</div>
          <div style="color:#555;">Sched: <b>${fmt(hrs.sched)}h</b></div>
          <div style="color:#555;">Visit: <b>${fmt(hrs.visit)}h</b></div>
          <div style="color:${diffColor};">Diff: <b>${diffSign}${fmt(diff)}h</b></div>
        </div>
      `;
    });

    // Week total
    const totalSched = Object.values(byDCW).reduce((s, v) => s + v.sched, 0);
    const totalVisit = Object.values(byDCW).reduce((s, v) => s + v.visit, 0);
    const totalDiff  = totalVisit - totalSched;
    const totalDiffColor = totalDiff < -0.25 ? '#c62828' : totalDiff > 0.25 ? '#1565c0' : '#2e7d32';
    const totalDiffSign  = totalDiff >= 0 ? '+' : '';

    html += `
      <div style="background:#1b5e20;color:white;border-radius:4px;padding:4px 6px;margin-top:4px;">
        <div style="font-size:10px;color:#a5d6a7;">WEEK TOTAL</div>
        <div>S: <b>${fmt(totalSched)}h</b></div>
        <div>V: <b>${fmt(totalVisit)}h</b></div>
        <div style="color:${totalDiff < -0.25 ? '#ff8a80' : totalDiff > 0.25 ? '#82b1ff' : '#b9f6ca'};">
          Diff: <b>${totalDiffSign}${fmt(totalDiff)}h</b>
        </div>
      </div>
    `;

    td.innerHTML = html;
    tr.appendChild(td);
  });

  // Log hours
  const clientName = getClientName();
  const allByDCW = {};
  dayCells.forEach(({ visits }) => {
    visits.forEach(v => {
      const dcw = v.dcw || 'Unknown';
      if (!allByDCW[dcw]) allByDCW[dcw] = { sched: 0, visit: 0 };
      allByDCW[dcw].sched += v.schedHrs || 0;
      allByDCW[dcw].visit += v.visitHrs || 0;
    });
  });
  const rows = Object.entries(allByDCW).map(([dcw, hrs]) => ({
    clientName, dcw, schedHours: hrs.sched, visitHours: hrs.visit, diff: hrs.visit - hrs.sched
  }));
  if (rows.length > 0) logToSheets({ type: 'hours', data: rows });

  // ── Auth vs Scheduled mismatch — color entire calendar table ──
  checkCalendarAuthMismatch(calTable, dayCells);
}

function checkCalendarAuthMismatch(calTable, dayCells) {
  if (!calTable || !dayCells || dayCells.length === 0) return;

  document.querySelectorAll('.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
  calTable.style.removeProperty('outline');
  calTable.style.removeProperty('background-color');

  // Read A: and S: directly from HHAeXchange DOM summary row
  let authHrsFromDOM = null, schedHrsFromDOM = null;
  const calRows = [...calTable.querySelectorAll('tr')].slice(-3);
  calRows.forEach(row => {
    const txt = row.innerText || '';
    if (txt.includes('A:') && txt.includes('S:')) {
      const am = txt.match(/A:\s*([\d:]+)/);
      const sm = txt.match(/S:\s*([\d:]+)/);
      if (am && !authHrsFromDOM)  authHrsFromDOM  = parseHHMM(am[1]);
      if (sm && !schedHrsFromDOM) schedHrsFromDOM = parseHHMM(sm[1]);

      // Highlight the summary row if over/under
      if (authHrsFromDOM && schedHrsFromDOM) {
        const isOver  = schedHrsFromDOM > authHrsFromDOM + 0.1;
        const isUnder = schedHrsFromDOM < authHrsFromDOM - 0.1;
        if (isOver || isUnder) {
          row.style.setProperty('background-color', 'rgba(255,140,0,0.25)', 'important');
          row.style.setProperty('outline', '2px solid #ff8c00', 'important');
          const flag = document.createElement('span');
          flag.className = 'cc-auth-row-flag';
          flag.style.cssText = 'display:inline-block;background:#ff8c00;color:#000;font-size:9px;font-weight:900;padding:2px 7px;border-radius:3px;margin-left:8px;letter-spacing:1px;font-family:monospace;';
          flag.textContent = isOver ? 'OVER USED AUTH' : 'UNDER USED AUTH';
          row.appendChild(flag);
        }
      }
    }
  });

  // Fallback to computed values
  let totalSchedHrs = schedHrsFromDOM;
  let monthlyAuthHrs = authHrsFromDOM;

  if (!totalSchedHrs) {
    totalSchedHrs = 0;
    dayCells.forEach(({ visits }) => { visits.forEach(v => { totalSchedHrs += v.schedHrs || 0; }); });
  }

  if (!monthlyAuthHrs) {
    const authArr = window._ccAuthData;
    if (!authArr || authArr.length === 0) return;
    const today = new Date(); today.setHours(0,0,0,0);
    let auth = authArr.find(a => a.toDate >= today) || authArr[0];
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth()+1, 0).getDate();
    monthlyAuthHrs = auth.dailyHrs * daysInMonth;
  }

  if (!monthlyAuthHrs || monthlyAuthHrs === 0) return;

  const diff = Math.abs(totalSchedHrs - monthlyAuthHrs);
  if (diff < 0.1) return;

  const isOver = totalSchedHrs > monthlyAuthHrs;
  const authLabel = isOver ? 'OVER USED AUTH' : 'UNDER USED AUTH';

  // Light orange for both over and under
  calTable.style.setProperty('outline', '3px solid #ff8c00', 'important');
  calTable.style.setProperty('background-color', 'rgba(255,140,0,0.06)', 'important');

  // Banner above table
  const banner = document.createElement('div');
  banner.className = 'cc-auth-mismatch-banner';
  banner.style.cssText = 'background:#ff8c00;color:#000;font-family:monospace;font-size:12px;font-weight:900;padding:8px 14px;border-radius:4px 4px 0 0;letter-spacing:1px;';
  banner.textContent = `⚠ ${authLabel}: Scheduled ${fmt(totalSchedHrs)}h vs Auth ${fmt(monthlyAuthHrs)}h (${isOver?'+':'-'}${fmt(diff)}h)`;
  calTable.parentNode.insertBefore(banner, calTable);

  // Add to floater
  window._ccAuthFlag = { label: authLabel, isOver, totalSchedHrs, monthlyAuthHrs, diff };
}

// ─── 3. CAREGIVER CALENDAR ────────────────────────────────────────
function parseCaregiverVisitsFromCell(cell) {
  const visits = [];
  const lines = (cell.innerText || '').split('\n').map(l => l.trim()).filter(l => l);

  let i = 0;
  while (i < lines.length) {
    const schedMatch = lines[i].match(/^(\d{4})\s*[-\u2013]\s*(\d{4})$/);
    if (!schedMatch) { i++; continue; }

    const scheduledRange = lines[i].replace(/\s/g,'');
    const nextLine = lines[i+1] || '';
    const visitMatch = nextLine.match(/^(\d{4})\s*[-\u2013]\s*(\d{4})$/);
    const visitRange = visitMatch ? nextLine.replace(/\s/g,'') : null;

    let clientName = 'Unknown';
    const searchFrom = visitMatch ? i + 2 : i + 1;
    for (let j = searchFrom; j < Math.min(searchFrom + 5, lines.length); j++) {
      const l = lines[j];
      if (/^[A-Za-z]/.test(l) && !/^(IO|DF|B$)/i.test(l) && l.length > 2) {
        clientName = l; break;
      }
    }

    const schedInterval = parseRangeToInterval(scheduledRange);
    const visitInterval  = visitRange ? parseRangeToInterval(visitRange) : null;
    const schedHrs = parseVisitHours(scheduledRange);
    const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

    let svDiffMins = 0;
    if (schedInterval && visitInterval) {
      svDiffMins = Math.abs(schedInterval.start - visitInterval.start) +
                   Math.abs(schedInterval.end - visitInterval.end);
    }

    visits.push({ scheduled: scheduledRange, visit: visitRange, schedHrs, visitHrs, schedInterval, visitInterval, svDiffMins, clientName });
    i = visitMatch ? i + 2 : i + 1;
  }
  return visits;
}

function runCaregiverCalendar() {
  injectHourCounterBtn();
  document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
  document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
    el.style.removeProperty('outline');
    el.style.removeProperty('background-color');
    el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
  });

  const allTds = [...document.querySelectorAll('td')];
  const dayCells = [];

  allTds.forEach(td => {
    const text = td.innerText || '';
    if (!text.match(/\d{4}\s*[-\u2013]\s*\d{4}/)) return;
    const lines = text.split('\n').map(l => l.trim()).filter(l => l);
    // Day number can be in first few lines (not necessarily line 0)
    let dayNum = NaN;
    for (let k = 0; k < Math.min(4, lines.length); k++) {
      const n = parseInt(lines[k]);
      if (!isNaN(n) && n >= 1 && n <= 31 && lines[k].match(/^\d{1,2}$/)) { dayNum = n; break; }
    }
    if (isNaN(dayNum)) return;
    const visits = parseCaregiverVisitsFromCell(td);
    if (visits.length > 0) dayCells.push({ dayNum, td, visits });
  });

  if (dayCells.length === 0) return;

  // Only show diff highlights on caregiver calendar — no overlap detection
  dayCells.forEach(({ dayNum, td, visits }) => {
    let hasDiff = false;
    const diffDetails = [];

    visits.forEach(v => {
      if (v.svDiffMins > 15) {
        hasDiff = true;
        diffDetails.push(`${v.clientName}: S=${v.scheduled} V=${v.visit||'N/A'} (${v.svDiffMins}min)`);
      }
    });

    if (hasDiff) {
      td.style.setProperty('outline','3px solid #f9a825','important');
      td.style.setProperty('background-color','rgba(249,168,37,0.12)','important');
      td.classList.add('cc-diff-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-diff-banner';
      banner.style.cssText = 'background:#f9a825;color:#333;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = '⚠ SCHED DIFF >15MIN\n' + diffDetails.join('\n');
      td.appendChild(banner);
    }
  });

  // ── Weekly hours column for caregiver calendar ─────────────────
  const calTable = dayCells[0]?.td?.closest('table');
  if (!calTable) return;

  const headerRow = calTable.querySelector('tr');
  if (headerRow && !headerRow.querySelector('.cc-week-hrs-header')) {
    const th = document.createElement('th');
    th.className = 'cc-week-hrs-header';
    th.style.cssText = 'background:#002447;color:white;font-size:11px;font-family:monospace;padding:6px 8px;text-align:left;white-space:nowrap;border-left:2px solid #4caf50;min-width:160px;';
    th.textContent = 'CC Hours';
    headerRow.appendChild(th);
  }

  const rowMap = new Map();
  dayCells.forEach(({ td, visits }) => {
    const tr = td.parentElement;
    if (!tr) return;
    if (!rowMap.has(tr)) rowMap.set(tr, []);
    rowMap.get(tr).push(...visits);
  });

  rowMap.forEach((visits, tr) => {
    if (tr.querySelector('.cc-week-hrs-cell')) return;

    // Aggregate by client
    const byClient = {};
    visits.forEach(v => {
      const c = v.clientName || 'Unknown';
      if (!byClient[c]) byClient[c] = { sched: 0, visit: 0 };
      byClient[c].sched += v.schedHrs || 0;
      byClient[c].visit += v.visitHrs || 0;
    });

    const td = document.createElement('td');
    td.className = 'cc-week-hrs-cell';
    td.style.cssText = 'vertical-align:top;border-left:2px solid #4caf50;padding:6px 8px;background:#f1f8f1;font-family:monospace;font-size:11px;min-width:160px;';

    let html = '';
    Object.entries(byClient).forEach(([client, hrs]) => {
      const diff = hrs.visit - hrs.sched;
      const diffColor = diff < -0.25 ? '#c62828' : diff > 0.25 ? '#1565c0' : '#2e7d32';
      const diffSign  = diff >= 0 ? '+' : '';
      html += `
        <div style="margin-bottom:8px;border-bottom:1px solid #c8e6c9;padding-bottom:6px;">
          <div style="font-weight:700;color:#1b5e20;font-size:10px;margin-bottom:3px;">${client}</div>
          <div style="color:#555;">Sched: <b>${fmt(hrs.sched)}h</b></div>
          <div style="color:#555;">Visit: <b>${fmt(hrs.visit)}h</b></div>
          <div style="color:${diffColor};">Diff: <b>${diffSign}${fmt(diff)}h</b></div>
        </div>
      `;
    });

    const totalSched = Object.values(byClient).reduce((s, v) => s + v.sched, 0);
    const totalVisit = Object.values(byClient).reduce((s, v) => s + v.visit, 0);
    const totalDiff  = totalVisit - totalSched;
    const totalDiffSign = totalDiff >= 0 ? '+' : '';

    html += `
      <div style="background:#1b5e20;color:white;border-radius:4px;padding:4px 6px;margin-top:4px;">
        <div style="font-size:10px;color:#a5d6a7;">WEEK TOTAL</div>
        <div>S: <b>${fmt(totalSched)}h</b></div>
        <div>V: <b>${fmt(totalVisit)}h</b></div>
        <div style="color:${totalDiff < -0.25 ? '#ff8a80' : totalDiff > 0.25 ? '#82b1ff' : '#b9f6ca'};">
          Diff: <b>${totalDiffSign}${fmt(totalDiff)}h</b>
        </div>
      </div>
    `;

    td.innerHTML = html;
    tr.appendChild(td);
  });
}

// ─── GOOGLE SHEETS LOGGER ─────────────────────────────────────────
function logToSheets(data) {
  var SHEETS_URL = 'https://script.google.com/macros/s/AKfycbyM8t-5uJyMq8k2qvRNsW0_enmvi1ICv1gWuxwIST8oQogB8XhtoRljIx-gqD45Usl-rA/exec';
  fetch(SHEETS_URL, {
    method: 'POST', mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...data, timestamp: new Date().toISOString() })
  }).catch(() => {});
}

// ─── SAVE AUTH TO BACKGROUND (for expiry alerts) ──────────────────
function saveAuthToBackground(clientName, auths) {
  const payload = auths.map(a => ({
    clientName,
    authNum:    a.authNum,
    toDate:     a.toDate ? a.toDate.toISOString() : null,
    toDateStr:  a.toStr,
    fromDateStr: a.fromStr,
    dailyHrs:   a.dailyHrs,
    weeklyHrs:  a.weeklyHrs,
    maxHrs:     a.maxHrs,
    daysRemaining: a.daysRemaining
  }));
  try {
    chrome.runtime.sendMessage({ action: 'saveAuth', auths: payload });
  } catch(e) {}
}

// ─── SAVE OVERLAP TO BACKGROUND ───────────────────────────────────
function saveOverlapToBackground(clientName, dayNum, detail) {
  try {
    chrome.runtime.sendMessage({ action: 'saveOverlap', overlap: { clientName, dayNum, detail } });
  } catch(e) {}
}

// ─── VISIT FREQUENCY vs AUTH ALERT ───────────────────────────────
function runVisitFrequencyCheck(dayCells, authData) {
  if (!authData || authData.length === 0 || dayCells.length === 0) return;

  const activeAuth = authData.find(a => a.daysRemaining > 0) || authData[0];
  if (!activeAuth) return;

  // Count actual visit days
  const visitDays = dayCells.filter(d => d.visits.some(v => v.visitHrs > 0)).length;
  const totalDays  = dayCells.length;
  const visitRate  = visitDays / totalDays; // e.g. 0.71 = 5/7 days

  // Auth allows dailyHrs every day — if visitRate is significantly lower, flag it
  const expectedVisitDays = Math.round(totalDays * (activeAuth.weeklyHrs / (activeAuth.dailyHrs * 7)));
  const missedDays = Math.max(0, expectedVisitDays - visitDays);

  if (missedDays >= 2) {
    // Inject alert banner below auth table
    const existing = document.getElementById('cc-freq-alert');
    if (existing) existing.remove();

    const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
    if (!authTable) return;

    const alert = document.createElement('div');
    alert.id = 'cc-freq-alert';
    alert.style.cssText = `
      background:#fff3e0; border:2px solid #f57c00; border-radius:6px;
      padding:10px 14px; margin:8px 0; font-family:monospace; font-size:12px;
      color:#e65100;
    `;
    alert.innerHTML = `
      <b>⚠ Visit Frequency Alert</b><br>
      <span style="color:#555;">
        Auth allows <b style="color:#2e7d32">${activeAuth.dailyHrs ? activeAuth.dailyHrs.toFixed(2) : 'N/A'}h/day</b> —
        Client visited <b>${visitDays}</b> of <b>${totalDays}</b> calendar days shown.<br>
        Estimated <b style="color:#c62828">${missedDays} missed visit day(s)</b> based on authorization schedule.
      </span>
    `;
    authTable.parentNode.insertBefore(alert, authTable.nextSibling);
  }
}


// ─── AUTH EXPIRY BANNER ON CLIENT PAGE ───────────────────────────
function injectAuthExpiryBanners() {
  document.querySelectorAll('.cc-expiry-banner').forEach(el => el.remove());

  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  if (!authTable) return;

  const today = new Date(); today.setHours(0,0,0,0);
  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 4) return;
    const toStr  = cells[3] ? cells[3].innerText.trim() : '';
    const authNum = cells[1] ? cells[1].innerText.trim() : '';
    const toDate = parseDate(toStr);
    if (!toDate) return;

    const daysLeft = Math.ceil((toDate - today) / 86400000);
    if (daysLeft > 30) return;

    const color   = daysLeft <= 7  ? '#c62828' : daysLeft <= 15 ? '#e65100' : '#1565c0';
    const bgColor = daysLeft <= 7  ? '#ffebee' : daysLeft <= 15 ? '#fff3e0' : '#e3f2fd';
    const icon    = daysLeft <= 7  ? '🚨' : daysLeft <= 15 ? '⚠' : 'ℹ';
    const label   = daysLeft <= 0  ? 'EXPIRED' : `${daysLeft} days left`;

    const banner = document.createElement('div');
    banner.className = 'cc-expiry-banner';
    banner.style.cssText = `
      background:${bgColor}; border-left:4px solid ${color};
      padding:5px 10px; font-family:monospace; font-size:11px;
      color:${color}; font-weight:700; margin-top:3px; border-radius:0 4px 4px 0;
    `;
    banner.textContent = `${icon} Auth ${authNum} — ${label} (expires ${toStr})`;

    const nextRow = row.nextSibling;
    if (nextRow && nextRow.classList && nextRow.classList.contains('cc-auth-info')) {
      nextRow.parentNode.insertBefore(banner, nextRow.nextSibling);
    } else {
      row.parentNode.insertBefore(banner, row.nextSibling);
    }
  });
}

// ─── DUPLICATE VISIT DETECTOR ─────────────────────────────────────
function runDuplicateVisitCheck(dayCells) {
  const duplicates = [];

  dayCells.forEach(({ dayNum, td, visits }) => {
    // Check if same DCW appears more than once on same day
    const dcwCounts = {};
    visits.forEach(v => {
      dcwCounts[v.dcw] = (dcwCounts[v.dcw] || 0) + 1;
    });

    Object.entries(dcwCounts).forEach(([dcw, count]) => {
      if (count > 1) {
        duplicates.push({ dayNum, dcw, count });
        // Highlight with orange outline
        td.style.setProperty('outline', '3px solid #ff6f00', 'important');
        const banner = document.createElement('div');
        banner.className = 'cc-dup-banner';
        banner.style.cssText = 'background:#ff6f00;color:white;font-family:monospace;font-size:10px;font-weight:700;padding:3px 7px;border-radius:3px;margin-top:4px;';
        banner.textContent = `⚠ DUPLICATE: ${dcw} scheduled ${count}x on day ${dayNum}`;
        td.appendChild(banner);
      }
    });
  });

  return duplicates;
}


// ─── POPUP SCAN HELPERS ───────────────────────────────────────────
function runEVVScan() {
  const rows = document.querySelectorAll('table tr');
  let missing = 0, gps = 0, total = 0;
  rows.forEach(r => { const t = r.innerText; if (!t.trim()) return; total++; if (/missing.*check|no.*check/i.test(t)) missing++; if (/gps.*fail|evv.*fail/i.test(t)) gps++; });
  if (total === 0) return [{ type:'info', icon:'ℹ', text:'Navigate to a visit list page', sub:'' }];
  const res = [{ type:'info', icon:'ℹ', text:`Scanned ${total} rows`, sub:'' }];
  if (missing > 0) res.push({ type:'danger', icon:'🚨', text:`${missing} missing check-in/out`, sub:'EVV compliance risk' });
  if (gps > 0) res.push({ type:'warn', icon:'⚠', text:`${gps} GPS flag(s)`, sub:'' });
  if (missing === 0 && gps === 0) res.push({ type:'success', icon:'✓', text:'No EVV issues detected', sub:'' });
  return res;
}

function runClaimScan() {
  const t = document.body.innerText;
  const denied = (t.match(/denied|rejected/gi)||[]).length;
  const pending = (t.match(/pending|submitted/gi)||[]).length;
  const paid = (t.match(/approved|paid/gi)||[]).length;
  const res = [];
  if (paid > 0)    res.push({ type:'success', icon:'✓',  text:`~${paid} approved/paid`, sub:'' });
  if (pending > 0) res.push({ type:'warn',    icon:'⏳', text:`~${pending} pending`, sub:'Follow up if >30 days' });
  if (denied > 0)  res.push({ type:'danger',  icon:'🚨', text:`~${denied} denied`, sub:'Action required' });
  if (res.length === 0) res.push({ type:'info', icon:'ℹ', text:'Navigate to billing page', sub:'' });
  return res;
}

function runMissedScan() {
  const t = document.body.innerText;
  const missed = (t.match(/missed|no.?show/gi)||[]).length;
  if (missed > 0) return [{ type:'danger', icon:'🚨', text:`${missed} missed/no-show mention(s)`, sub:'Review immediately' }];
  return [{ type:'success', icon:'✓', text:'No missed visits detected', sub:'' }];
}

// ─── APPOINTMENTS PAGE SCANNER ────────────────────────────────────

// ─── DISMISS STORAGE HELPERS ──────────────────────────────────────
function getDismissedKeys() {
  try {
    return JSON.parse(localStorage.getItem('_cc_dismissed') || '{}');
  } catch(e) { return {}; }
}
function isDismissed(key) {
  return !!getDismissedKeys()[key];
}
function dismissCard(key) {
  const dismissed = getDismissedKeys();
  dismissed[key] = true;
  localStorage.setItem('_cc_dismissed', JSON.stringify(dismissed));
}
function clearDismissed() {
  localStorage.removeItem('_cc_dismissed');
}
function makeDismissKey(type, ...parts) {
  return type + '_' + parts.map(p => String(p||'').replace(/\W+/g,'')).join('_');
}

let apptScannerActive = false;
let apptObserver = null;

function initAppointmentsScanner() {
  if (apptScannerActive) return;
  apptScannerActive = true;

  // Watch both grid containers for content to load
  const targets = ['divPatientCalendarGrid-container', 'divCaregiverCalendarGrid-container'];

  targets.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;

    const obs = new MutationObserver(() => {
      // Debounce: wait for grid to finish rendering
      clearTimeout(el._ccScanTimer);
      el._ccScanTimer = setTimeout(() => {
        if (el.children.length > 0) {
          // Only scan if panel doesn't exist yet — don't wipe it if minimized
          if (!document.getElementById('cc-appt-panel')) {
            runAppointmentsOverlapScan();
          }
          injectApptRememberBtn();
        }
      }, 1500);
    });

    obs.observe(el, { childList: true, subtree: true });
  });

  // Also hook the Search button click
  const searchBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnSearch');
  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      // Remove old panel and clear old highlights when new search starts
      const old = document.getElementById('cc-appt-panel');
      if (old) old.remove();
      // Clear any old red highlights
      document.querySelectorAll('.cg-visit-item').forEach(b => {
        b.style.removeProperty('outline');
        b.style.removeProperty('background');
      });
    });
  }
}

function runAppointmentsOverlapScan() {
  // Remove old panel
  const old = document.getElementById('cc-appt-panel');
  if (old) old.remove();

  // Determine which view is active
  const patientGrid = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');

  let results = { overlaps: [], hourDiffs: [], totalVisits: 0 };

  if (patientGrid && patientGrid.children.length > 0) {
    results = scanPatientGrid(patientGrid);
  } else if (caregiverGrid && caregiverGrid.children.length > 0) {
    results = scanCaregiverGrid(caregiverGrid);
  } else {
    return;
  }

  injectApptPanel({ overlaps: results.overlaps, hourDiffs: results.hourDiffs, totalVisits: results.totalVisits, panelId: 'cc-appt-panel', title: '⚕ Care Crafter — Schedule Scan' });

  // Inject remember button into panel footer
  const footer = document.getElementById('cc-appt-panel-footer');
  if (footer && !footer.querySelector('#cc-appt-remember-btn')) {
    const remBtn = document.createElement('button');
    remBtn.id = 'cc-appt-remember-btn';
    remBtn.textContent = '💾 Remember';
    remBtn.title = 'Scan all visits and save to billing memory — used to flag unconfirmed visits on the Add Internal Batch Invoice page';
    remBtn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;font-weight:bold;';
    remBtn.addEventListener('click', () => {
      const statusLbl = document.getElementById('cc-appt-remember-status') || document.createElement('span');
      scanApptAndRemember(remBtn, statusLbl);
    });
    // Status label next to button
    const statusLbl = document.createElement('span');
    statusLbl.id = 'cc-appt-remember-status';
    statusLbl.style.cssText = 'font-size:10px;color:#888;margin-right:8px;';
    chrome.storage.local.get(['_cc_billing_memory'], r => {
      if (r._cc_billing_memory) {
        const d = r._cc_billing_memory;
        const unconf = d.visits.filter(v => !v.isConfirmed).length;
        statusLbl.textContent = `Saved ${new Date(d.savedAt).toLocaleDateString()} · ${unconf} unconf`;
        statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
      }
    });
    footer.insertBefore(statusLbl, footer.firstChild);
    footer.insertBefore(remBtn, footer.firstChild);
  }
}

function extractVisitData(block) {
  // Real HHAeXchange Appointments page structure (confirmed from actual HTML):
  //
  // div.cg-container-wrap
  //   div.cg-container
  //     div.cg-row-container[data-row-id="19786141"]
  //       div.cg-info-cell
  //         div.cg-patient-cell[data-patient-id="19786141"]
  //           a.cg-word-break-string => "ABDUL HAMEED, AMAL\n(FNE-900042)"
  //       div[data-date-value="4/27/2026"].cg-calendar-cell   ← DATE IS HERE
  //         div.cg-visit-cell
  //           div.cg-visit-item[data-visit-id][data-scheduledminute]
  //             a[data-event-type="visit"] => "S:1700 - 2200 (PCA)"
  //             span.cg-visit-span  → V:<span.cg-visit-evv>1656</span> - <span.cg-visit-evv>2159</span>
  //             div[data-visittotal-id] => "S:05:00  C:05:03"
  //             div[data-caregiver-id] span.cg-text-link => "SALIH, YASIR"

  const visitId = block.getAttribute('data-visit-id') || '';

  // ── Scheduled time from <a data-event-type="visit"> ──────────────
  let schedRange = null;
  const schedLink = block.querySelector('a[data-event-type="visit"]');
  if (schedLink) {
    const txt = schedLink.textContent.trim();
    const m = txt.match(/S:\s*(\d{3,4})\s*[-–]\s*(\d{3,4})/i);
    if (m) schedRange = m[1] + '-' + m[2];
  }

  // ── Actual visit time from span.cg-visit-span → .cg-visit-evv spans ──
  let visitRange = null;
  const visitSpan = block.querySelector('.cg-visit-span');
  if (visitSpan) {
    const evvSpans = visitSpan.querySelectorAll('.cg-visit-evv');
    if (evvSpans.length >= 2) {
      const t1 = evvSpans[0].textContent.trim();
      const t2 = evvSpans[1].textContent.trim();
      if (t1 && t2) visitRange = t1 + '-' + t2;
    } else {
      const txt = visitSpan.textContent.trim();
      const m = txt.match(/V:\s*(\d{3,4})\s*[-–]\s*(\d{3,4})/i);
      if (m) visitRange = m[1] + '-' + m[2];
    }
  }

  // ── Caregiver name AND ID from [data-caregiver-id] span.cg-text-link ────
  let caregiverName = null;
  let caregiverId = null;
  const cgDiv = block.querySelector('[data-caregiver-id]');
  if (cgDiv) {
    caregiverId = cgDiv.getAttribute('data-caregiver-id');
    const cgEl = cgDiv.querySelector('.cg-text-link, span');
    if (cgEl) caregiverName = cgEl.textContent.trim();
  }

  // ── Scheduled vs confirmed hours from [data-visittotal-id] ───────
  // Format: "S:05:00  C:05:03"
  let schedHrs = null, confirmedHrs = null;
  const totalEl = block.querySelector('[data-visittotal-id]');
  if (totalEl) {
    const txt = totalEl.textContent.trim();
    const sm = txt.match(/S:([\d:]+)/);
    const cm = txt.match(/C:([\d:]+)/);
    if (sm) schedHrs = parseHHMM(sm[1]);
    if (cm) confirmedHrs = parseHHMM(cm[1]);
  }

  // ── Date: from parent div.cg-calendar-cell[data-date-value] ──────
  // The structure is NOT a <table>. It is:
  //   div.cg-row-container > div.cg-calendar-cell[data-date-value="4/27/2026"] > div.cg-visit-cell > div.cg-visit-item
  // We walk up: block → cg-visit-cell → cg-calendar-cell → data-date-value
  let dateStr = null;
  try {
    const visitCell = block.closest('.cg-visit-cell');
    const calCell = visitCell ? visitCell.closest('[data-date-value]') : null;
    if (calCell) dateStr = calCell.getAttribute('data-date-value');
  } catch(e) {}

  // ── Client name: from sibling cg-info-cell in the same cg-row-container ──
  // Walk up to cg-row-container, then find cg-patient-cell inside cg-info-cell
  let clientName = null;
  let patientId = null;
  try {
    const rowContainer = block.closest('.cg-row-container');
    if (rowContainer) {
      patientId = rowContainer.getAttribute('data-row-id');
      const patientCell = rowContainer.querySelector('.cg-patient-cell');
      if (patientCell) {
        const nameLink = patientCell.querySelector('a.cg-word-break-string');
        if (nameLink) {
          // Text is "ABDUL HAMEED, AMAL\n(FNE-900042)" — take first line only
          clientName = nameLink.textContent.trim().split('\n')[0].trim();
        } else {
          clientName = patientCell.textContent.trim().split('\n')[0].trim();
        }
      }
    }
  } catch(e) {}

  return { visitId, schedRange, visitRange, caregiverName, caregiverId, clientName, patientId, dateStr, schedHrs, confirmedHrs, el: block };
}

function parseHHMM(str) {
  // "16:00" => 16.0 hours
  if (!str) return null;
  const m = str.match(/(\d+):(\d+)/);
  if (!m) return null;
  return parseInt(m[1]) + parseInt(m[2]) / 60;
}

function scanPatientGrid(grid) {
  const overlaps = [];
  const hourDiffs = [];
  const OVERLAP_THRESHOLD_MINS = 8;
  const HOUR_DIFF_THRESHOLD_MINS = 8;

  // Remove any old highlights from previous scan
  grid.querySelectorAll('.cg-visit-item').forEach(b => {
    b.style.removeProperty('outline');
    b.style.removeProperty('background');
  });

  const blocks = Array.from(grid.querySelectorAll('.cg-visit-item'));
  const totalVisits = blocks.length;
  if (totalVisits === 0) return { overlaps, hourDiffs, totalVisits };

  // In the Patient view, each row = one patient.
  // Each day cell = div.cg-calendar-cell[data-date-value].
  // Overlaps happen when the SAME caregiver appears in two different patients' cells
  // for the SAME date with overlapping times.
  //
  // Group key = caregiverKey + "_" + dateStr
  // That way: SALIH on 4/27 is separate from SALIH on 4/28 → no false positives.

  const caregiverDayMap = {};

  blocks.forEach(block => {
    const data = extractVisitData(block);

    // ── Hour diff check (sched vs confirmed, ignore C:00:00 = not yet confirmed) ──
    if (data.schedHrs !== null && data.confirmedHrs !== null && data.confirmedHrs > 0) {
      const diffMins = Math.abs(data.schedHrs - data.confirmedHrs) * 60;
      if (diffMins >= HOUR_DIFF_THRESHOLD_MINS) {
        hourDiffs.push({
          client:    data.clientName || 'Unknown',
          caregiver: data.caregiverName || 'Unknown',
          date:      data.dateStr || '',
          schedHrs:  data.schedHrs.toFixed(2),
          visitHrs:  data.confirmedHrs.toFixed(2),
          diffMins:  Math.round(diffMins),
          over:      data.confirmedHrs > data.schedHrs,
          el:        block
        });
        if (diffMins >= 15) {
          try {
            // Purple: clock-in matches but clock-out differs >15 min
            // Green: time window shifted but total hours match within 15 min
            // Yellow: both in+out differ
            let highlightColor = null;
            if (data.schedRange && data.visitRange) {
              const si = parseRangeToInterval(data.schedRange);
              const vi = parseRangeToInterval(data.visitRange);
              if (si && vi) {
                const inDiffMins = Math.abs(si.start - vi.start);
                const outDiffMins = Math.abs(si.end - vi.end);
                const schedDurMins = si.end - si.start;
                const visitDurMins = vi.end - vi.start;
                const durDiffMins = Math.abs(schedDurMins - visitDurMins);
                if (durDiffMins <= 15) {
                  // Hours match within 15 min — green (time shifted)
                  highlightColor = 'green';
                } else if (inDiffMins <= 15 && outDiffMins > 15) {
                  // Clock-in matches, clock-out off — purple
                  highlightColor = 'purple';
                } else {
                  highlightColor = 'yellow';
                }
              } else {
                highlightColor = 'yellow';
              }
            } else {
              highlightColor = 'yellow';
            }
            if (highlightColor === 'purple') {
              block.style.outline = '2px solid #ce93d8';
              block.style.background = 'rgba(206,147,216,0.18)';
            } else if (highlightColor === 'green') {
              block.style.outline = '2px solid #66bb6a';
              block.style.background = 'rgba(102,187,106,0.18)';
            } else {
              block.style.outline = '2px solid #ffd600';
              block.style.background = 'rgba(255,214,0,0.18)';
            }
          } catch(e) {}
        }
      }
    }

    // ── Overlap map: caregiver + date → list of visits ────────────
    // Only group if we have a real caregiver name, a scheduled time, and a date.
    if (data.caregiverName && data.schedRange && data.dateStr) {
      const schedInterval = parseRangeToInterval(data.schedRange);
      if (schedInterval) {
        // ── KEY RULE: clamp actual EVV time to the scheduled window.
        // If a DCW clocks in early (before schedule start) or out late (after schedule end),
        // those outside-schedule minutes must NOT count toward overlap detection —
        // they would create false overlaps against a neighbouring visit and block billing.
        // Effective interval = intersection of EVV time with scheduled window.
        // If no EVV times yet (unconfirmed visit) → use scheduled window as-is.
        let effStart = schedInterval.start;
        let effEnd   = schedInterval.end;
        if (data.visitRange) {
          const evvInterval = parseRangeToInterval(data.visitRange);
          if (evvInterval) {
            const clampedStart = Math.max(evvInterval.start, schedInterval.start);
            const clampedEnd   = Math.min(evvInterval.end,   schedInterval.end);
            // Only use clamped interval if it's valid (DCW worked inside schedule)
            if (clampedEnd > clampedStart) {
              effStart = clampedStart;
              effEnd   = clampedEnd;
            }
            // If clamped interval is empty (DCW only worked entirely outside schedule)
            // fall back to schedule window — still need to check for double-booking
          }
        }

        const cgKey  = data.caregiverId
          ? 'id_' + data.caregiverId
          : data.caregiverName.toLowerCase().replace(/\W+/g, '');
        const mapKey = cgKey + '_' + data.dateStr.replace(/\W+/g, '');
        if (!caregiverDayMap[mapKey]) caregiverDayMap[mapKey] = [];
        caregiverDayMap[mapKey].push({
          ...data,
          start: effStart,
          end:   effEnd
        });
      }
    }
  });

  // ── Detect overlaps: same caregiver, same date, effective intervals overlap ≥8 min ──
  Object.values(caregiverDayMap).forEach(visits => {
    if (visits.length < 2) return;
    for (let i = 0; i < visits.length; i++) {
      for (let j = i + 1; j < visits.length; j++) {
        const a = visits[i], b = visits[j];
        const overlapStart = Math.max(a.start, b.start);
        const overlapEnd   = Math.min(a.end,   b.end);
        const overlapMins  = overlapEnd - overlapStart;
        if (overlapMins >= OVERLAP_THRESHOLD_MINS) {
          overlaps.push({
            caregiver:   a.caregiverName,
            date:        a.dateStr || b.dateStr || '',
            client1:     a.clientName || 'Unknown',
            time1:       a.schedRange,
            visit1:      a.visitRange || null,
            client2:     b.clientName || 'Unknown',
            time2:       b.schedRange,
            visit2:      b.visitRange || null,
            overlapMins
          });
          try { a.el.style.outline = '2px solid #ff4444'; a.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
          try { b.el.style.outline = '2px solid #ff4444'; b.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
        }
      }
    }
  });

  return { overlaps, hourDiffs, totalVisits };
}

function extractCaregiverVisitData(block) {
  // In the Caregiver view:
  //   div.cg-row-container[data-row-id="4660344"]
  //     div.cg-info-cell
  //       div.cg-caregiver-cell[data-caregiver-id="4660344"]
  //         a.cg-caregiver-name => "ACHARYA, DURGA\n(FNE-1639)"
  //     div[data-date-value="4/26/2026"].cg-calendar-cell
  //       div.cg-visit-cell
  //         div.cg-visit-item
  //           a[data-event-type="visit"] => "S:0630 - 1800 (PCA)"
  //           span.cg-visit-span
  //             span.cg-visit-evv => "0633"
  //             span.cg-visit-evv => "1803"
  //           div.cg-text-ellipsis[data-patient-id]
  //             span.cg-text-link => "ACHARYA, DIL"

  const visitId = block.getAttribute('data-visit-id') || '';

  // ── Scheduled time ──
  let schedRange = null;
  const schedLink = block.querySelector('a[data-event-type="visit"]');
  if (schedLink) {
    const txt = schedLink.textContent.trim();
    const m = txt.match(/S:\s*(\d{3,4})\s*[-–]\s*(\d{3,4})/i);
    if (m) schedRange = m[1] + '-' + m[2];
  }

  // ── Actual visit time from .cg-visit-evv spans ──
  let visitRange = null;
  const visitSpan = block.querySelector('.cg-visit-span');
  if (visitSpan) {
    const evvSpans = visitSpan.querySelectorAll('.cg-visit-evv');
    if (evvSpans.length >= 2) {
      const t1 = evvSpans[0].textContent.trim();
      const t2 = evvSpans[1].textContent.trim();
      if (t1 && t2) visitRange = t1 + '-' + t2;
    }
  }

  // ── Date from parent cg-calendar-cell ──
  let dateStr = null;
  try {
    const calCell = block.closest('[data-date-value]');
    if (calCell) dateStr = calCell.getAttribute('data-date-value');
  } catch(e) {}

  // ── Caregiver identity from cg-row-container ──
  let caregiverName = null;
  let caregiverId = null;
  try {
    const rowContainer = block.closest('.cg-row-container');
    if (rowContainer) {
      caregiverId = rowContainer.getAttribute('data-row-id');
      const cgCell = rowContainer.querySelector('.cg-caregiver-cell, .cg-caregiver-name');
      if (cgCell) {
        caregiverName = cgCell.textContent.trim().split('\n')[0].trim();
      }
    }
  } catch(e) {}

  // ── Client name from cg-text-ellipsis[data-patient-id] ──
  let clientName = null;
  try {
    const patientDiv = block.querySelector('[data-patient-id]');
    if (patientDiv) {
      const nameLink = patientDiv.querySelector('.cg-text-link, span');
      if (nameLink) clientName = nameLink.textContent.trim();
    }
  } catch(e) {}

  // ── Hours from S: and V: times directly ──
  const schedHrs = schedRange ? parseVisitHours(schedRange) : null;
  const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

  return { visitId, schedRange, visitRange, caregiverName, caregiverId, clientName, dateStr, schedHrs, visitHrs, el: block };
}

function scanCaregiverGrid(grid) {
  const overlaps = [];
  const hourDiffs = [];
  const OVERLAP_THRESHOLD_MINS = 8;
  const HOUR_DIFF_THRESHOLD_MINS = 8;

  // Remove any old highlights
  grid.querySelectorAll('.cg-visit-item').forEach(b => {
    b.style.removeProperty('outline');
    b.style.removeProperty('background');
  });

  const blocks = Array.from(grid.querySelectorAll('.cg-visit-item'));
  const totalVisits = blocks.length;
  if (totalVisits === 0) return { overlaps, hourDiffs, totalVisits };

  // In Caregiver view: each row = one caregiver.
  // Group by caregiver ID + date to detect overlaps (2 visits same day same caregiver).
  // Also check S: vs V: time differences.

  const caregiverDayMap = {};

  blocks.forEach(block => {
    const data = extractCaregiverVisitData(block);

    // ── Hour diff: compare S: time vs V: time ──
    if (data.schedHrs !== null && data.visitHrs !== null && data.visitRange) {
      const diffMins = Math.abs((data.schedHrs - data.visitHrs) * 60);
      if (diffMins >= HOUR_DIFF_THRESHOLD_MINS) {
        hourDiffs.push({
          caregiver: data.caregiverName || 'Unknown',
          client:    data.clientName || 'Unknown',
          date:      data.dateStr || '',
          schedHrs:  data.schedHrs.toFixed(2),
          visitHrs:  data.visitHrs.toFixed(2),
          diffMins:  Math.round(diffMins),
          over:      data.visitHrs > data.schedHrs,
          el:        block
        });
        // Yellow highlight for 15min+ diff
        if (diffMins >= 15) {
          try {
            let highlightColor = 'yellow';
            if (data.schedRange && data.visitRange) {
              const si = parseRangeToInterval(data.schedRange);
              const vi = parseRangeToInterval(data.visitRange);
              if (si && vi) {
                const inDiffMins = Math.abs(si.start - vi.start);
                const outDiffMins = Math.abs(si.end - vi.end);
                const durDiffMins = Math.abs((si.end - si.start) - (vi.end - vi.start));
                if (durDiffMins <= 15) {
                  highlightColor = 'green';
                } else if (inDiffMins <= 15 && outDiffMins > 15) {
                  highlightColor = 'purple';
                }
              }
            }
            if (highlightColor === 'purple') {
              block.style.outline = '2px solid #ce93d8';
              block.style.background = 'rgba(206,147,216,0.18)';
            } else if (highlightColor === 'green') {
              block.style.outline = '2px solid #66bb6a';
              block.style.background = 'rgba(102,187,106,0.18)';
            } else {
              block.style.outline = '2px solid #ffd600';
              block.style.background = 'rgba(255,214,0,0.18)';
            }
          } catch(e) {}
        }
      }
    }

    // ── Overlap map: same caregiver + same date → check if times collide ──
    if (data.caregiverId && data.schedRange && data.dateStr) {
      const schedInterval = parseRangeToInterval(data.schedRange);
      if (schedInterval) {
        // Clamp EVV times to scheduled window so overtime doesn't create false overlaps
        let effStart = schedInterval.start;
        let effEnd   = schedInterval.end;
        if (data.visitRange) {
          const evvInterval = parseRangeToInterval(data.visitRange);
          if (evvInterval) {
            const clampedStart = Math.max(evvInterval.start, schedInterval.start);
            const clampedEnd   = Math.min(evvInterval.end,   schedInterval.end);
            // Only use clamped interval if it's valid (DCW worked inside schedule)
            if (clampedEnd > clampedStart) {
              effStart = clampedStart;
              effEnd   = clampedEnd;
            }
            // If clamped interval is empty (DCW only worked entirely outside schedule)
            // fall back to schedule window — still need to check for double-booking
          }
        }
        const mapKey = 'id_' + data.caregiverId + '_' + data.dateStr.replace(/\W+/g, '');
        if (!caregiverDayMap[mapKey]) caregiverDayMap[mapKey] = [];
        caregiverDayMap[mapKey].push({ ...data, start: effStart, end: effEnd });
      }
    }
  });

  Object.values(caregiverDayMap).forEach(visits => {
    if (visits.length < 2) return;
    for (let i = 0; i < visits.length; i++) {
      for (let j = i + 1; j < visits.length; j++) {
        const a = visits[i], b = visits[j];
        const overlapStart = Math.max(a.start, b.start);
        const overlapEnd   = Math.min(a.end,   b.end);
        const overlapMins  = overlapEnd - overlapStart;
        if (overlapMins >= OVERLAP_THRESHOLD_MINS) {
          overlaps.push({
            caregiver:   a.caregiverName || 'Unknown',
            date:        a.dateStr || '',
            client1:     a.clientName || a.schedRange || 'Visit 1',
            time1:       a.schedRange,
            visit1:      a.visitRange || null,
            client2:     b.clientName || b.schedRange || 'Visit 2',
            time2:       b.schedRange,
            visit2:      b.visitRange || null,
            overlapMins
          });
          try { a.el.style.outline = '2px solid #ff4444'; a.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
          try { b.el.style.outline = '2px solid #ff4444'; b.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
        }
      }
    }
  });

  return { overlaps, hourDiffs, totalVisits };
}

function injectApptPanel({ overlaps, hourDiffs, totalVisits, panelId, title }) {
  panelId = panelId || 'cc-appt-panel';
  title   = title   || '⚕ Care Crafter — Schedule Scan';

  // Filter out dismissed items
  const visibleOverlaps = overlaps.filter(o => !isDismissed(makeDismissKey('ov', o.caregiver, o.date, o.client1, o.client2)));
  const allDiffs        = hourDiffs.filter(d => !isDismissed(makeDismissKey('df', d.caregiver, d.date, d.client||d.patient)));

  // ── Panel state (filter + sort + pagination) ──────────────────
  const PAGE_SIZE = 25;
  let filterDir   = 'all';   // 'all' | 'over' | 'under'
  let filterMins  = 0;       // minimum diffMins threshold
  let sortDir     = 'none';  // 'none' | 'asc' | 'desc'
  let diffPage    = 1;       // how many pages loaded so far

  function getFilteredSorted() {
    let list = allDiffs.slice();
    if (filterDir === 'over')  list = list.filter(d => d.over);
    if (filterDir === 'under') list = list.filter(d => !d.over);
    if (filterMins > 0)        list = list.filter(d => d.diffMins >= filterMins);
    if (sortDir === 'asc')     list.sort((a, b) => a.diffMins - b.diffMins);
    if (sortDir === 'desc')    list.sort((a, b) => b.diffMins - a.diffMins);
    return list;
  }

  // ── Build panel shell ─────────────────────────────────────────
  const panel = document.createElement('div');
  panel.id = panelId;

  const savedSize = JSON.parse(localStorage.getItem('_cc_panel_size') || 'null');
  const savedW = savedSize ? savedSize.w : 380;
  const savedH = savedSize ? savedSize.h : null;

  panel.style.cssText = `
    position:fixed;top:60px;right:16px;width:${savedW}px;min-width:280px;min-height:120px;max-height:82vh;
    background:#1a1a2e;color:#e0e0e0;border-radius:10px;
    box-shadow:0 4px 24px rgba(0,0,0,0.6);z-index:999999;
    font-family:'Segoe UI',monospace;font-size:12px;overflow:hidden;
    border:1px solid #334;resize:both;
    ${savedH ? `height:${savedH}px;` : ''}
  `;

  const hasIssues = visibleOverlaps.length > 0 || allDiffs.length > 0;

  // ── Header ────────────────────────────────────────────────────
  panel.innerHTML = `
    <div id="${panelId}-header" style="background:linear-gradient(135deg,#0f3460,#16213e);
      padding:11px 14px;display:flex;justify-content:space-between;align-items:center;
      border-radius:10px 10px 0 0;cursor:pointer;user-select:none;">
      <span style="font-weight:bold;font-size:13px;letter-spacing:.3px;">${title}</span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="${panelId}-minimize" style="font-size:11px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="${panelId}-close"    style="cursor:pointer;font-size:16px;color:#aaa;">✕</span>
      </div>
    </div>

    <div id="${panelId}-summary" style="padding:9px 14px;border-bottom:1px solid #2a2a3e;
      display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#16213e;">
      <span style="color:#aaa;">📋 <strong style="color:#e0e0e0;">${totalVisits}</strong> visits</span>
      ${visibleOverlaps.length > 0
        ? `<span style="color:#ff6b6b;font-weight:bold;">🔴 ${visibleOverlaps.length} overlap${visibleOverlaps.length>1?'s':''}</span>`
        : `<span style="color:#51cf66;">✓ No overlaps</span>`}
      ${allDiffs.length > 0
        ? `<span style="color:#ffd43b;font-weight:bold;">⚠ ${allDiffs.length} time diff${allDiffs.length>1?'s':''}</span>`
        : `<span style="color:#51cf66;">✓ Times match</span>`}
      ${window._ccAuthFlag
        ? `<span style="color:#ff8c00;font-weight:bold;">🟠 ${window._ccAuthFlag.label}</span>`
        : ''}
    </div>

    <div id="${panelId}-body" style="overflow-y:auto;max-height:calc(82vh - 160px);padding:10px 14px;">
      <div id="${panelId}-content"></div>
    </div>

    <div id="${panelId}-footer" style="padding:8px 14px;border-top:1px solid #2a2a3e;background:#16213e;
      display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap;">
      <button id="${panelId}-clear-dismissed" style="background:transparent;border:none;color:#555;font-size:10px;cursor:pointer;padding:0;" title="Show all dismissed items again">↺ Reset dismissed</button>
      <div style="display:flex;gap:6px;">
        <button id="${panelId}-export" style="background:#1a6e3c;color:#e0e0e0;border:1px solid #2a9e5c;
          border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;" title="Export to Excel">📥 Export</button>
        <button id="${panelId}-rescan" style="background:#0f3460;color:#e0e0e0;border:1px solid #334;
          border-radius:5px;padding:4px 12px;font-size:11px;cursor:pointer;">🔄 Rescan</button>
      </div>
    </div>
  `;

  document.body.appendChild(panel);

  // ── Filter / Sort toolbar (injected into body before content) ─
  const body = panel.querySelector(`#${panelId}-body`);

  if (allDiffs.length > 0) {
    const toolbar = document.createElement('div');
    toolbar.id = `${panelId}-toolbar`;
    toolbar.style.cssText = `
      display:flex;flex-wrap:wrap;gap:6px;align-items:center;
      padding:8px 0 10px;border-bottom:1px solid #2a2a3e;margin-bottom:10px;
    `;
    toolbar.innerHTML = `
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Filter:</span>
        <select id="${panelId}-filter-dir" style="background:#0f1824;color:#e0e0e0;border:1px solid #334;
          border-radius:4px;padding:2px 5px;font-size:11px;cursor:pointer;">
          <option value="all">All diffs</option>
          <option value="over">Over only</option>
          <option value="under">Under only</option>
        </select>
      </div>
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Min diff:</span>
        <input id="${panelId}-filter-h" type="number" min="0" max="99" placeholder="h"
          style="width:34px;background:#0f1824;color:#e0e0e0;border:1px solid #334;border-radius:4px;padding:2px 4px;font-size:11px;text-align:center;" />
        <span style="color:#555;font-size:10px;">h</span>
        <input id="${panelId}-filter-m" type="number" min="0" max="59" placeholder="m"
          style="width:34px;background:#0f1824;color:#e0e0e0;border:1px solid #334;border-radius:4px;padding:2px 4px;font-size:11px;text-align:center;" />
        <span style="color:#555;font-size:10px;">m</span>
      </div>
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Sort:</span>
        <select id="${panelId}-sort" style="background:#0f1824;color:#e0e0e0;border:1px solid #334;
          border-radius:4px;padding:2px 5px;font-size:11px;cursor:pointer;">
          <option value="none">Default</option>
          <option value="asc">Smallest first</option>
          <option value="desc">Largest first</option>
        </select>
      </div>
      <span id="${panelId}-count" style="color:#aaa;font-size:10px;margin-left:auto;"></span>
    `;
    body.insertBefore(toolbar, body.querySelector(`#${panelId}-content`));

    // Wire up toolbar controls
    const dirSel  = toolbar.querySelector(`#${panelId}-filter-dir`);
    const hInput  = toolbar.querySelector(`#${panelId}-filter-h`);
    const mInput  = toolbar.querySelector(`#${panelId}-filter-m`);
    const sortSel = toolbar.querySelector(`#${panelId}-sort`);

    function applyControls() {
      filterDir  = dirSel.value;
      const h    = parseInt(hInput.value) || 0;
      const m    = parseInt(mInput.value) || 0;
      filterMins = h * 60 + m;
      sortDir    = sortSel.value;
      diffPage   = 1;
      renderContent();
    }

    [dirSel, sortSel].forEach(el => el.addEventListener('change', applyControls));
    [hInput, mInput].forEach(el => el.addEventListener('input',  applyControls));
  }

  // ── Render content (overlaps + paginated diffs) ───────────────
  function renderContent() {
    const content    = panel.querySelector(`#${panelId}-content`);
    const countLabel = panel.querySelector(`#${panelId}-count`);
    let html = '';

    // ── No results states ──
    if (!hasIssues && totalVisits > 0) {
      html += `<div style="color:#51cf66;text-align:center;padding:24px 0;">
        <div style="font-size:28px;margin-bottom:8px;">✅</div>
        <div style="font-weight:bold;">All Clear!</div>
        <div style="color:#aaa;font-size:11px;margin-top:4px;">No overlaps or time differences found.</div>
      </div>`;
    }
    if (totalVisits === 0) {
      html += `<div style="color:#aaa;text-align:center;padding:24px 0;">
        <div style="font-size:24px;margin-bottom:8px;">🔍</div>
        <div>Run a search to scan visits.</div>
      </div>`;
    }

    // ── Overlaps ──
    if (visibleOverlaps.length > 0) {
      html += `<div style="color:#ff6b6b;font-weight:bold;margin:4px 0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        🔴 OVERLAPPING SHIFTS
        <span style="background:#ff4444;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;">${visibleOverlaps.length}</span>
      </div>`;

      visibleOverlaps.forEach(o => {
        const dKey = makeDismissKey('ov', o.caregiver, o.date, o.client1, o.client2);
        html += `<div class="cc-card" data-dismiss-key="${dKey}" style="background:#2d1b1b;border-left:3px solid #ff4444;
          padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="color:#ff9999;font-weight:bold;font-size:12px;">${o.caregiver||'Unknown Caregiver'}</span>
            <div style="display:flex;gap:6px;align-items:center;">
              <span style="background:#ff4444;color:#fff;font-size:10px;padding:1px 6px;border-radius:8px;">${o.overlapMins} min</span>
              <button class="cc-dismiss-btn" data-key="${dKey}" style="background:#333;border:1px solid #555;color:#aaa;border-radius:4px;padding:1px 7px;font-size:10px;cursor:pointer;" title="Dismiss">✓</button>
            </div>
          </div>
          ${o.date ? `<div style="color:#888;font-size:10px;margin:2px 0;">${o.date}</div>` : ''}
          <div style="margin-top:6px;display:flex;flex-direction:column;gap:3px;">
            <div style="background:#1a0f0f;padding:4px 7px;border-radius:3px;">
              <span style="color:#aaa;font-size:10px;">Client 1: </span>
              <span style="color:#e0e0e0;">${o.client1}</span>
              <span style="color:#888;font-size:10px;margin-left:6px;">S:${o.time1||'N/A'}</span>
              <span style="color:#69f0ae;font-size:10px;margin-left:4px;">V:${o.visit1||'N/A'}</span>
            </div>
            <div style="background:#1a0f0f;padding:4px 7px;border-radius:3px;">
              <span style="color:#aaa;font-size:10px;">Client 2: </span>
              <span style="color:#e0e0e0;">${o.client2}</span>
              <span style="color:#888;font-size:10px;margin-left:6px;">S:${o.time2||'N/A'}</span>
              <span style="color:#69f0ae;font-size:10px;margin-left:4px;">V:${o.visit2||'N/A'}</span>
            </div>
          </div>
        </div>`;
      });
    }

    // ── Time differences (filtered + sorted + paginated) ──
    const filtered = getFilteredSorted();
    const sliced   = filtered.slice(0, diffPage * PAGE_SIZE);
    const hasMore  = sliced.length < filtered.length;

    if (countLabel) countLabel.textContent = filtered.length + ' shown';

    if (filtered.length > 0) {
      html += `<div style="color:#ffd43b;font-weight:bold;margin:${visibleOverlaps.length>0?'12px':''}0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        ⚠ TIME DIFFERENCES
        <span style="background:#e6a817;color:#1a1a00;border-radius:10px;padding:1px 7px;font-size:10px;">${filtered.length}</span>
      </div>`;

      sliced.forEach(d => {
        const diffColor = d.over ? '#ff9999' : '#ffd43b';
        const arrow     = d.over ? '↑ Over' : '↓ Under';
        const dKey      = makeDismissKey('df', d.caregiver, d.date, d.client||d.patient);
        const h = Math.floor(d.diffMins / 60);
        const m = d.diffMins % 60;
        const diffLabel = h > 0 ? `${h}h ${m}m` : `${m}m`;
        html += `<div class="cc-card" data-dismiss-key="${dKey}" style="background:#2a2410;border-left:3px solid #ffd43b;
          padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="color:#ffd493;font-weight:bold;font-size:12px;">${d.caregiver||'Unknown'}</span>
            <div style="display:flex;gap:6px;align-items:center;">
              <span style="color:${diffColor};font-size:10px;font-weight:bold;">${arrow} ${diffLabel}</span>
              <button class="cc-dismiss-btn" data-key="${dKey}" style="background:#333;border:1px solid #555;color:#aaa;border-radius:4px;padding:1px 7px;font-size:10px;cursor:pointer;" title="Dismiss">✓</button>
            </div>
          </div>
          <div style="color:#888;font-size:10px;margin:2px 0;">
            ${d.client||d.patient||''}${d.date ? ' — ' + d.date : ''}
          </div>
          <div style="margin-top:6px;display:flex;gap:8px;">
            <div style="background:#1a1600;padding:4px 8px;border-radius:3px;flex:1;text-align:center;">
              <div style="color:#aaa;font-size:9px;">SCHEDULED</div>
              <div style="color:#e0e0e0;font-weight:bold;">${d.schedHrs}h</div>
            </div>
            <div style="background:#1a1600;padding:4px 8px;border-radius:3px;flex:1;text-align:center;">
              <div style="color:#aaa;font-size:9px;">ACTUAL</div>
              <div style="color:${diffColor};font-weight:bold;">${d.visitHrs}h</div>
            </div>
          </div>
        </div>`;
      });

      if (hasMore) {
        html += `<div id="${panelId}-load-more" style="text-align:center;padding:10px 0 4px;">
          <button style="background:#0f3460;color:#aaa;border:1px solid #334;border-radius:5px;
            padding:5px 18px;font-size:11px;cursor:pointer;">
            ↓ Load more (${filtered.length - sliced.length} remaining)
          </button>
        </div>`;
      }
    } else if (allDiffs.length > 0) {
      html += `<div style="color:#aaa;text-align:center;padding:16px 0;font-size:11px;">
        No time differences match the current filter.
      </div>`;
    }

    content.innerHTML = html;

    // Wire up dismiss buttons
    content.querySelectorAll('.cc-dismiss-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        dismissCard(btn.getAttribute('data-key'));
        const card = btn.closest('.cc-card');
        if (card) { card.style.transition='opacity 0.2s'; card.style.opacity='0'; setTimeout(()=>card.remove(),200); }
      });
    });

    // Load more button
    const loadMoreBtn = content.querySelector(`#${panelId}-load-more button`);
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', () => { diffPage++; renderContent(); });
    }

    // Infinite scroll — load more when near bottom
    body.onscroll = () => {
      if (body.scrollTop + body.clientHeight >= body.scrollHeight - 80 && hasMore) {
        diffPage++;
        renderContent();
      }
    };
  }

  renderContent();

  // Resize observer
  const ro = new ResizeObserver(() => {
    localStorage.setItem('_cc_panel_size', JSON.stringify({ w: panel.offsetWidth, h: panel.offsetHeight }));
  });
  ro.observe(panel);

  // ── Export to Excel ───────────────────────────────────────────
  panel.querySelector(`#${panelId}-export`).addEventListener('click', () => {
    try {
      const filtered = getFilteredSorted();
      // Build CSV rows
      const rows = [['Caregiver','Client/Patient','Date','Scheduled Hrs','Actual Hrs','Diff Mins','Diff Hrs/Min','Direction']];
      filtered.forEach(d => {
        const h = Math.floor(d.diffMins/60), m = d.diffMins%60;
        rows.push([
          d.caregiver||'',
          d.client||d.patient||'',
          d.date||'',
          d.schedHrs||'',
          d.visitHrs||'',
          d.diffMins,
          h>0?`${h}h ${m}m`:`${m}m`,
          d.over?'Over':'Under'
        ]);
      });
      // Also add overlaps sheet
      const ovRows = [['Caregiver','Date','Client 1','Sched 1','Visit 1','Client 2','Sched 2','Visit 2','Overlap Mins']];
      visibleOverlaps.forEach(o => {
        ovRows.push([o.caregiver||'',o.date||'',o.client1||'',o.time1||'',o.visit1||'',o.client2||'',o.time2||'',o.visit2||'',o.overlapMins]);
      });

      // Use SheetJS if available, else fall back to CSV download
      if (typeof XLSX !== 'undefined') {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows),   'Time Diffs');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(ovRows), 'Overlaps');
        XLSX.writeFile(wb, 'CareCrafter_Scan_' + new Date().toISOString().slice(0,10) + '.xlsx');
      } else {
        // CSV fallback
        const allRows = [['TYPE','CAREGIVER','CLIENT','DATE','SCHED HRS','ACTUAL HRS','DIFF MINS','DIRECTION']];
        filtered.forEach(d => allRows.push(['TimeDiff', d.caregiver||'', d.client||d.patient||'', d.date||'', d.schedHrs||'', d.visitHrs||'', d.diffMins, d.over?'Over':'Under']));
        visibleOverlaps.forEach(o => allRows.push(['Overlap', o.caregiver||'', o.client1+'/'+o.client2, o.date||'', '','','',o.overlapMins+' min overlap']));
        const csv = allRows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
        const a = document.createElement('a');
        a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
        a.download = 'CareCrafter_Scan_' + new Date().toISOString().slice(0,10) + '.csv';
        a.click();
      }
    } catch(e) { alert('Export error: ' + e.message); }
  });

  // ── Standard controls ──────────────────────────────────────────
  panel.querySelector(`#${panelId}-clear-dismissed`).addEventListener('click', () => {
    clearDismissed(); panel.remove();
    if (panelId === 'cc-appt-panel') runAppointmentsOverlapScan();
    else if (panelId === 'cc-vm-panel') runVisitMaintenanceScan(true);
  });

  panel.querySelector(`#${panelId}-close`).addEventListener('click', () => panel.remove());

  let minimized = false;
  panel.querySelector(`#${panelId}-minimize`).addEventListener('click', e => {
    e.stopPropagation();
    minimized = !minimized;
    const bodyEl   = panel.querySelector(`#${panelId}-body`);
    const summary  = panel.querySelector(`#${panelId}-summary`);
    const footer   = panel.querySelector(`#${panelId}-footer`);
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      [bodyEl, summary, footer].forEach(el => { if(el){el.style.overflow='hidden';el.style.height='0';el.style.padding='0';el.style.margin='0';}});
      panel.style.height='auto'; panel.style.maxHeight='none'; panel.style.minHeight='0'; panel.style.resize='none';
    } else {
      [bodyEl, summary, footer].forEach(el => { if(el){el.style.overflow='';el.style.height='';el.style.padding='';el.style.margin='';}});
      panel.style.height=panel.dataset.fullH||''; panel.style.maxHeight='82vh'; panel.style.minHeight='120px'; panel.style.resize='both';
    }
    panel.querySelector(`#${panelId}-minimize`).textContent = minimized ? '□' : '─';
  });

  panel.querySelector(`#${panelId}-rescan`).addEventListener('click', () => {
    panel.remove();
    if (panelId === 'cc-appt-panel') runAppointmentsOverlapScan();
    else if (panelId === 'cc-vm-panel') runVisitMaintenanceScan(true);
  });

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector(`#${panelId}-header`);
  header.addEventListener('mousedown', e => {
    if (e.target.id === `${panelId}-close` || e.target.id === `${panelId}-minimize`) return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top  = (e.clientY - dragY) + 'px';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });
}


// ─── MASTER WEEK SCANNER ─────────────────────────────────────────

function initMasterWeekScanner() {
  // If masterchild blocks already exist, scan immediately
  if (document.querySelectorAll('.masterchild').length > 0) {
    runMasterWeekScan();
    return;
  }
  // Otherwise watch for them to load
  const obs = new MutationObserver(() => {
    if (document.querySelectorAll('.masterchild').length > 0) {
      obs.disconnect();
      clearTimeout(window._ccMWScanTimer);
      window._ccMWScanTimer = setTimeout(runMasterWeekScan, 800);
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

function parseMasterWeekTime(rangeStr) {
  // "0600-1800" => { start: 360, end: 1080, hours: 12.0 }
  if (!rangeStr) return null;
  const m = rangeStr.replace(/\s/g, '').match(/^(\d{3,4})[-\u2013](\d{3,4})$/);
  if (!m) return null;
  const start = timeToMinutes(m[1]);
  const end   = timeToMinutes(m[2]);
  if (start === null || end === null) return null;
  let diff = end - start;
  if (diff < 0) diff += 1440;
  return { start, end: end < start ? end + 1440 : end, hours: Math.round((diff / 60) * 100) / 100 };
}

function runMasterWeekScan() {
  const existing = document.getElementById('cc-mw-panel');
  if (existing) existing.remove();

  const DAY_ORDER = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

  // Each .masterchild is one shift block (may share patient with others)
  const masterChildren = Array.from(document.querySelectorAll('.masterchild'));
  if (masterChildren.length === 0) return;

  // DCW map: key = "Name (ID)" => { days: { Mon: hours, Tue: hours, ... }, shifts: [] }
  const dcwMap = {};
  const overlapList = [];

  // Also track all shifts per day for overlap detection
  // shiftsByDay: { Mon: [{dcw, start, end, hours}], ... }
  const shiftsByDay = {};
  DAY_ORDER.forEach(d => shiftsByDay[d] = []);

  masterChildren.forEach(child => {
    // Find the table inside this masterchild
    const table = child.querySelector('table');
    if (!table) return;

    const rows = Array.from(table.querySelectorAll('tr'));
    if (rows.length < 2) return;

    // Find column headers (day names) from first row
    const headerCells = Array.from(rows[0].querySelectorAll('th, td'));
    const dayColMap = {}; // colIndex => dayName
    headerCells.forEach((cell, idx) => {
      const txt = cell.innerText.trim();
      const dayMatch = DAY_ORDER.find(d => txt.startsWith(d));
      if (dayMatch) dayColMap[idx] = dayMatch;
    });

    // Find the Hours row and Caregiver row
    let hoursRowData = null;   // { colIndex: timeRange }
    let caregiverData = null;  // { name, id }

    rows.forEach(row => {
      const cells = Array.from(row.querySelectorAll('th, td'));
      const firstTxt = (cells[0] ? cells[0].innerText.trim() : '');

      if (/^hours?$/i.test(firstTxt)) {
        // Hours row: each day column has a time range like "0600-1800"
        hoursRowData = {};
        cells.forEach((cell, idx) => {
          if (dayColMap[idx]) {
            const noData = cell.querySelector('.no-data');
            if (!noData) {
              const timeStr = cell.innerText.trim().replace(/\s+/g, '');
              if (/^\d{3,4}-\d{3,4}$/.test(timeStr)) {
                hoursRowData[dayColMap[idx]] = timeStr;
              }
            }
          }
        });
      }

      if (/^caregiver$/i.test(firstTxt)) {
        // Caregiver row: name is repeated in each ACTIVE day column.
        // Example: cells[0] = "Caregiver" (label), cells[dayColIdx] = "ACHARYA ISHORI, FNE-1640"
        // WRONG approach: reading cells[0] → gets "Caregiver" (the label)
        // CORRECT approach: read the day column cells and take first non-empty one
        cells.forEach((cell, idx) => {
          if (!dayColMap[idx]) return; // only check day columns, not the label column
          if (caregiverData) return;   // already found it
          const noData = cell.querySelector('.no-data');
          if (noData) return;
          const cellTxt = cell.innerText.trim();
          // Must be a real name: has letters, not just "--" or empty
          if (cellTxt && cellTxt !== '--' && /[A-Za-z]/.test(cellTxt)) {
            caregiverData = { name: cellTxt };
          }
        });
      }
    });

    if (!hoursRowData || !caregiverData) return;

    const dcwKey = caregiverData.name;
    if (!dcwMap[dcwKey]) dcwMap[dcwKey] = { days: {}, totalHours: 0 };

    // Register each active day for this DCW
    Object.entries(hoursRowData).forEach(([day, rangeStr]) => {
      const parsed = parseMasterWeekTime(rangeStr);
      if (!parsed) return;

      // Add to DCW map
      if (!dcwMap[dcwKey].days[day]) dcwMap[dcwKey].days[day] = 0;
      dcwMap[dcwKey].days[day] += parsed.hours;
      dcwMap[dcwKey].totalHours = (dcwMap[dcwKey].totalHours || 0) + parsed.hours;

      // Track for overlap detection
      shiftsByDay[day].push({ dcw: dcwKey, start: parsed.start, end: parsed.end, hours: parsed.hours, rangeStr });
    });
  });

  // Detect overlaps within each day
  let totalOverlaps = 0;
  DAY_ORDER.forEach(day => {
    const shifts = shiftsByDay[day];
    if (shifts.length < 2) return;
    for (let i = 0; i < shifts.length; i++) {
      for (let j = i + 1; j < shifts.length; j++) {
        const a = shifts[i], b = shifts[j];
        if (a.dcw === b.dcw) continue;
        const oStart = Math.max(a.start, b.start);
        const oEnd   = Math.min(a.end, b.end);
        const oMins  = oEnd - oStart;
        if (oMins >= 8) {
          totalOverlaps++;
          overlapList.push({
            day,
            dcw1: a.dcw, range1: a.rangeStr,
            dcw2: b.dcw, range2: b.rangeStr,
            overlapMins: oMins
          });
        }
      }
    }
  });

  // Agency total hours
  const agencyTotal = Object.values(dcwMap).reduce((sum, d) => sum + (d.totalHours || 0), 0);

  // ── Build floating panel ──
  const panel = document.createElement('div');
  panel.id = 'cc-mw-panel';
  panel.style.cssText = `
    position: fixed; top: 60px; right: 16px; width: 340px; max-height: 85vh;
    background: #1a1a2e; color: #e0e0e0; border-radius: 10px;
    box-shadow: 0 4px 28px rgba(0,0,0,0.7); z-index: 999999;
    font-family: 'Segoe UI', monospace; font-size: 12px; overflow: hidden;
    border: 1px solid #2a2a4a;
  `;

  const dcwEntries = Object.entries(dcwMap);

  let html = `
    <div id="cc-mw-header" style="
      background: linear-gradient(135deg,#0f3460,#16213e);
      padding: 11px 14px; display: flex; justify-content: space-between;
      align-items: center; border-radius: 10px 10px 0 0;
      cursor: pointer; user-select: none;">
      <span style="font-weight:bold;font-size:13px;letter-spacing:.3px;">
        ⚕ Care Crafter — Master Week
      </span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="cc-mw-minimize" style="font-size:14px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="cc-mw-close" style="cursor:pointer;font-size:16px;color:#aaa;">✕</span>
      </div>
    </div>

    <div id="cc-mw-summary" style="
      padding: 9px 14px; border-bottom: 1px solid #2a2a3e;
      display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
      background: #16213e;">
      <span style="color:#aaa;">👥 <strong style="color:#e0e0e0;">${dcwEntries.length}</strong> DCW${dcwEntries.length !== 1 ? 's' : ''}</span>
      <span style="color:#4ade80;font-weight:bold;">⏱ ${agencyTotal.toFixed(1)}h total</span>
      ${totalOverlaps > 0
        ? `<span style="color:#ff6b6b;font-weight:bold;">🔴 ${totalOverlaps} overlap${totalOverlaps !== 1 ? 's' : ''}</span>`
        : `<span style="color:#51cf66;">✓ No overlaps</span>`}
    </div>

    <div id="cc-mw-body" style="overflow-y:auto;max-height:calc(85vh - 120px);padding:10px 14px;">
  `;

  // ── Agency total box at top ──
  html += `
    <div style="
      background: linear-gradient(135deg,#0d4f3c,#1b5e20);
      border-radius: 8px; padding: 10px 14px; margin-bottom: 12px;
      border: 1px solid #2e7d32;">
      <div style="font-size:10px;color:#a5d6a7;letter-spacing:.5px;margin-bottom:4px;">AGENCY WEEKLY TOTAL</div>
      <div style="font-size:22px;font-weight:bold;color:#69f0ae;letter-spacing:-.5px;">${agencyTotal.toFixed(1)} hrs</div>
      <div style="font-size:10px;color:#81c784;margin-top:2px;">${dcwEntries.length} caregiver${dcwEntries.length !== 1 ? 's' : ''} across ${Object.values(shiftsByDay).filter(s => s.length > 0).length} active days</div>
    </div>
  `;

  // ── Per-DCW breakdown ──
  if (dcwEntries.length > 0) {
    html += `<div style="color:#90caf9;font-weight:bold;font-size:11px;margin-bottom:8px;letter-spacing:.4px;">📋 DCW BREAKDOWN</div>`;

    dcwEntries.forEach(([name, data]) => {
      const activeDays = DAY_ORDER.filter(d => data.days[d]);
      const dayBadges = DAY_ORDER.map(d => {
        if (!data.days[d]) return `<span style="color:#444;font-size:10px;">${d.substring(0,2)}</span>`;
        return `<span style="background:#1b5e20;color:#a5d6a7;border-radius:3px;padding:1px 5px;font-size:10px;font-weight:bold;">${d.substring(0,2)} ${data.days[d].toFixed(1)}h</span>`;
      }).join(' ');

      // Check if this DCW has any overlaps
      const hasOverlap = overlapList.some(o => o.dcw1 === name || o.dcw2 === name);

      html += `
        <div style="
          background: #1e2140; border-radius: 7px; padding: 10px 12px;
          margin-bottom: 9px; border-left: 3px solid ${hasOverlap ? '#ff4444' : '#1565c0'};
        ">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
            <div style="font-weight:bold;color:#90caf9;font-size:11px;line-height:1.4;max-width:220px;">${name}</div>
            <div style="text-align:right;white-space:nowrap;">
              <div style="font-size:16px;font-weight:bold;color:#69f0ae;">${(data.totalHours||0).toFixed(1)}h</div>
              <div style="font-size:9px;color:#888;">${activeDays.length} day${activeDays.length !== 1 ? 's' : ''}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;">${dayBadges}</div>
          ${hasOverlap ? `<div style="color:#ff8a80;font-size:10px;margin-top:6px;">⚠ Has scheduling overlap</div>` : ''}
        </div>
      `;
    });
  } else {
    html += `<div style="color:#888;text-align:center;padding:20px 0;">No shift data found.<br><span style="font-size:10px;">Make sure the Master Week page has loaded.</span></div>`;
  }

  // ── Overlaps section ──
  if (overlapList.length > 0) {
    html += `
      <div style="color:#ff6b6b;font-weight:bold;font-size:11px;margin:10px 0 8px;letter-spacing:.4px;">
        🔴 OVERLAPPING SHIFTS
        <span style="background:#ff4444;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;margin-left:6px;">${overlapList.length}</span>
      </div>
    `;
    overlapList.forEach(o => {
      html += `
        <div style="background:#2d1b1b;border-left:3px solid #ff4444;padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
            <span style="color:#ff9999;font-weight:bold;">${o.day}</span>
            <span style="background:#ff4444;color:#fff;font-size:10px;padding:1px 7px;border-radius:8px;">${o.overlapMins} min overlap</span>
          </div>
          <div style="font-size:11px;color:#ccc;line-height:1.6;">
            <div>📌 ${o.dcw1} <span style="color:#888;">${o.range1}</span></div>
            <div>📌 ${o.dcw2} <span style="color:#888;">${o.range2}</span></div>
          </div>
        </div>
      `;
    });
  }

  html += `</div>`; // end body

  // ── Footer ──
  html += `
    <div style="padding:8px 14px;border-top:1px solid #2a2a3e;background:#16213e;
      display:flex;justify-content:space-between;align-items:center;">
      <span style="color:#555;font-size:10px;">⚙ threshold: 8 min</span>
      <button id="cc-mw-rescan" style="background:#0f3460;color:#e0e0e0;border:1px solid #334;
        border-radius:5px;padding:4px 12px;font-size:11px;cursor:pointer;">
        🔄 Rescan
      </button>
    </div>
  `;

  panel.innerHTML = html;
  document.body.appendChild(panel);

  // ── Event listeners ──
  panel.querySelector('#cc-mw-close').addEventListener('click', () => panel.remove());

  panel.querySelector('#cc-mw-rescan').addEventListener('click', () => {
    panel.remove();
    runMasterWeekScan();
  });

  let minimized = false;
  panel.querySelector('#cc-mw-minimize').addEventListener('click', (e) => {
    e.stopPropagation();
    minimized = !minimized;
    const body    = panel.querySelector('#cc-mw-body');
    const summary = panel.querySelector('#cc-mw-summary');
    const footer  = panel.querySelector('#cc-mw-body + div');
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      [body, summary, footer].forEach(el => { if (el) { el.style.overflow='hidden'; el.style.height='0'; el.style.padding='0'; el.style.margin='0'; } });
      panel.style.height = 'auto'; panel.style.maxHeight = 'none'; panel.style.minHeight = '0'; panel.style.resize = 'none';
    } else {
      [body, summary, footer].forEach(el => { if (el) { el.style.overflow=''; el.style.height=''; el.style.padding=''; el.style.margin=''; } });
      panel.style.height = panel.dataset.fullH || ''; panel.style.maxHeight = '82vh'; panel.style.minHeight = '120px'; panel.style.resize = 'both';
    }
    panel.querySelector('#cc-mw-minimize').textContent = minimized ? '□' : '─';
  });

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector('#cc-mw-header');
  header.addEventListener('mousedown', (e) => {
    if (e.target.id === 'cc-mw-close' || e.target.id === 'cc-mw-minimize') return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top  = (e.clientY - dragY) + 'px';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // ── Auth vs Scheduled mismatch check for Master Week ──
  checkMasterWeekAuthMismatch(agencyTotal);
}

// ─── MASTER WEEK AUTH OVERLAY ─────────────────────────────────────
function runMasterWeekAuthOverlay() {
  document.querySelectorAll('.cc-mw-auth-info').forEach(el => el.remove());
  document.querySelectorAll('.cc-mw-injected').forEach(el => el.remove());

  const authTable = document.getElementById('uxUclMasterWeek_PatientAuthorizations_uxGvAuthorization');
  if (!authTable) return;

  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));
  const DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const DAY_COLS  = [10,11,12,13,14,15,16];
  const today = new Date(); today.setHours(0,0,0,0);

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 10) return;

    const authNum = cells[1]  ? cells[1].innerText.trim()  : '';
    const fromStr = cells[2]  ? cells[2].innerText.trim()  : '';
    const toStr   = cells[3]  ? cells[3].innerText.trim()  : '';
    const maxStr  = cells[9]  ? cells[9].innerText.trim()  : '';

    const fromDate = parseDate(fromStr);
    const toDate   = parseDate(toStr);
    const maxHrs   = parseHours(maxStr);
    if (!fromDate || !toDate || !maxHrs) return;

    const isExpired = toDate < today;
    const totalDays = daysBetween(fromDate, toDate);
    const dailyHrs  = maxHrs / totalDays;
    const weeklyHrs = dailyHrs * 7;
    const daysRemaining   = Math.max(0, daysBetween(today, toDate));
    const projectedRemain = daysRemaining * dailyHrs;

    // Inject daily hour badge under Mon-Sun columns
    DAY_COLS.forEach(ci => {
      if (cells[ci] && !cells[ci].querySelector('.cc-mw-injected')) {
        const div = document.createElement('div');
        div.className = 'cc-mw-injected';
        div.style.cssText = 'color:#00695c;font-size:11px;font-weight:700;font-family:monospace;margin-top:3px;';
        div.textContent = fmt(dailyHrs) + 'h';
        cells[ci].appendChild(div);
      }
    });

    // Expiry banner - inject as a row ABOVE if expired/expiring soon
    let bannerColor = null, bannerText = null;
    if (isExpired) {
      bannerColor = '#c62828'; bannerText = '🔴 EXPIRED — ' + toStr;
    } else if (daysRemaining <= 7) {
      bannerColor = '#b71c1c'; bannerText = '🔴 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    } else if (daysRemaining <= 15) {
      bannerColor = '#e65100'; bannerText = '🟠 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    } else if (daysRemaining <= 30) {
      bannerColor = '#1565c0'; bannerText = '🔵 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    }

    if (bannerColor) {
      const bannerRow = document.createElement('tr');
      bannerRow.className = 'cc-mw-auth-info';
      const bannerTd = document.createElement('td');
      bannerTd.colSpan = cells.length;
      bannerTd.style.cssText = `background:${bannerColor};color:#fff;font-family:monospace;font-size:11px;font-weight:700;padding:3px 14px;`;
      bannerTd.textContent = bannerText;
      bannerRow.appendChild(bannerTd);
      row.parentNode.insertBefore(bannerRow, row);
    }

    // Green info row below the data row
    const rc = isExpired ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
    const remFlag = isExpired ? '🚨 EXPIRED' : projectedRemain <= 0 ? '🚨 EXHAUSTED' : projectedRemain < maxHrs * 0.15 ? '⚠ LOW' : '✓';
    const infoRow = document.createElement('tr');
    infoRow.className = 'cc-mw-auth-info';
    const td = document.createElement('td');
    td.colSpan = cells.length;
    td.style.cssText = 'background:#e8f5e9;padding:7px 14px;font-family:monospace;font-size:12px;border-bottom:2px solid #81c784;';
    td.innerHTML = `
      <b style="color:#1b5e20;">⚕ ${authNum}</b> &nbsp;&nbsp;
      <span style="color:#555">${fromStr} – ${toStr} | <b>${totalDays} total days</b></span> &nbsp;&nbsp;
      Daily: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b> &nbsp;&nbsp;
      Weekly: <b style="color:#2e7d32">${fmt(weeklyHrs)}h</b> &nbsp;&nbsp;
      Remaining: <b style="color:${rc}">${fmt(projectedRemain)}h ${remFlag} (${daysRemaining} days left)</b>
      <br>
      <span style="color:#777;font-size:11px;">
        ${DAY_NAMES.map(d => `${d}: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b>`).join(' | ')}
      </span>
    `;
    infoRow.appendChild(td);
    row.parentNode.insertBefore(infoRow, row.nextSibling);

    // Store weekly auth hours globally for mismatch check
    if (!window._ccMWAuthWeeklyHrs || weeklyHrs > window._ccMWAuthWeeklyHrs) {
      window._ccMWAuthWeeklyHrs = weeklyHrs;
    }
  });

  // Watch for AJAX reloads
  if (!window._ccMWAuthObserver) {
    window._ccMWAuthObserver = new MutationObserver(() => {
      if (!document.querySelector('.cc-mw-auth-info')) {
        clearTimeout(window._ccMWAuthTimer);
        window._ccMWAuthTimer = setTimeout(runMasterWeekAuthOverlay, 600);
      }
    });
    window._ccMWAuthObserver.observe(document.body, { childList: true, subtree: true });
  }
}

// ─── PATIENT SEARCH ENHANCEMENTS ─────────────────────────────────
// This runs on the OUTER page (PatientSearch_ns.aspx) — watches for iframe load
function initPatientSearchEnhancements() {
  if (document.getElementById('cc-patient-search-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-patient-search-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // The results load into an iframe — watch for it to get src set / load
  const observer = new MutationObserver(() => {
    const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
    if (iframe) {
      iframe.removeEventListener('load', onIframeLoad);
      iframe.addEventListener('load', onIframeLoad);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Also attach immediately if iframe already exists
  const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
  if (iframe) iframe.addEventListener('load', onIframeLoad);
}

function onIframeLoad() {
  setTimeout(() => {
    try {
      const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
      if (!iframe || !iframe.contentDocument) return;
      highlightUnassignedCoordinatorRows(iframe.contentDocument);
    } catch(e) {}
  }, 400);
}

// This ALSO runs directly inside the results iframe page itself
// (because all_frames:true injects content.js into the iframe too)
function initPatientSearchResultsPage() {
  if (document.getElementById('cc-results-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-results-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // ── Auto-sort by Start Date DESC (newest first) ────────────────
  // IMPORTANT: SortXSLT lives in the PAGE's JS context, not the
  // extension's isolated world. We must inject a <script> tag to call it.
  let sortDone = false;

  function autoSortStartDate() {
    if (sortDone) return;
    const table = document.getElementById('tdSearchResults');
    if (!table || table.querySelectorAll('tbody tr').length === 0) return;
    sortDone = true;

    // Inject a script tag into the page so SortXSLT runs in page context
    const s = document.createElement('script');
    s.textContent = 'if(typeof SortXSLT==="function"){SortXSLT(1,"StartDate","DESC");}';
    document.head.appendChild(s);
    s.remove();
  }

  // Watch for AJAX results to appear after Search click
  const sortObs = new MutationObserver(() => {
    clearTimeout(window._ccSortTimer);
    window._ccSortTimer = setTimeout(autoSortStartDate, 500);
  });
  sortObs.observe(document.body, { childList: true, subtree: true });
  setTimeout(autoSortStartDate, 800);

  // Coordinator highlights + watch for pagination
  highlightUnassignedCoordinatorRows(document);
  const observer = new MutationObserver(() => {
    clearTimeout(window._ccResultTimer);
    window._ccResultTimer = setTimeout(() => highlightUnassignedCoordinatorRows(document), 600);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ─── CAREGIVER SEARCH — NEWEST DCW BY FNE CODE ────────────────────
function ccParseFne(text) {
  // Match codes like "FNE-1640" (prefix 2-5 letters, dash, number)
  const m = (text || '').match(/\b([A-Za-z]{2,5})-(\d{2,6})\b/);
  if (!m) return null;
  return { prefix: m[1].toUpperCase(), num: parseInt(m[2], 10), raw: m[1].toUpperCase() + '-' + m[2] };
}

function ccFindCaregiverRows() {
  // The results table = the table with the most rows containing an FNE-style code
  const tables = Array.from(document.querySelectorAll('table'));
  let best = [], bestCount = 0;
  tables.forEach(t => {
    const trs = Array.from(t.querySelectorAll('tr')).filter(tr => ccParseFne(tr.innerText || ''));
    if (trs.length > bestCount) { bestCount = trs.length; best = trs; }
  });
  return best;
}

function ccExtractCurrentPage() {
  const rows = ccFindCaregiverRows();
  const out = [];
  rows.forEach(tr => {
    const txt = tr.innerText || '';
    const fne = ccParseFne(txt);
    if (!fne) return;
    const link = tr.querySelector('a');
    let name = link ? link.textContent.trim().split('\n')[0].trim() : '';
    if (!name) {
      const c0 = tr.querySelector('td');
      if (c0) name = (c0.innerText || '').split('\n')[0].trim();
    }
    const dobM = txt.match(/\b\d{2}\/\d{2}\/\d{4}\b/);
    const phoneM = txt.match(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/);
    const status = /inactive/i.test(txt) ? 'Inactive' : /active/i.test(txt) ? 'Active' : '';
    out.push({ name, code: fne.raw, prefix: fne.prefix, num: fne.num,
      dob: dobM ? dobM[0] : '', phone: phoneM ? phoneM[0] : '', status });
  });
  return out;
}

function ccExtractCaregivers() {
  const seen = {};
  const uniq = ccExtractCurrentPage().filter(r => { if (seen[r.code]) return false; seen[r.code] = 1; return true; });
  uniq.sort((a, b) => b.num - a.num);
  return uniq;
}

// ── Pagination helpers (results are server-paged via SortXSLT) ──
function ccWait(ms) { return new Promise(r => setTimeout(r, ms)); }

function ccPageLabelEl() {
  return Array.from(document.querySelectorAll('.input-group-label')).find(s => /Page\s+\d+\s+of\s+\d+/i.test(s.textContent || '')) || null;
}
function ccPageInfo() {
  const el = ccPageLabelEl();
  const m = el ? el.textContent.match(/Page\s+(\d+)\s+of\s+(\d+)/i) : null;
  return m ? { cur: +m[1], total: +m[2] } : { cur: 1, total: 1 };
}
function ccFirstCode() {
  const rows = ccFindCaregiverRows();
  if (!rows.length) return '';
  const f = ccParseFne(rows[0].innerText || '');
  return f ? f.raw : '';
}
function ccGotoPage(n) {
  // SortXSLT lives in the page's JS context — inject a script tag to call it
  const s = document.createElement('script');
  s.textContent = "if(typeof SortXSLT==='function'){SortXSLT(" + n + ",'','ASC');}";
  document.head.appendChild(s);
  s.remove();
}
async function ccWaitForPageChange(prevFirstCode, targetPage) {
  for (let i = 0; i < 90; i++) { // up to ~18s
    await ccWait(200);
    const info = ccPageInfo();
    const first = ccFirstCode();
    if (info.cur === targetPage && first && first !== prevFirstCode) return true;
    if (info.cur === targetPage && i > 4) return true;
  }
  return false;
}
async function ccScanAllPages(onStatus) {
  const total = ccPageInfo().total;
  const all = {};
  // Start at page 1
  if (ccPageInfo().cur !== 1) { const pf = ccFirstCode(); ccGotoPage(1); await ccWaitForPageChange(pf, 1); }
  for (let p = 1; p <= total; p++) {
    if (ccPageInfo().cur !== p) {
      const pf = ccFirstCode();
      ccGotoPage(p);
      await ccWaitForPageChange(pf, p);
    }
    if (onStatus) onStatus(p, total);
    ccExtractCurrentPage().forEach(r => { if (!all[r.code]) all[r.code] = r; });
    await ccWait(120);
  }
  return Object.values(all).sort((a, b) => b.num - a.num);
}
async function ccRunFneScan() {
  const btn = document.getElementById('cc-fne-btn');
  const info = ccPageInfo();
  if (info.total <= 1) { ccShowFnePanel(ccExtractCaregivers()); return; }
  if (btn) { btn.disabled = true; btn.dataset.orig = btn.textContent; }
  let recs = [];
  try {
    recs = await ccScanAllPages((p, t) => { if (btn) btn.textContent = '⏳ Scanning page ' + p + ' of ' + t + '...'; });
  } catch (e) { recs = ccExtractCaregivers(); }
  if (btn) { btn.disabled = false; btn.textContent = btn.dataset.orig || '🆕 Find Newest DCWs'; }
  ccShowFnePanel(recs);
}

function initCaregiverSearchScanner() {
  if (document.getElementById('cc-cgsearch-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-cgsearch-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  function tryInject() {
    if (document.getElementById('cc-fne-btn')) return;
    if (ccFindCaregiverRows().length < 2) return; // wait for results
    const btn = document.createElement('button');
    btn.id = 'cc-fne-btn';
    btn.textContent = '🆕 Find Newest DCWs';
    btn.title = 'Sort all caregivers by FNE code — highest number = most recent hire';
    btn.style.cssText = 'position:fixed;top:118px;right:22px;z-index:99998;background:#1e3a5f;color:#fff;border:none;border-radius:8px;padding:10px 16px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,0.3);font-family:system-ui,sans-serif';
    btn.onclick = ccRunFneScan;
    document.body.appendChild(btn);
  }
  const obs = new MutationObserver(() => {
    clearTimeout(window._ccCgTimer);
    window._ccCgTimer = setTimeout(tryInject, 500);
  });
  obs.observe(document.body, { childList: true, subtree: true });
  setTimeout(tryInject, 1000);
}

function ccShowFnePanel(recs) {
  if (!recs) recs = ccExtractCaregivers();
  if (!recs.length) { alert('No caregivers with FNE codes found. Run a Search first.'); return; }

  // Highlight any of the top-10 newest that happen to be visible on the current page
  document.querySelectorAll('.cc-fne-rank').forEach(el => el.remove());
  const topRank = {};
  recs.slice(0, 10).forEach((r, i) => { topRank[r.code] = i + 1; });
  ccFindCaregiverRows().forEach(tr => {
    const f = ccParseFne(tr.innerText || '');
    if (!f || !topRank[f.raw]) return;
    const rank = topRank[f.raw];
    tr.querySelectorAll('td').forEach(td => td.style.setProperty('background-color', rank === 1 ? '#c8e6c9' : '#e8f5e9', 'important'));
    const c0 = tr.querySelector('td');
    if (c0) {
      const b = document.createElement('span');
      b.className = 'cc-fne-rank';
      b.textContent = '#' + rank + ' NEWEST ';
      b.style.cssText = 'display:inline-block;background:#2e7d32;color:#fff;font-size:9px;font-weight:800;padding:1px 5px;border-radius:4px;margin-right:4px';
      c0.prepend(b);
    }
  });

  const ov = document.createElement('div');
  ov.id = 'cc-fne-ov';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif';
  const rowsHtml = recs.map((r, i) => '<tr style="border-bottom:1px solid #eee;' + (i < 3 ? 'background:#f1f8e9' : '') + '">' +
    '<td style="padding:7px 10px;font-weight:700;color:' + (i < 3 ? '#2e7d32' : '#999') + '">' + (i + 1) + '</td>' +
    '<td style="padding:7px 10px;font-weight:600">' + r.name + '</td>' +
    '<td style="padding:7px 10px;font-family:monospace;color:#1565c0;font-weight:700">' + r.code + '</td>' +
    '<td style="padding:7px 10px">' + r.dob + '</td>' +
    '<td style="padding:7px 10px">' + r.phone + '</td>' +
    '<td style="padding:7px 10px">' + r.status + '</td></tr>').join('');
  ov.innerHTML = '<div style="background:#fff;border-radius:12px;width:780px;max-width:92vw;max-height:86vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.4)">' +
    '<div style="padding:16px 20px;background:#1e3a5f;color:#fff;display:flex;align-items:center;gap:12px">' +
      '<div style="flex:1"><div style="font-size:16px;font-weight:800">🆕 Newest DCWs by FNE Code</div>' +
      '<div style="font-size:12px;opacity:0.85;margin-top:2px">' + recs.length + ' caregivers · highest FNE first (newest hires). Top 10 highlighted in green below.</div></div>' +
      '<button id="cc-fne-csv" style="background:#4caf50;color:#fff;border:none;border-radius:6px;padding:8px 14px;font-size:12px;font-weight:700;cursor:pointer">⬇ Export CSV</button>' +
      '<button id="cc-fne-x" style="background:rgba(255,255,255,0.2);color:#fff;border:none;border-radius:6px;padding:8px 12px;font-size:14px;cursor:pointer">✕</button>' +
    '</div>' +
    '<div style="overflow-y:auto">' +
      '<table style="width:100%;border-collapse:collapse;font-size:13px">' +
        '<thead><tr style="position:sticky;top:0;background:#f5f5f5;z-index:1">' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">RANK</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">NAME</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">FNE CODE</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">DOB</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">PHONE</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">STATUS</th>' +
        '</tr></thead><tbody>' + rowsHtml + '</tbody></table></div></div>';
  document.body.appendChild(ov);
  document.getElementById('cc-fne-x').onclick = () => ov.remove();
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  document.getElementById('cc-fne-csv').onclick = () => {
    const csv = [['Rank', 'Name', 'FNE Code', 'DOB', 'Phone', 'Status']]
      .concat(recs.map((r, i) => [i + 1, r.name, r.code, r.dob, r.phone, r.status]))
      .map(row => row.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'newest-dcws-' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
  };
}

function highlightUnassignedCoordinatorRows(doc) {
  const rows = doc.querySelectorAll('table tr');
  if (rows.length === 0) return;

  // Find coordinator column index from header row
  let coordColIdx = -1;
  rows.forEach(row => {
    if (coordColIdx !== -1) return;
    const ths = row.querySelectorAll('th, td[style*="background"]');
    ths.forEach((th, idx) => {
      if (/coordinator/i.test(th.innerText)) coordColIdx = idx;
    });
  });

  rows.forEach(row => {
    if (row.querySelector('th')) return;
    const cells = row.querySelectorAll('td');
    if (cells.length < 3) return;

    let coordText = '';
    if (coordColIdx !== -1 && cells[coordColIdx]) {
      coordText = cells[coordColIdx].innerText.trim();
    } else {
      // Fallback: check every cell for blank/Default/Unassigned
      cells.forEach(cell => {
        const t = cell.innerText.trim();
        if (t === '' || /^default$/i.test(t) || /^unassigned$/i.test(t)) coordText = t;
      });
    }

    const isUnassigned = coordText === '' || /^default$/i.test(coordText) || /^unassigned$/i.test(coordText);
    if (isUnassigned && !row.querySelector('.cc-coord-warn')) {
      row.querySelectorAll('td').forEach(td => {
        td.style.setProperty('background-color', '#ffe0b2', 'important');
      });
      const firstCell = cells[0];
      if (firstCell) {
        const icon = document.createElement('span');
        icon.className = 'cc-coord-warn';
        icon.title = 'No coordinator assigned';
        icon.style.cssText = 'color:#e65100;font-weight:700;margin-right:4px;font-size:12px;';
        icon.textContent = '⚠ ';
        firstCell.prepend(icon);
      }
    }
  });
}



// ─── AUTH VS SCHEDULED MISMATCH — MASTER WEEK ────────────────────
function checkMasterWeekAuthMismatch(agencyTotalHrs) {
  // Remove previous mismatch banners
  document.querySelectorAll('.cc-mw-mismatch-banner').forEach(el => el.remove());

  const authWeeklyHrs = window._ccMWAuthWeeklyHrs;
  if (!authWeeklyHrs || !agencyTotalHrs) return;

  const diff = Math.abs(agencyTotalHrs - authWeeklyHrs);
  if (diff === 0) return;

  const isOver = agencyTotalHrs > authWeeklyHrs;

  let bgColor, borderColor, bannerBg, textColor, label;
  if (diff > 2) {
    bgColor     = 'rgba(198,40,40,0.08)';
    borderColor = '#c62828';
    bannerBg    = '#c62828';
    textColor   = '#fff';
    label = `🔴 MASTER WEEK MISMATCH >2h: Scheduled ${fmt(agencyTotalHrs)}h vs Auth ${fmt(authWeeklyHrs)}h/wk (${isOver ? '+' : '-'}${fmt(diff)}h)`;
  } else {
    bgColor     = 'rgba(249,168,37,0.10)';
    borderColor = '#f9a825';
    bannerBg    = '#f9a825';
    textColor   = '#333';
    label = `🟡 MASTER WEEK MISMATCH ≤2h: Scheduled ${fmt(agencyTotalHrs)}h vs Auth ${fmt(authWeeklyHrs)}h/wk (${isOver ? '+' : '-'}${fmt(diff)}h)`;
  }

  // Find the master week schedule table and color it
  const mwTables = document.querySelectorAll('.masterchild table, table.hhax-table');
  mwTables.forEach(t => {
    t.style.setProperty('outline', `3px solid ${borderColor}`, 'important');
    t.style.setProperty('background-color', bgColor, 'important');
  });

  // Inject banner at top of page content
  const banner = document.createElement('div');
  banner.className = 'cc-mw-mismatch-banner';
  banner.style.cssText = `background:${bannerBg};color:${textColor};font-family:monospace;font-size:12px;font-weight:700;padding:7px 14px;border-radius:4px;margin:8px 0;`;
  banner.textContent = label;
  const mainContent = document.querySelector('main, .hhax-main-content, #mainContentRegion, body');
  if (mainContent) mainContent.insertBefore(banner, mainContent.firstChild);
}

// ─── PREBILLING ENHANCEMENTS ──────────────────────────────────────
function initPrebillingEnhancements() {
  const marker = document.createElement('div');
  marker.id = 'cc-prebilling-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // Inject the compliance banner + scan button immediately
  injectPrebillingBanner();
  injectPrebillingScanBtn();

  // ── Auto-sort by Visit Date DESC (latest first) ────────────────
  function autoSortByVisitDateDesc() {
    if (window._ccPrebillSorted) return;
    const allLinks = Array.from(document.querySelectorAll('th a, thead a'));
    const visitDateLink = allLinks.find(a => {
      const txt = a.innerText.trim().toLowerCase();
      return txt.includes('visit date') || txt.includes('service date');
    });
    if (visitDateLink) {
      try {
        if (typeof SortXSLT === 'function') {
          SortXSLT(1, 'VisitDate', 'DESC');
          window._ccPrebillSorted = true;
          return;
        }
      } catch(e) {}
      visitDateLink.click();
      setTimeout(() => {
        const links2 = Array.from(document.querySelectorAll('th a, thead a'));
        const vdLink2 = links2.find(a => a.innerText.trim().toLowerCase().includes('visit date') || a.innerText.trim().toLowerCase().includes('service date'));
        if (vdLink2) vdLink2.click();
      }, 800);
      window._ccPrebillSorted = true;
    }
  }

  setTimeout(autoSortByVisitDateDesc, 1200);
  setTimeout(autoSortByVisitDateDesc, 2500);

  // Watch for results to load — re-inject button + EVV bars
  const observer = new MutationObserver(() => {
    clearTimeout(window._ccPrebillTimer);
    window._ccPrebillTimer = setTimeout(() => {
      injectPrebillingScanBtn();
      injectEVVUrgencyBars();
    }, 600);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Also run after delays in case results already loaded
  setTimeout(() => { injectPrebillingScanBtn(); injectEVVUrgencyBars(); }, 1500);
  setTimeout(() => { injectPrebillingScanBtn(); injectEVVUrgencyBars(); }, 3500);
}

// ── Inject "Scan Prebilling & Remember" button ─────────────────
function injectPrebillingScanBtn() {
  if (document.getElementById('cc-prebill-scan-wrap')) return;

  // Best anchor: above the results table
  const anchor = document.getElementById('tdSearchResults') ||
                 document.getElementById('tdScroll') ||
                 document.querySelector('.scrollpane.table-scroll') ||
                 document.getElementById('ctl00_ContentPlaceHolder1_divPrebillingReportInternalScroll');
  if (!anchor) return;

  const wrap = document.createElement('div');
  wrap.id = 'cc-prebill-scan-wrap';
  wrap.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0 4px 0;font-family:Arial,sans-serif;flex-wrap:wrap;';

  const btn = document.createElement('button');
  btn.id = 'cc-prebill-scan-btn';
  btn.textContent = '💾 Scan Prebilling & Remember';
  btn.title = 'Scan all prebilling rows across all pages and merge into billing memory — used to flag unconfirmed visits on the Add Internal Batch Invoice page. Works alongside the Appointments scan.';
  btn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:11px;cursor:pointer;font-weight:bold;';

  const statusLbl = document.createElement('span');
  statusLbl.id = 'cc-prebill-scan-status';
  statusLbl.style.cssText = 'font-size:11px;color:#888;font-family:monospace;';

  // Pre-populate with existing memory info
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    if (r._cc_billing_memory) {
      const d = r._cc_billing_memory;
      const unconf = d.visits.filter(v => !v.isConfirmed).length;
      const savedTime = new Date(d.savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      statusLbl.textContent = `Last saved ${savedTime} · ${d.totalVisits || d.visits.length} visits · ${unconf} unconfirmed`;
      statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
    } else {
      statusLbl.textContent = 'No memory saved yet — click to scan';
      statusLbl.style.color = '#888';
    }
  });

  btn.addEventListener('click', () => scanPrebillingAndRemember(btn, statusLbl));
  wrap.appendChild(btn);
  wrap.appendChild(statusLbl);
  anchor.parentNode.insertBefore(wrap, anchor);
}

// ── Prebilling page scanner ────────────────────────────────────
async function scanPrebillingAndRemember(btn, statusLbl) {
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Scanning...'; }
  if (statusLbl) { statusLbl.textContent = 'Scanning...'; statusLbl.style.color = '#90caf9'; }

  const allRecords = [];
  const seenKeys   = new Set();
  let pageNum      = 1;

  // ── Parse military time range "0430-1230" → minutes duration ──
  function parseSchedMilitary(range) {
    const m = (range || '').replace(/\s/g, '').match(/^(\d{2})(\d{2})-(\d{2})(\d{2})$/);
    if (!m) return null;
    const start = parseInt(m[1]) * 60 + parseInt(m[2]);
    const end   = parseInt(m[3]) * 60 + parseInt(m[4]);
    const diff  = end > start ? end - start : end + 1440 - start;
    return diff > 0 ? diff : null;
  }

  // ── Snapshot all rows on current page ──
  function scanCurrentPage() {
    const tbody = document.querySelector(
      '#tblDetails tbody, table.hhax-table-soy tbody, table.sortableTable tbody'
    );
    if (!tbody) return 0;

    let count = 0;
    Array.from(tbody.querySelectorAll('tr:not(.cc-evv-bar-row)')).forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 13) return;

      const dateText = tds[0].textContent.trim();
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;

      // Patient ID from link onclick
      const patLink = tds[1].querySelector('a');
      const patM = (patLink?.getAttribute('onclick') || '').match(/RedirectToInternalPatientPage\((\d+)\)/);
      const patientId = patM ? patM[1] : null;
      if (!patientId) return;

      // Caregiver ID + name
      const cgLink  = tds[5].querySelector('a');
      const cgM     = (cgLink?.getAttribute('onclick') || '').match(/RedirectToAidePage\((\d+)\)/);
      const caregiverId   = cgM ? cgM[1] : null;
      const caregiverName = cgLink
        ? (cgLink.childNodes[0]?.textContent?.trim() || tds[5].textContent.split('\n')[0].trim()).replace(/\s+/g, ' ').trim()
        : tds[5].textContent.split('\n')[0].trim();

      // Visit ID from edit button id="VID-NNN-VISITID"
      const lastTd  = tds[tds.length - 1];
      const editBtn = lastTd.querySelector('a[id^="VID-"]');
      const vidM    = editBtn?.id?.match(/VID-\d+-(\d+)/);
      let visitId   = vidM ? vidM[1] : null;
      if (!visitId) {
        const ocM = (editBtn?.getAttribute('onclick') || '').match(/RedirectToVisitPage\((\d+)/);
        if (ocM) visitId = ocM[1];
      }

      // Dedup by visitId or composite key
      const dedupKey = visitId || (patientId + '_' + dateText + '_' + (caregiverId || caregiverName));
      if (seenKeys.has(dedupKey)) return;
      seenKeys.add(dedupKey);

      // Confirmation status:
      // - tds[9] = Visit Time: warning triangle = missing EVV
      // - tds[12] = Problems: "Incomplete Confirmation" = unconfirmed
      const hasEVVWarning = !!tds[9].querySelector('.warning, .fa-exclamation-triangle');
      const problemsText  = tds[12] ? tds[12].textContent : '';
      const isConfirmed   = !hasEVVWarning && !problemsText.includes('Incomplete Confirmation');

      const schedRange = tds[8].textContent.trim();
      const memberName = tds[2].textContent.trim();

      allRecords.push({
        visitId,
        date:         dateText,
        patientId,
        memberName,
        caregiverId,
        caregiverName,
        schedRange,
        schedMins:    parseSchedMilitary(schedRange),
        isConfirmed,
        source:       'prebilling'
      });
      count++;
    });
    return count;
  }

  // ── Wait for page to change after clicking Next ──
  async function waitForPageChange(prevFirstId) {
    await new Promise(resolve => {
      let tries = 0;
      const check = setInterval(() => {
        tries++;
        const firstRow = document.querySelector(
          '#tblDetails tbody tr:not(.cc-evv-bar-row), table.hhax-table-soy tbody tr:not(.cc-evv-bar-row)'
        );
        const curId = firstRow?.querySelector('a[id^="VID-"]')?.id;
        if ((curId && curId !== prevFirstId) || tries >= 60) { clearInterval(check); resolve(); }
      }, 200);
    });
    await new Promise(r => setTimeout(r, 400));
  }

  // ── Scan page 1 ──
  scanCurrentPage();
  if (statusLbl) statusLbl.textContent = `Page ${pageNum} scanned (${allRecords.length} rows)...`;

  // ── Auto-paginate ──
  while (pageNum < 100) {
    const pagingDiv = document.getElementById('divPrebillingReportInternalPaging') ||
                      document.querySelector('[id*="Paging"]');
    if (!pagingDiv) break;

    // Find Next link by common text patterns
    const pagerLinks = Array.from(pagingDiv.querySelectorAll('a, button'));
    const nextLink = pagerLinks.find(el => {
      const t = el.textContent.trim();
      return t === '>' || t === '>>' || t.toLowerCase() === 'next';
    });
    if (!nextLink) break;

    // Check if disabled
    const isDisabled = nextLink.classList.contains('disabled') ||
                       nextLink.hasAttribute('disabled') ||
                       nextLink.getAttribute('aria-disabled') === 'true';
    if (isDisabled) break;

    const prevFirstRow = document.querySelector(
      '#tblDetails tbody tr:not(.cc-evv-bar-row), table.hhax-table-soy tbody tr:not(.cc-evv-bar-row)'
    );
    const prevFirstId = prevFirstRow?.querySelector('a[id^="VID-"]')?.id;

    nextLink.click();
    await waitForPageChange(prevFirstId);

    pageNum++;
    if (statusLbl) statusLbl.textContent = `Page ${pageNum} scanning (${allRecords.length} rows so far)...`;
    if (btn) btn.textContent = `⏳ Page ${pageNum}...`;

    const newRows = scanCurrentPage();
    if (newRows === 0) break; // Empty page — done
  }

  // ── Merge into existing memory ─────────────────────────────────
  // Prebilling scanner MERGES — it doesn't overwrite appointments data.
  // Records already in memory are updated (isConfirmed refreshed from prebilling).
  // New records (not previously seen) are appended.
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    const mem = r._cc_billing_memory || { visits: [], savedAt: null };

    // Index existing records by visitId for O(1) update
    const byVisitId = {};
    mem.visits.forEach((v, i) => { if (v.visitId) byVisitId[v.visitId] = i; });

    let added = 0, updated = 0;
    allRecords.forEach(rec => {
      if (rec.visitId && rec.visitId in byVisitId) {
        Object.assign(mem.visits[byVisitId[rec.visitId]], rec);
        updated++;
      } else {
        if (rec.visitId) byVisitId[rec.visitId] = mem.visits.length;
        mem.visits.push(rec);
        added++;
      }
    });

    // Recompute aggregates
    const sortedDates = mem.visits.map(v => v.date).filter(Boolean).sort();
    mem.dateRange   = sortedDates.length
      ? sortedDates[0] + (sortedDates[sortedDates.length - 1] !== sortedDates[0]
          ? ' – ' + sortedDates[sortedDates.length - 1] : '')
      : '';
    mem.totalVisits = mem.visits.length;
    mem.savedAt     = new Date().toISOString();

    const unconf = mem.visits.filter(v => !v.isConfirmed).length;

    chrome.storage.local.set({ _cc_billing_memory: mem }, () => {
      if (btn) { btn.disabled = false; btn.textContent = '💾 Scan Prebilling & Remember'; }
      if (statusLbl) {
        statusLbl.textContent = `✓ ${allRecords.length} rows merged (${added} new · ${updated} updated) · ${unconf} unconfirmed · ${mem.dateRange}`;
        statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
      }
    });
  });
}

function injectPrebillingBanner() {
  if (document.getElementById('cc-prebill-banner')) return;

  const banner = document.createElement('div');
  banner.id = 'cc-prebill-banner';
  banner.style.cssText = [
    'background:#c62828',
    'color:#fff',
    'font-family:Arial,sans-serif',
    'font-size:13px',
    'font-weight:700',
    'padding:10px 18px',
    'margin:8px 0 4px 0',
    'border-left:5px solid #7f0000',
    'border-radius:4px',
    'letter-spacing:0.2px',
    'box-shadow:0 2px 6px rgba(0,0,0,0.2)',
    'display:block',
    'box-sizing:border-box',
    'position:relative',
    'z-index:1',
    'line-height:1.5',
  ].join(';');

  banner.innerHTML = '<span style="font-size:16px;margin-right:8px;">⚠️</span><span>Timesheets / EVV visits must be submitted within <u>24–72 hours</u> after the shift or end of pay period. Failure to submit on time may result in claim denial.</span>';

  // Insert AFTER the page header, inside the content area — NOT at the very top
  // This avoids blocking the sticky nav dropdown menus
  const pageHeader = document.querySelector('.hhax-page-header');
  if (pageHeader && pageHeader.parentNode) {
    pageHeader.parentNode.insertBefore(banner, pageHeader.nextSibling);
    return;
  }
  const card = document.querySelector('.hhax-card');
  if (card) {
    card.parentNode.insertBefore(banner, card);
    return;
  }
  const main = document.querySelector('.hhax-main-content') || document.getElementById('mainContent') || document.body;
  main.appendChild(banner);
}

function injectEVVUrgencyBars() {
  // Remove any previously injected bar rows first
  document.querySelectorAll('.cc-evv-bar-row').forEach(el => el.remove());
  document.querySelectorAll('.cc-evv-bar').forEach(el => el.remove());

  const resultsDiv = document.getElementById('ctl00_ContentPlaceHolder1_divPrebillingReportInternalScroll');
  const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframe');

  let doc = document;
  if ((!resultsDiv || resultsDiv.innerHTML.trim().length < 100) && iframe && iframe.contentDocument && iframe.contentDocument.body) {
    doc = iframe.contentDocument;
  }

  const rows = Array.from(doc.querySelectorAll('table tr'));
  if (rows.length === 0) return;

  // Find date column index from header
  let dateColIdx = -1;
  rows.forEach(row => {
    if (dateColIdx !== -1) return;
    const ths = row.querySelectorAll('th');
    ths.forEach((th, idx) => {
      const t = th.innerText.trim().toLowerCase();
      if (t.includes('visit date') || t.includes('service date') || t === 'date') dateColIdx = idx;
    });
  });

  const now = new Date();
  const GRADIENT = 'linear-gradient(to right, #b7f5a0 0%, #fff176 25%, #ffd600 45%, #ff8f00 65%, #e53935 82%, #c62828 100%)';

  rows.forEach(row => {
    if (row.querySelector('th')) return;
    if (row.classList.contains('cc-evv-bar-row')) return;
    if (row.nextElementSibling && row.nextElementSibling.classList.contains('cc-evv-bar-row')) return;

    const cells = row.querySelectorAll('td');
    if (cells.length < 3) return;

    let visitDate = null;
    if (dateColIdx !== -1 && cells[dateColIdx]) {
      visitDate = parseDate(cells[dateColIdx].innerText.trim());
    }
    if (!visitDate) {
      Array.from(cells).forEach(cell => {
        if (visitDate) return;
        const m = cell.innerText.trim().match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (m) visitDate = new Date(parseInt(m[3]), parseInt(m[1])-1, parseInt(m[2]));
      });
    }
    if (!visitDate) return;

    const visitMidnight = new Date(visitDate);
    visitMidnight.setHours(0,0,0,0);
    const hoursElapsed = (now - visitMidnight) / 3600000;
    if (hoursElapsed < 0) return;

    const MAX_HRS = 72;
    const pct = Math.min((hoursElapsed / MAX_HRS) * 100, 100);
    const isOverdue = hoursElapsed >= MAX_HRS;

    // ── Countdown label in the last cell ──────────────────────────
    const lastCell = cells[cells.length - 1];
    if (!lastCell.querySelector('.cc-evv-bar')) {
      const label = doc.createElement('div');
      label.className = 'cc-evv-bar';
      label.dataset.visitMidnight = visitMidnight.getTime();
      label.style.cssText = 'font-size:9px;font-family:monospace;font-weight:700;text-align:right;padding-top:2px;white-space:nowrap;';
      updateEVVLabel(label);
      lastCell.appendChild(label);
    }

    // ── Gradient bar row injected BELOW the data row ──────────────
    // This is the only reliable cross-browser way — a dedicated <tr>
    const barRow = doc.createElement('tr');
    barRow.className = 'cc-evv-bar-row';
    barRow.style.cssText = 'height:14px;padding:0;margin:0;';

    const barTd = doc.createElement('td');
    barTd.colSpan = cells.length;
    barTd.style.cssText = 'padding:0;margin:0;height:14px;border:none;position:relative;overflow:visible;';

    // Full gradient track
    const track = doc.createElement('div');
    track.style.cssText = [
      'width:100%', 'height:14px',
      'background:' + GRADIENT,
      'position:relative',
      'overflow:visible'
    ].join(';');

    // Bold vertical marker line — tall, black with white outline
    const marker = doc.createElement('div');
    marker.style.cssText = [
      'position:absolute',
      'top:-4px',
      'left:' + pct + '%',
      'width:5px',
      'height:22px',
      'background:#000',
      'transform:translateX(-50%)',
      'border-left:2px solid rgba(255,255,255,0.9)',
      'border-right:2px solid rgba(255,255,255,0.9)',
      'border-radius:2px',
      'z-index:10',
      'box-shadow:0 0 4px rgba(0,0,0,0.8)'
    ].join(';');
    track.appendChild(marker);

    // Overdue red overlay on right side past marker
    if (isOverdue) {
      const overdueOverlay = doc.createElement('div');
      overdueOverlay.style.cssText = 'position:absolute;top:0;right:0;width:100%;height:6px;background:rgba(127,0,0,0.35);';
      track.appendChild(overdueOverlay);
    }

    barTd.appendChild(track);
    barRow.appendChild(barTd);
    row.parentNode.insertBefore(barRow, row.nextSibling);
  });

  // ── Live-tick: update countdown labels every 60s ──────────────
  if (!window._ccEVVTick) {
    window._ccEVVTick = setInterval(() => {
      document.querySelectorAll('.cc-evv-bar[data-visit-midnight]').forEach(updateEVVLabel);
    }, 60000);
  }
}

function updateEVVLabel(lbl) {
  const remainingMs = (72 * 3600000) - (Date.now() - parseInt(lbl.dataset.visitMidnight));
  if (remainingMs <= 0) {
    const h = Math.floor(-remainingMs / 3600000);
    const m = Math.floor((-remainingMs % 3600000) / 60000);
    lbl.style.color = '#7f0000';
    lbl.textContent = '💥 ' + h + 'h ' + m + 'm OVERDUE';
  } else {
    const h = Math.floor(remainingMs / 3600000);
    const m = Math.floor((remainingMs % 3600000) / 60000);
    lbl.style.color = h < 12 ? '#b71c1c' : h < 24 ? '#e65100' : h < 48 ? '#f57f17' : '#555';
    lbl.textContent = '⏳ ' + h + 'h ' + m + 'm remaining';
  }
}

function buildEVVBarHTML(hoursElapsed) {
  const MAX_HOURS = 72;
  const pct = Math.min(hoursElapsed / MAX_HOURS * 100, 100);
  const isOverdue = hoursElapsed > MAX_HOURS;
  const hrs = Math.round(hoursElapsed);

  const gradient = 'linear-gradient(to right,#ffffff 0%,#fff176 35%,#ffd600 55%,#ff6f00 75%,#c62828 100%)';
  const trackStyle = 'display:block;width:100%;height:5px;background:' + gradient + ';position:relative;overflow:hidden;box-sizing:border-box;';

  if (isOverdue) {
    return '<div style="' + trackStyle + '">'
      + '<div style="position:absolute;right:0;top:0;height:5px;background:#7f0000;padding:0 3px;font-size:5px;font-family:monospace;font-weight:700;color:#fff;white-space:nowrap;line-height:5px;box-sizing:border-box;">💥' + hrs + 'h OVERDUE</div>'
      + '</div>';
  } else {
    return '<div style="' + trackStyle + '">'
      + '<div style="position:absolute;top:0;left:' + pct + '%;width:2px;height:5px;background:rgba(0,0,0,0.6);transform:translateX(-1px);"></div>'
      + '<div style="position:absolute;right:2px;top:0;font-size:5px;color:rgba(0,0,0,0.35);font-family:monospace;line-height:5px;white-space:nowrap;">' + hrs + 'h</div>'
      + '</div>';
  }
}

// ─── VISIT MAINTENANCE SCANNER ────────────────────────────────────

let vmScannerActive = false;
let _vmAllOverlaps = [];
let _vmAllDiffs = [];
let _vmTotalVisits = 0;
let _vmScanning = false;

function initVisitMaintenanceScanner() {
  if (vmScannerActive) return;
  vmScannerActive = true;

  // Mark as initialized
  const marker = document.createElement('div');
  marker.id = 'cc-vm-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // Watch for search results to load
  const obs = new MutationObserver(() => {
    clearTimeout(window._ccVMTimer);
    window._ccVMTimer = setTimeout(() => {
      if (_vmScanning) return; // never interrupt an active scan
      const grid = document.querySelector('hhax-visit-table .ag-center-cols-container');
      if (grid && grid.children.length > 0 && !document.getElementById('cc-vm-panel')) {
        runVisitMaintenanceScan(false);
      }
    }, 1500);
  });
  const container = document.querySelector('hhax-visits-filter-result') || document.body;
  obs.observe(container, { childList: true, subtree: true });
}

function parseVMTime12h(str) {
  // Parse "08:56 PM" → minutes since midnight
  if (!str || str.includes('--')) return null;
  const m = str.match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!m) return null;
  let h = parseInt(m[1]), mn = parseInt(m[2]);
  const ampm = m[3].toUpperCase();
  if (ampm === 'PM' && h !== 12) h += 12;
  if (ampm === 'AM' && h === 12) h = 0;
  return h * 60 + mn;
}

function parseVMScheduleRange(str) {
  // Parse "09:00 PM - 12:00 AM" → {start, end} in minutes
  if (!str) return null;
  const parts = str.split('-').map(s => s.trim());
  if (parts.length < 2) return null;
  // Handle cross-midnight: combine back in case "-" splits AM/PM weirdly
  const full = str.trim();
  const m = full.match(/(\d+:\d+\s*(?:AM|PM))\s*[-–]\s*(\d+:\d+\s*(?:AM|PM))/i);
  if (!m) return null;
  let start = parseVMTime12h(m[1]);
  let end = parseVMTime12h(m[2]);
  if (start === null || end === null) return null;
  if (end <= start) end += 1440; // cross midnight
  return { start, end };
}

function scanVisitMaintenancePage() {
  const rows = Array.from(document.querySelectorAll('.ag-center-cols-container .ag-row'));
  const visits = [];
  const overlaps = [];
  const hourDiffs = [];

  rows.forEach(row => {
    try {
      // Date/Schedule column
      const dateCell = row.querySelector('[col-id="VisitDate"] hhax-grid-date-cell');
      if (!dateCell) return;
      const spans = Array.from(dateCell.querySelectorAll('span')).filter(s => s.textContent.trim());
      const dateStr = spans[0] ? spans[0].textContent.trim() : '';
      // Schedule range like "09:00 PM - 12:00 AM"
      const schedStr = spans[1] ? spans[1].textContent.trim() : '';
      // Scheduled duration like "3h 00m"
      const schedDurStr = spans[2] ? spans[2].textContent.trim() : '';

      // Visit Time column — actual EVV times
      const timeCell = row.querySelector('[col-id="VisitStartTime"] hhax-grid-time-cell');
      let actualStartStr = null, actualEndStr = null, actualDurStr = null;
      if (timeCell) {
        const boldSpans = Array.from(timeCell.querySelectorAll('.bold-text'));
        // Filter to ones that look like times (HH:MM AM/PM)
        const timeSpans = boldSpans.filter(s => /\d+:\d+\s*(AM|PM)/i.test(s.textContent));
        if (timeSpans.length >= 2) {
          actualStartStr = timeSpans[0].textContent.trim();
          actualEndStr = timeSpans[1].textContent.trim();
        }
        const durEl = timeCell.querySelector('.duration');
        if (durEl) actualDurStr = durEl.textContent.replace('Duration:', '').trim();
      }

      // Member (patient) — extract name AND admission ID
      const patientCell = row.querySelector('[col-id="Patient.PatientFirstName"] hhax-grid-patient-cell');
      let patientName = '', admissionId = '';
      if (patientCell) {
        const link = patientCell.querySelector('a');
        if (link) {
          patientName = link.textContent.trim();
          // PatientId from href: PatientId=19786071
          const pidM = (link.href || '').match(/PatientId=(\d+)/);
          if (pidM) admissionId = 'pid_' + pidM[1];
        }
        // Also grab Admsn. ID text like "FNE-900006" as fallback
        if (!admissionId) {
          const smallEls = patientCell.querySelectorAll('small');
          smallEls.forEach(sm => {
            if (sm.textContent.includes('Admsn') || sm.textContent.includes('FNE-') || sm.textContent.match(/\w+-\d+/)) {
              const nextSm = sm.nextElementSibling;
              if (nextSm) admissionId = nextSm.textContent.trim();
            }
          });
        }
        if (!admissionId) admissionId = patientName; // last resort
      }

      // Caregiver — extract name AND AideId from href
      const cgCell = row.querySelector('[col-id="Caregiver.CaregiverFirstName"] hhax-grid-caregiver-cell');
      let caregiverName = '', aideId = '';
      if (cgCell) {
        const link = cgCell.querySelector('a');
        if (link) {
          caregiverName = link.textContent.trim();
          // AideId from href: AideId=3891469
          const aidM = (link.href || '').match(/AideId=(\d+)/);
          if (aidM) aideId = 'aide_' + aidM[1];
        }
        if (!aideId) aideId = caregiverName; // last resort
      }

      // Visit Status — col-id confirmed as "VisitInfo.Status"
      let visitStatus = '';
      const statusCell = row.querySelector('[col-id="VisitInfo.Status"]');
      if (statusCell) visitStatus = statusCell.textContent.trim();

      // Raw numeric patientId from admissionId
      const rawPatientId = admissionId.replace('pid_', '');

      // Parse durations in minutes
      function parseDurToMins(s) {
        if (!s) return null;
        const mh = s.match(/(\d+)h\s*(\d+)m/);
        if (mh) return parseInt(mh[1]) * 60 + parseInt(mh[2]);
        const mm = s.match(/(\d+)m/);
        if (mm) return parseInt(mm[1]);
        return null;
      }

      const schedDurMins = parseDurToMins(schedDurStr);
      const actualDurMins = parseDurToMins(actualDurStr);
      const schedInterval = parseVMScheduleRange(schedStr);
      const actualStart = parseVMTime12h(actualStartStr);
      let actualEnd = parseVMTime12h(actualEndStr);
      if (actualEnd !== null && actualStart !== null && actualEnd <= actualStart) actualEnd += 1440;

      // Build visit object
      const visit = {
        dateStr, schedStr, schedDurMins, schedInterval,
        actualStartStr, actualEndStr, actualDurMins, actualStart, actualEnd,
        patientName, admissionId, rawPatientId, caregiverName, aideId,
        visitStatus,
        el: row
      };
      visits.push(visit);

      // ── Highlight logic ──────────────────────────────────────
      if (schedInterval && actualStart !== null && actualEnd !== null && actualDurMins !== null) {
        const inDiffMins = Math.abs(schedInterval.start - actualStart);
        const outDiffMins = Math.abs(schedInterval.end - actualEnd);
        const schedDur = schedInterval.end - schedInterval.start;
        const actualDur = actualEnd - actualStart;
        const durDiffMins = Math.abs(schedDur - actualDur);
        const maxDiff = Math.max(inDiffMins, outDiffMins);

        if (maxDiff > 15 || durDiffMins > 15) {
          let highlightColor = 'yellow';
          if (durDiffMins <= 15) {
            highlightColor = 'green';
          } else if (inDiffMins <= 15 && outDiffMins > 15) {
            highlightColor = 'purple';
          }

          // Push to diffs
          hourDiffs.push({
            caregiver: caregiverName,
            patient: patientName,
            date: dateStr,
            schedHrs: (schedDur / 60).toFixed(2),
            visitHrs: (actualDur / 60).toFixed(2),
            diffMins: Math.round(durDiffMins || maxDiff),
            over: actualDur > schedDur,
            highlightColor,
            el: row
          });

          // Apply row highlight
          if (highlightColor === 'purple') {
            row.style.setProperty('background', 'rgba(206,147,216,0.15)', 'important');
            row.style.setProperty('outline', '2px solid #ce93d8', 'important');
          } else if (highlightColor === 'green') {
            row.style.setProperty('background', 'rgba(102,187,106,0.15)', 'important');
            row.style.setProperty('outline', '2px solid #66bb6a', 'important');
          } else {
            row.style.setProperty('background', 'rgba(255,214,0,0.12)', 'important');
            row.style.setProperty('outline', '2px solid #ffd600', 'important');
          }
        }
      }
    } catch(e) {}
  });

  // ── Overlap detection ──
  // Group by caregiver + date
  const cgDayMap = {};
  // Group by patient + date (two caregivers at same time)
  const patDayMap = {};

  visits.forEach(v => {
    if (!v.aideId || !v.dateStr) return;
    const dateKey = v.dateStr.replace(/\W+/g,'');

    // Same caregiver overlaps — key by AIDE ID (not name, avoids false positives with same-name caregivers)
    const cgKey = v.aideId + '_' + dateKey;
    if (!cgDayMap[cgKey]) cgDayMap[cgKey] = [];
    if (v.schedInterval) cgDayMap[cgKey].push(v);

    // Same patient, two caregivers — key by ADMISSION/PATIENT ID (not name)
    if (v.admissionId) {
      const patKey = v.admissionId.replace(/\W+/g,'') + '_' + dateKey;
      if (!patDayMap[patKey]) patDayMap[patKey] = [];
      if (v.schedInterval) patDayMap[patKey].push(v);
    }
  });

  function detectOverlaps(map, type) {
    Object.values(map).forEach(group => {
      if (group.length < 2) return;
      for (let i = 0; i < group.length; i++) {
        for (let j = i + 1; j < group.length; j++) {
          const a = group[i], b = group[j];
          const oStart = Math.max(a.schedInterval.start, b.schedInterval.start);
          const oEnd = Math.min(a.schedInterval.end, b.schedInterval.end);
          const oMins = oEnd - oStart;
          if (oMins >= 8) {
            overlaps.push({
              caregiver: type === 'cg' ? a.caregiverName : `${a.caregiverName} & ${b.caregiverName}`,
              date: a.dateStr,
              client1: type === 'cg' ? a.patientName : a.patientName,
              time1: a.schedStr,
              visit1: a.actualStartStr && a.actualEndStr ? `${a.actualStartStr} - ${a.actualEndStr}` : null,
              client2: type === 'cg' ? b.patientName : b.patientName,
              time2: b.schedStr,
              visit2: b.actualStartStr && b.actualEndStr ? `${b.actualStartStr} - ${b.actualEndStr}` : null,
              overlapMins: Math.round(oMins),
              type
            });
            a.el.style.setProperty('outline', '2px solid #ff4444', 'important');
            a.el.style.setProperty('background', 'rgba(255,68,68,0.12)', 'important');
            b.el.style.setProperty('outline', '2px solid #ff4444', 'important');
            b.el.style.setProperty('background', 'rgba(255,68,68,0.12)', 'important');
          }
        }
      }
    });
  }

  detectOverlaps(cgDayMap, 'cg');
  detectOverlaps(patDayMap, 'pat');

  return { overlaps, hourDiffs, totalVisits: visits.length, visits };
}

function runVisitMaintenanceScan(resetAccumulated) {
  if (resetAccumulated) {
    _vmAllOverlaps = [];
    _vmAllDiffs = [];
    _vmTotalVisits = 0;
  }

  // Clear old highlights
  document.querySelectorAll('.ag-center-cols-container .ag-row').forEach(row => {
    row.style.removeProperty('background');
    row.style.removeProperty('outline');
  });

  const results = scanVisitMaintenancePage();

  // Accumulate results across pages
  _vmAllOverlaps = _vmAllOverlaps.concat(results.overlaps);
  _vmAllDiffs = _vmAllDiffs.concat(results.hourDiffs);
  _vmTotalVisits += results.totalVisits;

  // Remove old panel and show new
  const old = document.getElementById('cc-vm-panel');
  if (old) old.remove();

  injectApptPanel({
    overlaps: _vmAllOverlaps,
    hourDiffs: _vmAllDiffs,
    totalVisits: _vmTotalVisits,
    panelId: 'cc-vm-panel',
    title: '⚕ Care Crafter — Visit Maintenance'
  });

  // Add "Scan All Pages" button to footer
  const footer = document.getElementById('cc-vm-panel-footer');
  if (footer && !footer.querySelector('#cc-vm-scan-all')) {
    const scanAllBtn = document.createElement('button');
    scanAllBtn.id = 'cc-vm-scan-all';
    scanAllBtn.textContent = '📄 Scan All Pages';
    scanAllBtn.style.cssText = 'background:#1a3a1a;color:#69f0ae;border:1px solid #2a5a2a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;';
    scanAllBtn.addEventListener('click', () => scanAllVMPages());
    footer.insertBefore(scanAllBtn, footer.firstChild);
  }
}

async function scanAllVMPages() {
  if (_vmScanning) return;
  _vmScanning = true;
  _vmAllOverlaps = [];
  _vmAllDiffs = [];
  _vmTotalVisits = 0;

  const scanAllBtn = document.getElementById('cc-vm-scan-all');
  if (scanAllBtn) { scanAllBtn.textContent = '⏳ Scanning...'; scanAllBtn.disabled = true; }

  // Go to first page
  const firstBtn = document.querySelector('hhax-status-panel-pagination button[aria-label="Go to first page"]');
  if (firstBtn && !firstBtn.classList.contains('hhax-btn-disabled')) {
    firstBtn.click();
    await new Promise(r => setTimeout(r, 1500));
  }

  let pageNum = 1;
  while (true) {
    // Clear old highlights on this page
    document.querySelectorAll('.ag-center-cols-container .ag-row').forEach(row => {
      row.style.removeProperty('background');
      row.style.removeProperty('outline');
    });

    const results = scanVisitMaintenancePage();
    _vmAllOverlaps = _vmAllOverlaps.concat(results.overlaps);
    _vmAllDiffs = _vmAllDiffs.concat(results.hourDiffs);
    _vmTotalVisits += results.totalVisits;

    if (scanAllBtn) scanAllBtn.textContent = `⏳ Page ${pageNum}...`;

    // Try next page
    const nextBtn = document.querySelector('hhax-status-panel-pagination button[aria-label="Go to next page"]');
    if (!nextBtn || nextBtn.classList.contains('hhax-btn-disabled')) break;
    nextBtn.click();
    pageNum++;
    await new Promise(r => setTimeout(r, 1800));
  }

  _vmScanning = false;

  // Show accumulated results
  const old = document.getElementById('cc-vm-panel');
  if (old) old.remove();

  injectApptPanel({
    overlaps: _vmAllOverlaps,
    hourDiffs: _vmAllDiffs,
    totalVisits: _vmTotalVisits,
    panelId: 'cc-vm-panel',
    title: `⚕ Care Crafter — Visit Maintenance (All ${pageNum} pages)`
  });

  // Re-add scan all button
  const footer = document.getElementById('cc-vm-panel-footer');
  if (footer && !footer.querySelector('#cc-vm-scan-all')) {
    const btn2 = document.createElement('button');
    btn2.id = 'cc-vm-scan-all';
    btn2.textContent = '📄 Scan All Pages';
    btn2.style.cssText = 'background:#1a3a1a;color:#69f0ae;border:1px solid #2a5a2a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;';
    btn2.addEventListener('click', () => scanAllVMPages());
    footer.insertBefore(btn2, footer.firstChild);
  }
}

// ─── START ────────────────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// ─── APPOINTMENTS: SCAN ALL & REMEMBER ───────────────────────────

function injectApptRememberBtn() {
  if (document.getElementById('cc-appt-remember-wrap')) return;

  // Find anchor — try above the grid or near the search button
  const anchor = document.querySelector('.hhax-calendar-search-panel, #ctl00_ContentPlaceHolder1_uxBtnSearch, .hhax-search-panel');
  const gridWrap = document.getElementById('divPatientCalendarGrid-container') ||
                   document.getElementById('divCaregiverCalendarGrid-container');
  const insertTarget = anchor ? anchor.parentNode : (gridWrap ? gridWrap.parentNode : null);
  const insertBefore = anchor ? anchor.nextSibling : gridWrap;
  if (!insertTarget) return;

  const wrap = document.createElement('div');
  wrap.id = 'cc-appt-remember-wrap';
  wrap.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0;margin-bottom:4px;flex-wrap:wrap;';

  const btn = document.createElement('button');
  btn.id = 'cc-appt-remember-btn';
  btn.textContent = '💾 Scan All & Remember';
  btn.title = 'Scan all visits on this appointments grid and save to billing memory for use on the Add Internal Batch Invoice page';
  btn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 13px;font-size:12px;font-weight:bold;cursor:pointer;';

  const statusLbl = document.createElement('span');
  statusLbl.id = 'cc-appt-remember-status';
  statusLbl.style.cssText = 'font-size:11px;color:#aaa;';

  chrome.storage.local.get(['_cc_billing_memory'], r => {
    if (r._cc_billing_memory) {
      const d      = r._cc_billing_memory;
      const unconf = d.visits.filter(v => !v.isConfirmed).length;
      const ageMs  = Date.now() - new Date(d.savedAt).getTime();
      const ageHrs = Math.floor(ageMs / 3600000);
      const staleWarn = ageMs > 6 * 3600000 ? ` ⏰ ${ageHrs}h old` : '';
      const range  = d.dateRange ? ` · ${d.dateRange}` : '';
      statusLbl.textContent = `Saved ${new Date(d.savedAt).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})} ${new Date(d.savedAt).toLocaleDateString()}${range} · ${d.totalVisits} visits · ${unconf} unconfirmed${staleWarn}`;
      statusLbl.style.color = (unconf > 0 || ageMs > 6 * 3600000) ? '#ff8a80' : '#69f0ae';
    }
  });

  btn.addEventListener('click', () => scanApptAndRemember(btn, statusLbl));
  wrap.appendChild(btn);
  wrap.appendChild(statusLbl);
  insertTarget.insertBefore(wrap, insertBefore);
}

async function scanApptAndRemember(btn, statusLbl) {
  if (window._ccApptScanning) return;
  window._ccApptScanning = true;

  btn.textContent = '⏳ Scrolling...';
  btn.disabled = true;
  statusLbl.style.color = '#aaa';
  statusLbl.textContent = 'Scrolling to load all visits...';

  const patientGrid   = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');
  const activeGrid = (patientGrid  && patientGrid.children.length > 0) ? patientGrid  :
                     (caregiverGrid && caregiverGrid.children.length > 0) ? caregiverGrid : null;

  if (!activeGrid) {
    btn.textContent = '💾 Scan All & Remember';
    btn.disabled = false;
    statusLbl.style.color = '#f59e0b';
    statusLbl.textContent = '⚠ No grid found — run a search first';
    window._ccApptScanning = false;
    return;
  }

  const scrollEl = activeGrid.querySelector('.cg-container-wrap') || activeGrid;

  // ── FIX 1 (CRITICAL): Collect visits AT EACH scroll step, not after scrolling back.
  // The Appointments grid uses a virtualizing renderer — DOM nodes are recycled as
  // you scroll. If we scroll back to the top and collect, we only capture the first
  // screenful. We must snapshot every viewport as we pass through it.
  const allRecords = [];
  const seenKeys   = new Set();

  function collectVisibleVisits() {
    activeGrid.querySelectorAll('.cg-visit-item').forEach(block => {
      const visitId = block.getAttribute('data-visit-id') || '';

      const rowContainer = block.closest('.cg-row-container');
      if (!rowContainer) return;

      const calCell = block.closest('[data-date-value]');
      if (!calCell) return;
      const rawDate = calCell.getAttribute('data-date-value');
      if (!rawDate) return;

      // ── FIX 3: Prefer data-patient-id on .cg-patient-cell; fall back to data-row-id
      const patientCellEl = rowContainer.querySelector('.cg-patient-cell[data-patient-id]');
      const patientId = (patientCellEl ? patientCellEl.getAttribute('data-patient-id') : null)
                        || rowContainer.getAttribute('data-row-id');
      if (!patientId) return;

      const cgDiv        = block.querySelector('[data-caregiver-id]');
      const caregiverId  = cgDiv ? (cgDiv.getAttribute('data-caregiver-id') || '') : '';
      const caregiverName = cgDiv ? ((cgDiv.querySelector('.cg-text-link, span') || {}).textContent || '').trim() : '';

      // Dedup key: visitId if available, otherwise patient+date+caregiver combo
      const dedupKey = visitId || (patientId + '_' + rawDate + '_' + caregiverId + '_' + caregiverName);
      if (seenKeys.has(dedupKey)) return;
      seenKeys.add(dedupKey);

      const dm = rawDate.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      const dateNorm = dm ? dm[1].padStart(2,'0') + '/' + dm[2].padStart(2,'0') + '/' + dm[3] : rawDate;

      let clientName = '';
      const patCell = rowContainer.querySelector('.cg-patient-cell a.cg-word-break-string');
      if (patCell) clientName = patCell.textContent.trim().split('\n')[0].trim();

      const confirmedMinute = parseInt(block.getAttribute('data-confirmedminute') || '0');
      const scheduledMinute = parseInt(block.getAttribute('data-scheduledminute') || '0');

      // ── EVV confirmation check: use THREE independent signals ──
      // The virtualizing grid recycles DOM nodes during scroll, so child elements
      // like .cg-visit-evv spans may not be rendered when the snapshot is taken.
      // We therefore treat any ONE of three signals as sufficient proof of confirmation:
      //   1. confirmedFromTotal — [data-visittotal-id] text shows C:XX:XX > 0
      //      (HHAeXchange only calculates confirmed minutes after full EVV in+out)
      //   2. confirmedMinute > 0 — data-confirmedminute attribute > 0 (same meaning)
      //   3. hasFullEVV — both .cg-visit-evv spans present with non-zero times
      //      (clock-in AND clock-out both recorded)
      // Using AND between confirmed-minutes and hasFullEVV was wrong: a confirmed
      // visit whose EVV spans weren't rendered yet would be stored as unconfirmed,
      // causing the billing page to block it even after it was fully confirmed.
      const evvSpans = block.querySelectorAll('.cg-visit-evv');
      const evvIn    = evvSpans.length >= 1 ? evvSpans[0].textContent.trim() : '';
      const evvOut   = evvSpans.length >= 2 ? evvSpans[1].textContent.trim() : '';
      const hasFullEVV = evvIn  !== '' && evvIn  !== '0000'
                      && evvOut !== '' && evvOut !== '0000';

      // [data-visittotal-id] "S:05:00  C:05:03" — confirmed minutes from total element
      const totalEl = block.querySelector('[data-visittotal-id]');
      let confirmedFromTotal = false;
      if (totalEl) {
        const cm = totalEl.textContent.match(/C:(\d+):(\d+)/);
        if (cm) confirmedFromTotal = (parseInt(cm[1]) * 60 + parseInt(cm[2])) > 0;
      }

      // Any one signal is sufficient — OR instead of AND
      const isConfirmed = confirmedFromTotal || confirmedMinute > 0 || hasFullEVV;

      allRecords.push({
        patientId, date: dateNorm, caregiverName, caregiverId,
        clientName, visitId,
        schedMins:     scheduledMinute || null,
        confirmedMins: confirmedMinute || null,
        status:        isConfirmed ? 'Completed' : 'Prebilling',
        isConfirmed
      });
    });
  }

  // Collect initial viewport before any scrolling
  scrollEl.scrollTop = 0;
  await new Promise(r => setTimeout(r, 500));
  collectVisibleVisits();

  // Scroll down in steps — collect at EACH step so no virtualizer rows are missed
  const scrollStep = 300;
  let lastScrollTop = -1;
  let stuckCount = 0;

  while (true) {
    scrollEl.scrollTop += scrollStep;
    await new Promise(r => setTimeout(r, 200)); // 200ms gives virtualizer time to render

    collectVisibleVisits(); // snapshot every viewport as we pass through

    if (scrollEl.scrollTop === lastScrollTop) {
      stuckCount++;
      if (stuckCount >= 3) break; // reached bottom
    } else {
      stuckCount = 0;
    }
    lastScrollTop = scrollEl.scrollTop;

    const pct = Math.round((scrollEl.scrollTop / (scrollEl.scrollHeight - scrollEl.clientHeight || 1)) * 100);
    btn.textContent = `⏳ ${Math.min(pct, 99)}%...`;
    statusLbl.textContent = `Found ${allRecords.length} visits...`;
  }

  window._ccApptScanning = false;

  if (allRecords.length === 0) {
    btn.textContent = '💾 Scan All & Remember';
    btn.disabled = false;
    statusLbl.style.color = '#f59e0b';
    statusLbl.textContent = '⚠ No visits found — run a search first';
    return;
  }

  const unconfirmed  = allRecords.filter(v => !v.isConfirmed).length;
  const sortedDates  = allRecords.map(v => v.date).filter(Boolean).sort();
  const dateRangeStr = sortedDates.length
    ? sortedDates[0] + (sortedDates[sortedDates.length - 1] !== sortedDates[0] ? ' – ' + sortedDates[sortedDates.length - 1] : '')
    : '';

  const saveData = {
    savedAt:     new Date().toISOString(),
    totalVisits: allRecords.length,
    dateRange:   dateRangeStr,
    source:      'appointments',
    visits:      allRecords
  };

  chrome.storage.local.set({ _cc_billing_memory: saveData }, () => {
    btn.style.background  = '#1a3a1a';
    btn.style.color       = '#69f0ae';
    btn.style.borderColor = '#2a5a2a';
    btn.textContent = `✅ ${allRecords.length} visits saved`;
    btn.disabled = false;

    const sl = document.getElementById('cc-appt-remember-status');
    if (sl) {
      sl.style.color  = unconfirmed > 0 ? '#ff8a80' : '#69f0ae';
      sl.textContent  = `${allRecords.length} visits · ${unconfirmed} unconfirmed · ${dateRangeStr}`;
    }

    // Improvement: if the billing page is already open in this tab, auto-refresh overlay
    if (document.querySelector('.hhax-table-billing-grid')) {
      setTimeout(runBatchInvoiceOverlay, 600);
    }

    setTimeout(() => {
      btn.style.background  = '#0f3460';
      btn.style.color       = '#90caf9';
      btn.style.borderColor = '#2a4a8a';
      btn.textContent = '💾 Scan All & Remember';
    }, 5000);
  });
}

// ─── BILLING PAGE OVERLAY ─────────────────────────────────────────

function normDate(d) { return (d || '').replace(/\D/g, ''); }

function parseHrsToMins(s) {
  // "04:00" or "4:00" → minutes
  if (!s) return null;
  const m = s.trim().match(/^(\d+):(\d+)$/);
  if (!m) return null;
  return parseInt(m[1]) * 60 + parseInt(m[2]);
}

function fmtMins(m) {
  // 90 → "+1h 30m", -15 → "-15m"
  const sign = m >= 0 ? '+' : '-';
  const abs = Math.abs(m);
  const h = Math.floor(abs / 60);
  const mn = abs % 60;
  return h > 0 ? `${sign}${h}h${mn > 0 ? ' ' + mn + 'm' : ''}` : `${sign}${mn}m`;
}


// ── Helper: execute __doPostBack in page context via background script ──
function ccDoPostBack(target) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'doPostBack', target }, () => resolve());
  });
}
function initBatchInvoiceOverlay() {
  const marker = document.createElement('div');
  marker.id = 'cc-billing-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  setTimeout(runBatchInvoiceOverlay, 1000);

  // Re-run on page postbacks (classic ASP full reload on paging)
  const obs = new MutationObserver(() => {
    if (window._ccBillingScanning) return; // don't interfere with active scan
    clearTimeout(window._ccBillingTimer);
    window._ccBillingTimer = setTimeout(() => {
      if (document.querySelector('.hhax-table-billing-grid')) runBatchInvoiceOverlay();
    }, 800);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

function runBatchInvoiceOverlay() {
  // Clean up previous run
  document.querySelectorAll('.cc-billing-warn, .cc-diff-cell, .cc-diff-header').forEach(e => e.remove());
  document.querySelectorAll('tr.cc-billing-flagged').forEach(tr => {
    tr.style.removeProperty('background');
    tr.style.removeProperty('outline');
    tr.classList.remove('cc-billing-flagged');
  });
  document.querySelectorAll('.cc-billing-chk-disabled').forEach(chk => {
    chk.disabled = false; chk.classList.remove('cc-billing-chk-disabled');
  });

  chrome.storage.local.get(['_cc_billing_memory'], result => {
    const mem = result._cc_billing_memory;
    injectBillingMemoryBar(mem);
    injectBillingFloater(mem);

    // Inject "Diff" column header
    const thead = document.querySelector('.hhax-table-billing-grid thead tr, .hhax-table-billing-grid tbody tr:first-child[style*="bold"]');
    const thVisitHrs = Array.from(document.querySelectorAll('.hhax-table-billing-grid th')).find(th => th.textContent.trim() === 'Visit Hrs');
    if (thVisitHrs && !document.querySelector('.cc-diff-header')) {
      const thDiff = document.createElement('th');
      thDiff.className = 'cc-diff-header';
      thDiff.textContent = 'Diff';
      thDiff.style.cssText = 'text-align:left;color:#90caf9;font-size:11px;white-space:nowrap;';
      thVisitHrs.parentNode.insertBefore(thDiff, thVisitHrs.nextSibling);
    }

    if (!mem || !mem.visits || !mem.visits.length) {
      // No memory — add empty diff cells so table stays aligned
      document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
        const tds = tr.querySelectorAll('td');
        if (tds.length < 5) return;
        const tdDiff = document.createElement('td');
        tdDiff.className = 'cc-diff-cell';
        tdDiff.style.cssText = 'font-size:10px;color:#555;';
        tdDiff.textContent = '—';
        const visitHrsTd = tds[8]; // Visit Hrs is col index 8 (0-based: chk,date,cg,admid,member,office,mco,visit,visitHrs...)
        if (visitHrsTd) visitHrsTd.parentNode.insertBefore(tdDiff, visitHrsTd.nextSibling);
      });
      return;
    }

    // Build TWO lookups:
    // 1. visitId → record (exact match via hidden input)
    // 2. patientId+dateNorm → [records] (fallback for unconfirmed blocking)
    const visitLookup = {};   // visitId → record
    const patDateLookup = {}; // patientId_date → [records]
    mem.visits.forEach(v => {
      if (v.visitId) visitLookup[v.visitId] = v;
      const key = v.patientId + '_' + normDate(v.date);
      if (!patDateLookup[key]) patDateLookup[key] = [];
      patDateLookup[key].push(v);
    });

    const diffRows = []; // for floater summary
    let missingFromMemory = 0; // rows where visitId not found in memory

    const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 5) return;

      const dateText = (tds[1] ? tds[1].textContent.trim() : '');
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;

      // PatientId from link
      const patientLink = tr.querySelector('a[href*="PatientId="], a[onclick*="PatientId="]');
      if (!patientLink) return;
      const src = patientLink.href || patientLink.getAttribute('onclick') || '';
      const pidM = src.match(/PatientId=(\d+)/);
      if (!pidM) return;
      const patientId = pidM[1];

      // VisitId from hidden input — exact match key
      const hidVisit = tr.querySelector('input.hidVisitID');
      const visitId = hidVisit ? hidVisit.value : null;

      // Caregiver name from col 2 (for display in tooltip)
      const cgName = tds[2] ? tds[2].textContent.trim() : '';

      // Actual visit hrs from col 8 (Visit Hrs: "04:00")
      const visitHrsTd = tds[8];
      const actualHrsStr = visitHrsTd ? visitHrsTd.textContent.trim() : '';
      const actualMins = parseHrsToMins(actualHrsStr);

      // Member name from col 4
      const memberName = tds[4] ? tds[4].textContent.trim() : '';

      // Exact record by visitId (same visit ID on appt page data-visit-id)
      const exactRecord = visitId ? visitLookup[visitId] : null;

      // All records for this patient+date (for unconfirmed blocking check)
      const patDateKey = patientId + '_' + normDate(dateText);
      const patDateMatched = patDateLookup[patDateKey];

      // ── Diff cell — use exactRecord for precise sched hrs ──
      const tdDiff = document.createElement('td');
      tdDiff.className = 'cc-diff-cell';
      tdDiff.style.cssText = 'font-size:11px;font-weight:bold;white-space:nowrap;';

      if (exactRecord && actualMins !== null && exactRecord.schedMins) {
        const schedMins = exactRecord.schedMins;
        const diffMins = actualMins - schedMins;
        const absDiff = Math.abs(diffMins);
        const schedLabel = `${Math.floor(schedMins/60)}h${schedMins%60>0?' '+schedMins%60+'m':''}`;
        tdDiff.title = `Sched: ${schedLabel} / Actual: ${actualHrsStr} / DCW ID: ${exactRecord.caregiverId||'?'}`;
        if (absDiff < 5) {
          tdDiff.style.color = '#69f0ae';
          tdDiff.textContent = '✓';
        } else {
          tdDiff.style.color = diffMins > 0 ? '#ff8a80' : '#ffd740';
          tdDiff.textContent = fmtMins(diffMins);
          if (absDiff >= 15) {
            diffRows.push({ caregiver: cgName, caregiverId: exactRecord.caregiverId, member: memberName, date: dateText, diff: diffMins, actual: actualHrsStr, sched: schedMins });
          }
        }
      } else {
        tdDiff.style.color = '#555';
        tdDiff.textContent = '—';
        if (!exactRecord) {
          missingFromMemory++;
          tdDiff.title = 'Visit not found in memory — re-scan Appointments page';
        } else {
          tdDiff.title = 'No scheduled hours saved for this visit';
        }
      }

      if (visitHrsTd) visitHrsTd.parentNode.insertBefore(tdDiff, visitHrsTd.nextSibling);

      // ── Flag unconfirmed rows ──
      // Cross-DCW blocking only needs patDateMatched (other DCWs on same patient+date).
      // exactRecord is used for "own visit unconfirmed" check, but absence of it must
      // NOT skip the cross-DCW check — if another DCW is unconfirmed we still block.
      if (!patDateMatched) return;

      // Use caregiverId from exactRecord when available; fall back to name from billing row.
      const thisCaregiversId = exactRecord ? exactRecord.caregiverId : null;

      // Compare by ID when both sides have one (most reliable).
      // Fall back to normalized-name comparison when IDs are missing so unconfirmed
      // DCWs without IDs are still caught.
      const normCgStr = s => (s || '').trim().toUpperCase().replace(/\s+/g, ' ');
      const unconfirmed = patDateMatched.filter(v => {
        if (v.isConfirmed) return false;
        if (thisCaregiversId && v.caregiverId) return v.caregiverId !== thisCaregiversId;
        // At least one side is missing an ID — fall back to name
        return normCgStr(v.caregiverName) !== normCgStr(cgName);
      });

      // Also block if THIS DCW's own visit is unconfirmed (requires exactRecord)
      const thisVisitUnconfirmed = exactRecord ? !exactRecord.isConfirmed : false;

      if (unconfirmed.length === 0 && !thisVisitUnconfirmed) return;

      tr.style.setProperty('background', 'rgba(255,68,68,0.13)', 'important');
      tr.style.setProperty('outline', '2px solid #ff4444', 'important');
      tr.classList.add('cc-billing-flagged');

      // FIX Bug 1: Build a complete warn message that shows BOTH issues when
      // both apply — this visit is unconfirmed AND another DCW is also blocking.
      const warnParts = [];
      if (thisVisitUnconfirmed) {
        warnParts.push(`⚠ This visit is unconfirmed\n   Patient: ${memberName}\n   DCW: ${cgName}${exactRecord.caregiverId ? ' (ID: ' + exactRecord.caregiverId + ')' : ''}`);
      }
      if (unconfirmed.length > 0) {
        const names  = [...new Set(unconfirmed.map(v => v.caregiverName))].filter(Boolean).join(', ') || 'Unknown DCW';
        const idList = [...new Set(unconfirmed.map(v => v.caregiverId).filter(Boolean))].join(', ');
        warnParts.push(`🚫 Cannot bill — another DCW is unconfirmed on this date\n   Patient: ${memberName}\n   Blocking DCW: ${names}${idList ? ' (ID: ' + idList + ')' : ''}`);
      }
      const warnMsg = warnParts.join('\n');

      const warn = document.createElement('span');
      warn.className = 'cc-billing-warn';
      warn.textContent = ' 🚫';
      warn.title = warnMsg;
      warn.style.cssText = 'cursor:help;font-size:13px;';
      tds[1].appendChild(warn);

      const chk = tr.querySelector('input[type="checkbox"]');
      if (chk) { chk.disabled = true; chk.classList.add('cc-billing-chk-disabled'); chk.title = warnMsg; }
    });

    // Update floater with diff summary + missing count
    window._ccBillingMissing = missingFromMemory;
    injectBillingMemoryBar(mem); // re-render bar with fresh missing count
    updateBillingFloater(mem, diffRows);
  });
}

function injectBillingMemoryBar(mem) {
  const old = document.getElementById('cc-billing-bar');
  if (old) old.remove();
  const bar = document.createElement('div');
  bar.id = 'cc-billing-bar';
  const resultsDiv = document.getElementById('ctl00_ContentPlaceHolder1_uxtblSearchResults');
  if (!resultsDiv) return;

  if (!mem || !mem.visits || !mem.visits.length) {
    bar.style.cssText = 'background:#1a1a0d;border:1px solid #f59e0b;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#f59e0b;display:flex;align-items:center;gap:8px;';
    bar.innerHTML = '<span style="font-size:16px;">⚠️</span><span><b>Care Crafter:</b> No visit memory saved. Go to <b>Appointments</b> page, run a search, then click <b>💾 Scan All & Remember</b>.</span>';
    resultsDiv.parentNode.insertBefore(bar, resultsDiv);
    return;
  }

  const dt       = new Date(mem.savedAt);
  const ageMs    = Date.now() - dt.getTime();
  const ageHrs   = Math.floor(ageMs / 3600000);
  const stale    = ageMs > 6 * 3600000; // >6 hours old
  const unconf   = mem.visits.filter(v => !v.isConfirmed).length;
  const missing  = window._ccBillingMissing || 0;
  const dateRange = mem.dateRange || '';

  // Check if any billing row dates fall outside memory's date coverage
  const memDateSet = new Set(mem.visits.map(v => normDate(v.date)));
  const billingDates = new Set();
  document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
    const tds = tr.querySelectorAll('td');
    if (tds.length < 2) return;
    const m = tds[1].textContent.match(/(\d{2}\/\d{2}\/\d{4})/);
    if (m) billingDates.add(normDate(m[1]));
  });
  const outOfRange = [...billingDates].filter(d => !memDateSet.has(d));
  const dateMismatch = outOfRange.length > 0;

  let parts = [];
  parts.push(`<b>Care Crafter Memory Active</b>`);
  parts.push(`${mem.totalVisits} visits`);
  if (dateRange) parts.push(`<span style="color:#aaa;">${dateRange}</span>`);
  parts.push(`saved ${dt.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})} on ${dt.toLocaleDateString()}`);
  if (unconf > 0) parts.push(`<span style="color:#ff6b6b;font-weight:bold;">${unconf} unconfirmed → 🚫 blocked</span>`);
  if (missing > 0) parts.push(`<span style="color:#ffd740;">⚠ ${missing} billing rows not in memory — re-scan Appointments</span>`);

  if (stale || dateMismatch) {
    bar.style.cssText = 'background:#1a1200;border:1px solid #f59e0b;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#f59e0b;display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
    let warn = '';
    if (stale)        warn += ` ⏰ Memory is ${ageHrs}h old — re-scan Appointments for accuracy.`;
    if (dateMismatch) warn += ` 📅 Billing dates not covered by memory (${outOfRange.length} date(s)) — re-scan to include them.`;
    bar.innerHTML = `<span style="font-size:16px;">🧠</span><span>${parts.join(' · ')}</span><span style="color:#f59e0b;font-size:11px;">${warn}</span>`;
  } else {
    bar.style.cssText = 'background:#0d1a0d;border:1px solid #2a5a2a;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#69f0ae;display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
    bar.innerHTML = `<span style="font-size:16px;">🧠</span><span>${parts.join(' · ')}</span>`;
  }

  resultsDiv.parentNode.insertBefore(bar, resultsDiv);
}

function injectBillingFloater(mem) {
  if (document.getElementById('cc-billing-floater')) return;

  const savedPos = JSON.parse(localStorage.getItem('_cc_billing_floater_pos') || 'null');
  const savedSize = JSON.parse(localStorage.getItem('_cc_billing_floater_size') || 'null');

  const panel = document.createElement('div');
  panel.id = 'cc-billing-floater';
  panel.style.cssText = `
    position:fixed; z-index:999999;
    top:${savedPos ? savedPos.top + 'px' : '70px'};
    left:${savedPos ? savedPos.left + 'px' : 'auto'};
    right:${savedPos ? 'auto' : '16px'};
    width:${savedSize ? savedSize.w + 'px' : '340px'};
    min-width:240px; min-height:80px; max-height:80vh;
    background:#1a1a2e; color:#e0e0e0;
    border-radius:10px; box-shadow:0 4px 24px rgba(0,0,0,0.6);
    border:1px solid #334; font-family:'Segoe UI',monospace; font-size:12px;
    overflow:hidden; resize:both;
    ${savedSize ? `height:${savedSize.h}px;` : ''}
  `;

  panel.innerHTML = `
    <div id="cc-bf-header" style="background:linear-gradient(135deg,#0f3460,#16213e);
      padding:10px 14px;display:flex;justify-content:space-between;align-items:center;
      border-radius:10px 10px 0 0;cursor:move;user-select:none;">
      <span style="font-weight:bold;font-size:13px;">💊 Care Crafter — Billing</span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="cc-bf-minimize" style="font-size:11px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="cc-bf-close" style="cursor:pointer;font-size:16px;color:#aaa;" title="Close">✕</span>
      </div>
    </div>
    <div id="cc-bf-body" style="overflow-y:auto;max-height:calc(80vh - 80px);padding:10px 14px;">
      <div id="cc-bf-content" style="color:#aaa;text-align:center;padding:16px 0;">
        <div style="font-size:20px;">🔍</div>
        <div style="margin-top:6px;font-size:11px;">Loading billing analysis...</div>
      </div>
    </div>
  `;

  document.body.appendChild(panel);

  // Event delegation — scan button survives innerHTML updates
  panel.querySelector('#cc-bf-body').addEventListener('click', e => {
    if (e.target.id === 'cc-bf-scan-all' || e.target.closest('#cc-bf-scan-all')) {
      const btn = document.getElementById('cc-bf-scan-all');
      const status = document.getElementById('cc-bf-scan-status');
      if (btn) { btn.textContent = '⏳ Starting...'; btn.disabled = true; btn.style.background = '#1a3a1a'; btn.style.color = '#69f0ae'; }
      if (status) status.textContent = 'Injecting scan into page...';
      // Run scan in MAIN world so it survives ASP.NET postbacks
      chrome.runtime.sendMessage({ action: 'runBillingScanInPage' }, () => {
        // Poll for results from MAIN world scan
        const poll = setInterval(() => {
          if (!window._ccPageScanResults?.done) return;
          clearInterval(poll);

          const r = window._ccPageScanResults;
          window._ccPageScanResults = null;

          chrome.storage.local.get(['_cc_billing_memory'], result => {
            const mem = result._cc_billing_memory;

            // Build lookups from memory
            const visitLookup   = {};
            const patDateLookup = {};
            if (mem && mem.visits) {
              mem.visits.forEach(v => {
                if (v.visitId) visitLookup[v.visitId] = v;
                const key = v.patientId + '_' + normDate(v.date);
                if (!patDateLookup[key]) patDateLookup[key] = [];
                patDateLookup[key].push(v);
              });
            }

            // Process each scanned row
            let totalBlocked = 0;
            const allDiffs = [];
            const seen = new Set();

            r.rows.forEach(row => {
              const exactRecord = row.visitId ? visitLookup[row.visitId] : null;
              const patDateKey  = row.patientId + '_' + normDate(row.date);
              const patDateMatched = patDateLookup[patDateKey];
              const thisId = exactRecord ? exactRecord.caregiverId : null;

              // Check blocked
              if (patDateMatched) {
                const unconf = patDateMatched.filter(v => {
                  if (v.isConfirmed) return false;
                  if (!thisId || !v.caregiverId) return v.caregiverName !== row.caregiver;
                  return v.caregiverId !== thisId;
                });
                const thisUnconf = exactRecord && !exactRecord.isConfirmed;
                if ((unconf.length > 0 || thisUnconf) && !seen.has(row.visitId)) {
                  seen.add(row.visitId);
                  totalBlocked++;
                }
              }

              // Check diff
              const actualMins = parseHrsToMins(row.visitHrs);
              if (exactRecord && actualMins !== null && exactRecord.schedMins) {
                const diffMins = actualMins - exactRecord.schedMins;
                if (Math.abs(diffMins) >= 15) {
                  allDiffs.push({
                    caregiver:   row.caregiver,
                    caregiverId: exactRecord.caregiverId,
                    member:      row.member,
                    date:        row.date,
                    diff:        diffMins,
                    actual:      row.visitHrs,
                    sched:       exactRecord.schedMins
                  });
                }
              }
            });

            window._ccBillingScanData = {
              totalRows: r.totalRows,
              pages:     r.pages,
              blocked:   totalBlocked,
              diffs:     allDiffs
            };

            updateBillingFloater(mem, allDiffs);
          });
        }, 1000);
        setTimeout(() => clearInterval(poll), 600000);
      });
    }
  });

  // Save size
  const ro = new ResizeObserver(() => {
    localStorage.setItem('_cc_billing_floater_size', JSON.stringify({ w: panel.offsetWidth, h: panel.offsetHeight }));
  });
  ro.observe(panel);

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector('#cc-bf-header');
  header.addEventListener('mousedown', e => {
    if (['cc-bf-close','cc-bf-minimize'].includes(e.target.id)) return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const left = e.clientX - dragX;
    const top  = e.clientY - dragY;
    panel.style.left = left + 'px';
    panel.style.top  = top  + 'px';
    localStorage.setItem('_cc_billing_floater_pos', JSON.stringify({ left, top }));
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // Minimize
  let minimized = false;
  panel.querySelector('#cc-bf-minimize').addEventListener('click', e => {
    e.stopPropagation();
    minimized = !minimized;
    const body = panel.querySelector('#cc-bf-body');
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      body.style.overflow = 'hidden'; body.style.height = '0'; body.style.padding = '0';
      panel.style.height = 'auto'; panel.style.maxHeight = 'none'; panel.style.minHeight = '0'; panel.style.resize = 'none';
    } else {
      body.style.overflow = ''; body.style.height = ''; body.style.padding = '';
      panel.style.height = panel.dataset.fullH || ''; panel.style.maxHeight = '80vh'; panel.style.minHeight = '80px'; panel.style.resize = 'both';
    }
    panel.querySelector('#cc-bf-minimize').textContent = minimized ? '□' : '─';
  });

  panel.querySelector('#cc-bf-close').addEventListener('click', () => panel.remove());
}

function updateBillingFloater(mem, diffRows) {
  const content = document.getElementById('cc-bf-content');
  if (!content) return;

  if (!mem || !mem.visits) {
    content.innerHTML = `<div style="color:#f59e0b;text-align:center;padding:12px;">⚠ No memory loaded</div>`;
    return;
  }

  // ── Same-name DCW detection from memory ──
  // Group by caregiverName → collect unique caregiverIds
  const nameToIds = {};
  mem.visits.forEach(v => {
    if (!v.caregiverName) return;
    const name = v.caregiverName.trim();
    if (!nameToIds[name]) nameToIds[name] = new Set();
    if (v.caregiverId) nameToIds[name].add(v.caregiverId);
  });
  const duplicateNames = Object.entries(nameToIds).filter(([, ids]) => ids.size > 1);

  const flagged   = document.querySelectorAll('tr.cc-billing-flagged').length;
  const scanData  = window._ccBillingScanData || null;

  let html = '';

  // ── Stats row ──
  const totalScanned = scanData ? scanData.totalRows : '?';
  const blockedCount = scanData ? scanData.blocked : flagged;
  const diffCount    = scanData ? scanData.diffs.length : diffRows.length;
  const activeDiffs  = scanData ? scanData.diffs : diffRows;

  html += `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:10px;">
      <div style="background:#0d1a0d;border:1px solid #2a5a2a;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#69f0ae;">${totalScanned}</div>
        <div style="font-size:9px;color:#aaa;">visits scanned</div>
      </div>
      <div style="background:#1a0f0f;border:1px solid #ff4444;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#ff6b6b;">${blockedCount}</div>
        <div style="font-size:9px;color:#aaa;">blocked rows</div>
      </div>
      <div style="background:#1a1600;border:1px solid #ffd740;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#ffd740;">${diffCount}</div>
        <div style="font-size:9px;color:#aaa;">time diffs</div>
      </div>
    </div>`;

  // ── Same-name DCW warning ──
  if (duplicateNames.length > 0) {
    html += `<div style="background:#1a0d1a;border:1px solid #ce93d8;border-radius:6px;padding:8px 10px;margin-bottom:10px;">
      <div style="color:#ce93d8;font-weight:bold;font-size:11px;margin-bottom:6px;">⚠ SAME NAME — DIFFERENT DCW ID</div>`;
    duplicateNames.forEach(([name, ids]) => {
      // Count visits per caregiverId for this name
      const idCounts = {};
      mem.visits.filter(v => v.caregiverName && v.caregiverName.trim() === name).forEach(v => {
        const id = v.caregiverId || 'unknown';
        idCounts[id] = (idCounts[id] || 0) + 1;
      });
      html += `<div style="margin-bottom:6px;">
        <div style="color:#e0e0e0;font-weight:bold;font-size:11px;">${name}</div>`;
      Object.entries(idCounts).forEach(([id, count]) => {
        html += `<div style="display:flex;justify-content:space-between;padding:2px 8px;font-size:10px;color:#aaa;">
          <span>ID: <span style="color:#ce93d8;font-weight:bold;">${id}</span></span>
          <span style="color:#e0e0e0;">${count} visit${count>1?'s':''}</span>
        </div>`;
      });
      html += `</div>`;
    });
    html += `</div>`;
  }

  // ── Scan all pages button ──
  html += `<div style="margin-bottom:10px;">
    <button id="cc-bf-scan-all" style="width:100%;background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;
      border-radius:6px;padding:7px;font-size:11px;font-weight:bold;cursor:pointer;">
      📄 Scan All Billing Pages
    </button>
    <div id="cc-bf-scan-status" style="font-size:10px;color:#888;text-align:center;margin-top:4px;">
      ${scanData ? `Last scan: ${scanData.totalRows} visits across ${scanData.pages} pages` : 'Scans all pages automatically'}
    </div>
  </div>`;

  // ── Time diffs ──
  if (activeDiffs.length > 0) {
    html += `<div style="color:#ffd740;font-weight:bold;font-size:11px;margin-bottom:6px;">⚠ TIME DIFFERENCES ≥15min</div>`;
    activeDiffs.forEach(d => {
      const col   = d.diff > 0 ? '#ff8a80' : '#ffd740';
      const arrow = d.diff > 0 ? '↑ Over' : '↓ Under';
      const schedH = Math.floor(Math.abs(d.sched)/60);
      const schedM = d.sched % 60;
      html += `
        <div style="background:#1a1600;border-left:3px solid ${col};border-radius:4px;padding:6px 9px;margin-bottom:5px;">
          <div style="display:flex;justify-content:space-between;">
            <span style="color:#e0e0e0;font-weight:bold;font-size:11px;">${d.caregiver}</span>
            <span style="color:${col};font-size:11px;font-weight:bold;">${arrow} ${fmtMins(d.diff)}</span>
          </div>
          <div style="color:#888;font-size:10px;margin-top:1px;">${d.member} — ${d.date}</div>
          <div style="display:flex;gap:5px;margin-top:3px;">
            <span style="background:#111;padding:2px 5px;border-radius:3px;font-size:10px;color:#aaa;">S: ${schedH}h${schedM>0?' '+schedM+'m':''}</span>
            <span style="background:#111;padding:2px 5px;border-radius:3px;font-size:10px;color:${col};">A: ${d.actual}</span>
          </div>
        </div>`;
    });
  }

  if (blockedCount === 0 && activeDiffs.length === 0 && duplicateNames.length === 0) {
    html += `<div style="color:#69f0ae;text-align:center;padding:12px 0;">
      <div style="font-size:22px;">✅</div>
      <div style="margin-top:5px;font-weight:bold;">All Clear!</div>
      <div style="color:#aaa;font-size:10px;margin-top:3px;">No blocks, diffs, or duplicate names.</div>
    </div>`;
  }

  content.innerHTML = html;
  // Note: scan button click handled by event delegation on #cc-bf-body
}

async function scanAllBillingPages(mem) {
  // Reset stuck flag
  window._ccBillingScanning = false;

  const scanBtn    = document.getElementById('cc-bf-scan-all');
  const scanStatus = document.getElementById('cc-bf-scan-status');

  window._ccBillingScanning = true;
  if (scanBtn) { scanBtn.textContent = '⏳ Scanning...'; scanBtn.disabled = true; scanBtn.style.background = '#1a3a1a'; scanBtn.style.color = '#69f0ae'; }

  const visitLookup   = {};
  const patDateLookup = {};
  if (mem && mem.visits) {
    mem.visits.forEach(v => {
      if (v.visitId) visitLookup[v.visitId] = v;
      const key = v.patientId + '_' + normDate(v.date);
      if (!patDateLookup[key]) patDateLookup[key] = [];
      patDateLookup[key].push(v);
    });
  }

  let pageNum = 1, totalRows = 0, totalBlocked = 0;
  const allDiffs = [];

  async function waitForPageChange(oldFirstId) {
    await new Promise(resolve => {
      let attempts = 0;
      const check = setInterval(() => {
        attempts++;
        const el  = document.querySelector('.hhax-table-billing-grid input.hidVisitID');
        const nid = el ? el.value : null;
        if ((nid && nid !== oldFirstId) || attempts >= 100) {
          clearInterval(check); resolve();
        }
      }, 200);
    });
    await new Promise(r => setTimeout(r, 500));
  }

  // Go to page 1 if not already there
  const currentPageEl = document.getElementById('ctl00_ContentPlaceHolder1_uxLblCurrent');
  const currentPage   = currentPageEl ? parseInt(currentPageEl.textContent.trim()) : 1;
  if (currentPage > 1) {
    const firstBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnFirst');
    if (firstBtn && firstBtn.style.display !== 'none') {
      const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
      firstBtn.click();
      await waitForPageChange(oldId);
    }
  }

  function scanCurrentPage() {
    const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 5) return;
      const dateText = tds[1] ? tds[1].textContent.trim() : '';
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;
      totalRows++;

      const hidVisit    = tr.querySelector('input.hidVisitID');
      const visitId     = hidVisit ? hidVisit.value : null;
      const exactRecord = visitId ? visitLookup[visitId] : null;
      const cgName      = tds[2] ? tds[2].textContent.trim() : '';
      const memberName  = tds[4] ? tds[4].textContent.trim() : '';

      const patientLink = tr.querySelector('a[href*="PatientId="], a[onclick*="PatientId="]');
      if (patientLink) {
        const src  = patientLink.href || patientLink.getAttribute('onclick') || '';
        const pidM = src.match(/PatientId=(\d+)/);
        if (pidM) {
          const patDateKey     = pidM[1] + '_' + normDate(dateText);
          const patDateMatched = patDateLookup[patDateKey];
          const thisId         = exactRecord ? exactRecord.caregiverId : null;
          if (patDateMatched) {
            const unconf = patDateMatched.filter(v => {
              if (v.isConfirmed) return false;
              if (!thisId || !v.caregiverId) return v.caregiverName !== cgName;
              return v.caregiverId !== thisId;
            });
            const thisUnconf = exactRecord && !exactRecord.isConfirmed;
            if (unconf.length > 0 || thisUnconf) totalBlocked++;
          }
        }
      }

      const visitHrsTd   = tds[8];
      const actualHrsStr = visitHrsTd ? visitHrsTd.textContent.trim() : '';
      const actualMins   = parseHrsToMins(actualHrsStr);
      if (exactRecord && actualMins !== null && exactRecord.schedMins) {
        const diffMins = actualMins - exactRecord.schedMins;
        if (Math.abs(diffMins) >= 15) {
          allDiffs.push({ caregiver: cgName, caregiverId: exactRecord.caregiverId, member: memberName, date: dateText, diff: diffMins, actual: actualHrsStr, sched: exactRecord.schedMins });
        }
      }
    });
  }

  while (true) {
    if (scanStatus) scanStatus.textContent = `Scanning page ${pageNum}...`;
    if (scanBtn)    scanBtn.textContent    = `⏳ Page ${pageNum}...`;

    scanCurrentPage();

    const nextBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnNext');
    if (!nextBtn || nextBtn.style.display === 'none') break;
    if (!nextBtn.href || !nextBtn.href.includes('doPostBack')) break;

    const oldFirstId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
    nextBtn.click();
    await waitForPageChange(oldFirstId);

    const newFirstId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
    if (!newFirstId || newFirstId === oldFirstId) break;

    pageNum++;
    if (pageNum > 300) break;
  }

  window._ccBillingScanData = { totalRows, blocked: totalBlocked, diffs: allDiffs, pages: pageNum };
  window._ccBillingScanning = false;

  if (scanStatus) scanStatus.textContent = `Done — ${totalRows} visits across ${pageNum} pages`;
  if (scanBtn) {
    scanBtn.textContent  = '📄 Scan All Billing Pages';
    scanBtn.disabled     = false;
    scanBtn.style.background = '#0f3460';
    scanBtn.style.color  = '#90caf9';
  }

  // Re-run overlay to refresh highlights and floater after scan
  setTimeout(runBatchInvoiceOverlay, 600);

  chrome.storage.local.get(['_cc_billing_memory'], result => {
    updateBillingFloater(result._cc_billing_memory, allDiffs);
  });
}

} // end initExtension
