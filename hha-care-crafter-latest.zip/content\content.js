// ─── HHA Care Crafter Content Script ─────────────────────────────

// License check — stop everything if expired, not activated, or the remote
// kill switch (Admin Panel -> Extension Live/Disabled toggle) has been
// flipped off. _cc_ext_enabled defaults to undefined until background.js's
// first check completes; treat that as enabled so a fresh install isn't
// blocked before the first fetch lands.
(function() {
  chrome.storage.local.get(['_xa', '_xe', '_cc_ext_enabled'], result => {
    const activated = result._xa || false;
    const expiry    = result._xe    || null;
    const expired   = !expiry || Date.now() > expiry;
    const killed    = result._cc_ext_enabled === false;
    if (!activated || expired || killed) {
      return;
    }
    initExtension();
  });
})();

function initExtension() {


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'evvScan')    { sendResponse({ items: runEVVScan() });    return true; }
  if (message.action === 'claimScan') { sendResponse({ items: runClaimScan() });  return true; }
  if (message.action === 'missedScan'){ sendResponse({ items: runMissedScan() }); return true; }
});

// ─── INIT ─────────────────────────────────────────────────────────
function init() {
  if (!window.location.href.includes('hhaexchange.com')) return;
  setTimeout(detectPageAndRun, 800);
  setTimeout(detectPageAndRun, 2000);
  setTimeout(detectPageAndRun, 4000);

  // ── Watch for calendar month navigation ───────────────────────────────
  // Hook the Go button directly AND watch the UpdatePanel for DOM changes
  let calRescanTimer = null;

  function rerunCalendar() {
    clearTimeout(calRescanTimer);
    calRescanTimer = setTimeout(() => {
      // Remove old CC injections so they get rebuilt fresh
      document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
      document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
        el.style.removeProperty('outline');
        el.style.removeProperty('background-color');
        el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
      });
      const bodyText = document.body.innerText;
      const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
      const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
      if (hasClientCal) runClientCalendar();
      else if (hasCaregiverCal) runCaregiverCalendar();
      // If no cells found yet, retry once more after longer delay
      else setTimeout(() => {
        const bt = document.body.innerText;
        if (bt.includes('Billed:') && bt.includes('S:')) runClientCalendar();
        else if (bt.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bt.includes('IO')) runCaregiverCalendar();
      }, 2000);
    }, 1500);
  }

  // Hook Go button click directly — most reliable trigger
  function hookCalGoButton() {
    const goBtn = document.getElementById('uxbtnSearch') ||
                  document.getElementById('ctl00_ContentPlaceHolder1_uxBtnGo') ||
                  document.querySelector('input[value="Go"]');
    if (goBtn && !goBtn._ccHooked) {
      goBtn._ccHooked = true;
      goBtn.addEventListener('click', () => setTimeout(rerunCalendar, 1500));
    }
    // Also hook prev/next arrow buttons
    document.querySelectorAll('#btnPrevMonth, #btnNextMonth, input[value="<"], input[value=">"]').forEach(btn => {
      if (!btn._ccHooked) {
        btn._ccHooked = true;
        btn.addEventListener('click', () => setTimeout(rerunCalendar, 1500));
      }
    });

    // Inject "⏱ Hour Counter" button next to Go button
    if (goBtn && !document.getElementById('cc-hour-counter-btn')) {
      const btn = document.createElement('button');
      btn.id = 'cc-hour-counter-btn';
      btn.textContent = '⏱ Hour Counter';
      btn.title = 'Calculate scheduled vs actual hours per caregiver for this month';
      btn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:12px;font-weight:bold;cursor:pointer;margin-left:8px;vertical-align:middle;';
      btn.addEventListener('click', () => {
        // Clean up old injections first
        document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner,.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
        document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
          el.style.removeProperty('outline');
          el.style.removeProperty('background-color');
          el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
        });
        document.querySelectorAll('table').forEach(t => {
          t.style.removeProperty('outline');
          t.style.removeProperty('background-color');
        });
        btn.textContent = '⏳ Calculating...';
        btn.disabled = true;
        setTimeout(() => {
          const bodyText = document.body.innerText;
          const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
          const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
          if (hasClientCal) runClientCalendar();
          else if (hasCaregiverCal) runCaregiverCalendar();
          btn.textContent = '⏱ Hour Counter';
          btn.disabled = false;
        }, 300);
      });
      // Insert right after Go button
      goBtn.parentNode.insertBefore(btn, goBtn.nextSibling);
    }
  }
  hookCalGoButton();
  setTimeout(hookCalGoButton, 2000); // retry after page settles

  // Also watch UpdatePanel for AJAX reloads
  const calObs = new MutationObserver(() => rerunCalendar());
  const updatePanel = document.getElementById('ctl00_ContentPlaceHolder1_UpdatePanel1') ||
                      document.getElementById('ContentPlaceHolder1_UpdatePanel1') ||
                      document.querySelector('[id*="UpdatePanel"]');
  if (updatePanel) {
    calObs.observe(updatePanel, { childList: true, subtree: false });
  }

  // ── Watch for Visit Maintenance page to load (Angular SPA navigation) ──
  let vmCheckTimer = null;
  const spaObs = new MutationObserver(() => {
    clearTimeout(vmCheckTimer);
    vmCheckTimer = setTimeout(() => {
      if (document.querySelector('hhax-visits-filter-result') && !document.getElementById('cc-vm-init')) {
        initVisitMaintenanceScanner();
      }
    }, 1500);
  });
  spaObs.observe(document.body, { childList: true, subtree: false });
}

function detectPageAndRun() {
  const bodyText = document.body.innerText;
  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
  const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
  const isAppointmentsPage  = window.location.href.includes('Appointments_ns.aspx');
  const isMasterWeekPage    = window.location.href.includes('InternalPatientMasterWeekIFrame_ns.aspx');
  const isPatientSearchPage = window.location.href.includes('PatientSearchXSLTIFrame_ns.aspx') || window.location.href.includes('PatientSearch_ns.aspx');
  const isPatientResultsPage = window.location.href.includes('PatientSearchXSLTIFrame_ns.aspx');
  const isCaregiverSearchPage = window.location.href.includes('CaregiverSearch_ns.aspx') || window.location.href.includes('CaregiverSearch.aspx');
  const isPrebillingPage = window.location.href.includes('PrebillingReport');
  const isVisitMaintenancePage = window.location.href.includes('VisitMaintenance') || document.querySelector('hhax-visits-filter-result') !== null;
  const isBatchInvoicePage = window.location.href.includes('BillProcessInternal') || window.location.href.includes('AddInternalBatchInvoice') || !!document.querySelector('.hhax-table-billing-grid');


  // Client-level Master Week auth table
  const mwAuthTable = document.getElementById('uxUclMasterWeek_PatientAuthorizations_uxGvAuthorization');
  if (mwAuthTable && !document.querySelector('.cc-mw-auth-info')) {
    runMasterWeekAuthOverlay();
  }

  if (authTable && !document.querySelector('.cc-auth-info')) {
    runAuthOverlay();
    injectAuthExpiryBanners();
  }
  if (isBatchInvoicePage && !document.getElementById('cc-billing-init')) { initBatchInvoiceOverlay(); return; }
  if (hasClientCal || hasCaregiverCal) {
    // Keep retrying until button appears — timing varies by page
    let attempts = 0;
    const tryInject = () => {
      if (document.getElementById('cc-hour-counter-btn')) return;
      injectHourCounterBtn();
      attempts++;
      if (attempts < 20) setTimeout(tryInject, 500);
    };
    setTimeout(tryInject, 300);
  }
  if (hasClientCal) {
    document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    runClientCalendar();
  } else if (hasCaregiverCal) {
    document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header,.cc-dup-banner').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    runCaregiverCalendar();
  }

  // ── For Aide page: watch for calendar to finish loading then auto-run ──
  if (window.location.href.includes('Aide_ns.aspx') && !window._ccAideCalObs) {
    window._ccAideCalObs = true;
    const aideObs = new MutationObserver(() => {
      clearTimeout(window._ccAideCalTimer);
      window._ccAideCalTimer = setTimeout(() => {
        const bt = document.body.innerText;
        const hasCal = !bt.includes('Billed:') && !!bt.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bt.includes('IO');
        if (hasCal && !document.querySelector('.cc-week-hrs-cell')) {
          document.querySelectorAll('.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
          runCaregiverCalendar();
        }
      }, 1500);
    });
    // Watch the calendar table area specifically
    const calArea = document.querySelector('.hhax-main-content, #mainContentRegion, [role="main"]') || document.body;
    aideObs.observe(calArea, { childList: true, subtree: true });
    // Disconnect after 30s to avoid running forever
    setTimeout(() => aideObs.disconnect(), 30000);
  }
  if (isAppointmentsPage) initAppointmentsScanner();
  if (isAppointmentsPage && !document.getElementById('cc-authcmp-init')) initApptAuthCompare();
  if (isMasterWeekPage && !document.getElementById('cc-mw-panel')) initMasterWeekScanner();
  if (isPatientSearchPage && !document.getElementById('cc-patient-search-init')) initPatientSearchEnhancements();
  if (isPatientResultsPage && !document.getElementById('cc-results-init')) initPatientSearchResultsPage();
  if (isCaregiverSearchPage && !document.getElementById('cc-cgsearch-init')) initCaregiverSearchScanner();
  if (isPrebillingPage && !document.getElementById('cc-prebilling-init')) initPrebillingEnhancements();
  if (isVisitMaintenancePage && !document.getElementById('cc-vm-init')) initVisitMaintenanceScanner();
}

// ─── UTILITIES ────────────────────────────────────────────────────
function parseDate(str) {
  if (!str) return null;
  const m = str.trim().match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (!m) return null;
  return new Date(parseInt(m[3]), parseInt(m[1]) - 1, parseInt(m[2]));
}

function daysBetween(from, to) {
  if (!from || !to) return null;
  return Math.round((to - from) / 86400000) + 1;
}

function parseHours(str) {
  if (!str) return null;
  const m = str.replace(/,/g, '').match(/([\d.]+)\s*hrs?/i);
  if (m) return parseFloat(m[1]);
  const n = parseFloat(str.replace(/,/g, ''));
  return isNaN(n) ? null : n;
}

function timeToMinutes(t) {
  if (!t) return null;
  const s = t.toString().trim().replace(/\D/g, '').padStart(4, '0');
  if (s.length < 4) return null;
  const h = parseInt(s.substring(0, 2));
  const mn = parseInt(s.substring(2, 4));
  if (isNaN(h) || isNaN(mn)) return null;
  return h * 60 + mn;
}

function parseVisitHours(rangeStr) {
  if (!rangeStr) return null;
  const m = rangeStr.trim().match(/(\d{3,4})\s*[-\u2013]\s*(\d{3,4})/);
  if (!m) return null;
  const start = timeToMinutes(m[1]);
  const end   = timeToMinutes(m[2]);
  if (start === null || end === null) return null;
  let diff = end - start;
  if (diff < 0) diff += 1440;
  return Math.round((diff / 60) * 100) / 100;
}

function parseRangeToInterval(rangeStr) {
  if (!rangeStr) return null;
  const m = rangeStr.trim().match(/(\d{3,4})\s*[-\u2013]\s*(\d{3,4})/);
  if (!m) return null;
  const s = timeToMinutes(m[1]);
  let e = timeToMinutes(m[2]);
  if (s === null || e === null) return null;
  if (e < s) e += 1440;
  return { start: s, end: e };
}

function fmt(n) {
  if (n === null || n === undefined) return 'N/A';
  return parseFloat(n).toFixed(2);
}

function fmtTime(mins) {
  return String(Math.floor(mins / 60)).padStart(2, '0') + String(mins % 60).padStart(2, '0');
}

function getClientName() {
  try {
    const el = window.parent.document.querySelector('[id*="uxLblPatientName"], h1 .headinfo');
    if (el) return el.innerText.trim().split('\n')[0];
  } catch(e) {}
  return 'Unknown Client';
}

// ─── 1. AUTH OVERLAY ─────────────────────────────────────────────
// Global store for auth data so calendar can compare
window._ccAuthData = null;

function runAuthOverlay() {
  document.querySelectorAll('.cc-auth-info').forEach(el => el.remove());
  document.querySelectorAll('.cc-injected').forEach(el => el.remove());

  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  if (!authTable) return;

  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));
  const authData = [];
  const DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const DAY_COLS  = [10,11,12,13,14,15,16];
  const today = new Date(); today.setHours(0,0,0,0);

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 10) return;

    const authNum = cells[1]  ? cells[1].innerText.trim()  : '';
    const fromStr = cells[2]  ? cells[2].innerText.trim()  : '';
    const toStr   = cells[3]  ? cells[3].innerText.trim()  : '';
    const maxStr  = cells[9]  ? cells[9].innerText.trim()  : '';

    const fromDate = parseDate(fromStr);
    const toDate   = parseDate(toStr);
    const maxHrs   = parseHours(maxStr);
    if (!fromDate || !toDate || !maxHrs) return;

    const totalDays        = daysBetween(fromDate, toDate);
    const dailyHrs         = maxHrs / totalDays;
    const weeklyHrs        = dailyHrs * 7;
    const daysRemaining    = Math.max(0, daysBetween(today, toDate));
    const projectedRemain  = daysRemaining * dailyHrs;

    // Inject daily hours under Mon-Sun columns
    DAY_COLS.forEach(ci => {
      if (cells[ci] && !cells[ci].querySelector('.cc-injected')) {
        const div = document.createElement('div');
        div.className = 'cc-injected';
        div.style.cssText = 'color:#00695c;font-size:11px;font-weight:700;font-family:monospace;margin-top:3px;';
        div.textContent = fmt(dailyHrs) + 'h';
        cells[ci].appendChild(div);
      }
    });

    // Replace Remaining Auth cell
    const remCell = cells[17];
    if (remCell) {
      const remColor = projectedRemain <= 0 ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
      const remFlag  = projectedRemain <= 0 ? '🚨 EXHAUSTED' : projectedRemain < maxHrs * 0.15 ? '⚠ LOW' : '✓';
      remCell.innerHTML = `
        <span style="font-weight:700;color:${remColor};">${fmt(projectedRemain)}h ${remFlag}</span>
        <div style="font-size:10px;color:#888;font-family:monospace;">${daysRemaining} days left</div>
      `;
    }

    const infoRow = document.createElement('tr');
    infoRow.className = 'cc-auth-info';
    const td = document.createElement('td');
    td.colSpan = cells.length;
    td.style.cssText = 'background:#e8f5e9;padding:7px 14px;font-family:monospace;font-size:12px;border-bottom:2px solid #81c784;';
    const rc = projectedRemain <= 0 ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
    td.innerHTML = `
      <b style="color:#1b5e20;">⚕ ${authNum}</b> &nbsp;&nbsp;
      <span style="color:#555">${fromStr} – ${toStr} | <b>${totalDays} total days</b></span> &nbsp;&nbsp;
      Daily: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b> &nbsp;&nbsp;
      Weekly: <b style="color:#2e7d32">${fmt(weeklyHrs)}h</b> &nbsp;&nbsp;
      Remaining: <b style="color:${rc}">${fmt(projectedRemain)}h (${daysRemaining} days left)</b>
      <br>
      <span style="color:#777;font-size:11px;">
        ${DAY_NAMES.map(d => `${d}: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b>`).join(' | ')}
      </span>
    `;
    infoRow.appendChild(td);
    row.parentNode.insertBefore(infoRow, row.nextSibling);
    authData.push({ authNum, fromStr, toStr, toDate, totalDays, maxHrs, dailyHrs, weeklyHrs, projectedRemain, daysRemaining });
  });

  if (authData.length > 0) {
    window._ccAuthData = authData; // store globally for calendar mismatch check
    logToSheets({ type: 'auth', clientName: getClientName(), auths: authData });
    saveAuthToBackground(getClientName(), authData);
  }
}

// ─── 2. CLIENT CALENDAR ───────────────────────────────────────────
function parseClientVisitsFromCell(cell) {
  const visits = [];
  const lines = (cell.innerText || '').split('\n').map(l => l.trim()).filter(l => l);

  for (let i = 0; i < lines.length; i++) {
    const sMatch = lines[i].match(/^S:\s*(\d{3,4}[-\u2013]\d{3,4})/);
    if (!sMatch) continue;

    const scheduledRange = sMatch[1];
    const nextLine = lines[i + 1] || '';
    const vMatch = nextLine.match(/^V:\s*(\d{3,4}[-\u2013]\d{3,4})/);
    const visitRange = vMatch ? vMatch[1] : null;

    let dcw = 'Unknown';
    for (let j = i + 2; j < Math.min(i + 8, lines.length); j++) {
      const l = lines[j];
      if (/^[A-Za-z]/.test(l) && !/^(Billed|S:|V:|IO$|Not Auth|Authorized|Partial)/i.test(l) && l.length > 3) {
        dcw = l; break;
      }
    }

    let billed = null;
    for (let j = i + 1; j < Math.min(i + 8, lines.length); j++) {
      const bm = lines[j].match(/Billed:\s*([YN])/i);
      if (bm) { billed = bm[1]; break; }
    }

    const schedInterval = parseRangeToInterval(scheduledRange);
    const visitInterval  = visitRange ? parseRangeToInterval(visitRange) : null;
    const schedHrs = parseVisitHours(scheduledRange);
    const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

    let svDiffMins = 0;
    if (schedInterval && visitInterval) {
      svDiffMins = Math.abs(schedInterval.start - visitInterval.start) +
                   Math.abs(schedInterval.end   - visitInterval.end);
    }

    visits.push({ scheduled: scheduledRange, visit: visitRange, schedHrs, visitHrs, schedInterval, visitInterval, svDiffMins, dcw, billed });
    i += 2;
  }
  return visits;
}


function injectHourCounterBtn() {
  if (document.getElementById('cc-hour-counter-btn')) return true;
  const goBtn = document.getElementById('uxbtnSearch') ||
                document.getElementById('uxBtnCalendarSearch') ||
                document.getElementById('ctl00_ContentPlaceHolder1_uxBtnGo') ||
                document.querySelector('input[value="Go"]');
  if (!goBtn) return false;

  function cleanupCalendar() {
    document.querySelectorAll('.cc-week-hrs-cell,.cc-week-hrs-header,.cc-diff-banner,.cc-overlap-banner,.cc-dup-banner,.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
    document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
      el.style.removeProperty('outline'); el.style.removeProperty('background-color');
      el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
    });
    document.querySelectorAll('table').forEach(t => { t.style.removeProperty('outline'); t.style.removeProperty('background-color'); });
  }

  // Hook prev/next month buttons
  ['btnPrevMonth','btnNextMonth'].forEach(id => {
    const btn = document.getElementById(id);
    if (btn && !btn._ccMonthHooked) {
      btn._ccMonthHooked = true;
      btn.addEventListener('click', () => {
        setTimeout(() => {
          cleanupCalendar();
          const old = document.getElementById('cc-hour-counter-btn');
          if (old) old.remove();
          setTimeout(injectHourCounterBtn, 800);
        }, 1500);
      });
    }
  });

  // Hook Go button for month change cleanup
  if (!goBtn._ccGoHooked) {
    goBtn._ccGoHooked = true;
    goBtn.addEventListener('click', () => setTimeout(cleanupCalendar, 1500));
  }

  const hcBtn = document.createElement('button');
  hcBtn.id = 'cc-hour-counter-btn';
  hcBtn.type = 'button';
  hcBtn.textContent = '⏱ Hour Counter';
  hcBtn.title = 'Calculate scheduled vs actual hours per caregiver for this month';
  hcBtn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:12px;font-weight:bold;cursor:pointer;margin-left:8px;vertical-align:middle;';

  hcBtn.addEventListener('click', () => {
    cleanupCalendar();
    hcBtn.textContent = '⏳ Calculating...';
    hcBtn.disabled = true;
    setTimeout(() => {
      const bodyText = document.body.innerText;
      const hasClientCal = bodyText.includes('Billed:') && bodyText.includes('S:');
      const hasCaregiverCal = !hasClientCal && !!bodyText.match(/\d{4}\s*[-\u2013]\s*\d{4}/) && bodyText.includes('IO');
      if (hasClientCal) runClientCalendar();
      else if (hasCaregiverCal) runCaregiverCalendar();
      hcBtn.textContent = '⏱ Hour Counter';
      hcBtn.disabled = false;
    }, 300);
  });

  goBtn.parentNode.insertBefore(hcBtn, goBtn.nextSibling);
  return true;
}

function runClientCalendar() {
  injectHourCounterBtn();
  // Clean up previous
  document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
  document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
    el.style.removeProperty('outline');
    el.style.removeProperty('background-color');
    el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
  });

  // Find all calendar day cells
  const allTds = [...document.querySelectorAll('td')];
  const dayCells = [];

  allTds.forEach(td => {
    const text = td.innerText || '';
    if (!text.includes('Billed:') || !text.includes('S:')) return;
    const lines = text.split('\n').map(l => l.trim()).filter(l => l);
    const dayNum = parseInt(lines[0]);
    if (isNaN(dayNum) || dayNum < 1 || dayNum > 31) return;
    const visits = parseClientVisitsFromCell(td);
    if (visits.length > 0) dayCells.push({ dayNum, td, visits });
  });

  if (dayCells.length === 0) return;

  // Run duplicate visit check
  document.querySelectorAll('.cc-dup-banner').forEach(el => el.remove());
  runDuplicateVisitCheck(dayCells);
  dayCells.forEach(({ dayNum, td, visits }) => {
    let hasOverlap = false;
    let hasDiff = false;
    const overlapDetails = [];
    const diffDetails = [];

    visits.forEach(v => {
      if (v.svDiffMins > 15) {
        hasDiff = true;
        diffDetails.push(`${v.dcw}: S=${v.scheduled} V=${v.visit||'N/A'} (${v.svDiffMins}min diff)`);
      }
    });

    const intervals = [];
    visits.forEach(v => {
      if (v.schedInterval) intervals.push({ ...v.schedInterval, dcw: v.dcw, type: 'S' });
      if (v.visitInterval) intervals.push({ ...v.visitInterval, dcw: v.dcw, type: 'V' });
    });

    for (let i = 0; i < intervals.length; i++) {
      for (let j = i + 1; j < intervals.length; j++) {
        const a = intervals[i], b = intervals[j];
        if (a.dcw === b.dcw) continue;
        const oStart = Math.max(a.start, b.start);
        const oEnd   = Math.min(a.end, b.end);
        if (oEnd - oStart >= 8) {
          hasOverlap = true;
          overlapDetails.push(`🚨 ${fmtTime(oStart)}–${fmtTime(oEnd)} (${oEnd-oStart}min)\n${a.dcw} & ${b.dcw} [${a.type}+${b.type}]`);
        }
      }
    }

    if (hasOverlap) {
      td.style.setProperty('outline','3px solid #c62828','important');
      td.style.setProperty('background-color','rgba(198,40,40,0.10)','important');
      td.classList.add('cc-overlap-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-overlap-banner';
      banner.style.cssText = 'background:#c62828;color:white;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = overlapDetails.join('\n\n');
      td.appendChild(banner);
      logToSheets({ type: 'overlap', clientName: getClientName(), dayNum, overlaps: overlapDetails });
      saveOverlapToBackground(getClientName(), dayNum, overlapDetails.join(' | '));
    } else if (hasDiff) {
      td.style.setProperty('outline','3px solid #f9a825','important');
      td.style.setProperty('background-color','rgba(249,168,37,0.12)','important');
      td.classList.add('cc-diff-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-diff-banner';
      banner.style.cssText = 'background:#f9a825;color:#333;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = '⚠ SCHED DIFF >15MIN\n' + diffDetails.join('\n');
      td.appendChild(banner);
    }
  });

  // ── Build weekly hours column ──────────────────────────────────
  // Find the calendar table — it has week rows (tr) with day cells (td)
  // Group dayCells by the table row they belong to
  const calTable = dayCells[0]?.td?.closest('table');
  if (!calTable) return;

  // Add header cell to header row
  const headerRow = calTable.querySelector('tr');
  if (headerRow && !headerRow.querySelector('.cc-week-hrs-header')) {
    const th = document.createElement('th');
    th.className = 'cc-week-hrs-header';
    th.style.cssText = `
      background:#002447; color:white; font-size:11px;
      font-family:monospace; padding:6px 8px;
      text-align:left; white-space:nowrap;
      border-left:2px solid #4caf50; min-width:140px;
    `;
    th.textContent = 'CC Hours';
    headerRow.appendChild(th);
  }

  // Group day cells by their parent tr (week row)
  const rowMap = new Map();
  dayCells.forEach(({ td, visits }) => {
    const tr = td.parentElement;
    if (!tr) return;
    if (!rowMap.has(tr)) rowMap.set(tr, []);
    rowMap.get(tr).push(...visits);
  });

  // For each week row, calculate per-DCW sched/visit/diff and inject a td
  rowMap.forEach((visits, tr) => {
    if (tr.querySelector('.cc-week-hrs-cell')) return;

    // Aggregate by DCW
    const byDCW = {};
    visits.forEach(v => {
      const dcw = v.dcw || 'Unknown';
      if (!byDCW[dcw]) byDCW[dcw] = { sched: 0, visit: 0 };
      byDCW[dcw].sched += v.schedHrs || 0;
      byDCW[dcw].visit += v.visitHrs || 0;
    });

    const td = document.createElement('td');
    td.className = 'cc-week-hrs-cell';
    td.style.cssText = `
      vertical-align: top;
      border-left: 2px solid #4caf50;
      padding: 6px 8px;
      background: #f1f8f1;
      font-family: monospace;
      font-size: 11px;
      min-width: 140px;
    `;

    let html = '';
    Object.entries(byDCW).forEach(([dcw, hrs]) => {
      const diff = hrs.visit - hrs.sched;
      const diffColor = diff < -0.25 ? '#c62828' : diff > 0.25 ? '#1565c0' : '#2e7d32';
      const diffSign  = diff >= 0 ? '+' : '';
      html += `
        <div style="margin-bottom:8px;border-bottom:1px solid #c8e6c9;padding-bottom:6px;">
          <div style="font-weight:700;color:#1b5e20;font-size:11px;margin-bottom:3px;">${dcw}</div>
          <div style="color:#555;">Sched: <b>${fmt(hrs.sched)}h</b></div>
          <div style="color:#555;">Visit: <b>${fmt(hrs.visit)}h</b></div>
          <div style="color:${diffColor};">Diff: <b>${diffSign}${fmt(diff)}h</b></div>
        </div>
      `;
    });

    // Week total
    const totalSched = Object.values(byDCW).reduce((s, v) => s + v.sched, 0);
    const totalVisit = Object.values(byDCW).reduce((s, v) => s + v.visit, 0);
    const totalDiff  = totalVisit - totalSched;
    const totalDiffColor = totalDiff < -0.25 ? '#c62828' : totalDiff > 0.25 ? '#1565c0' : '#2e7d32';
    const totalDiffSign  = totalDiff >= 0 ? '+' : '';

    html += `
      <div style="background:#1b5e20;color:white;border-radius:4px;padding:4px 6px;margin-top:4px;">
        <div style="font-size:10px;color:#a5d6a7;">WEEK TOTAL</div>
        <div>S: <b>${fmt(totalSched)}h</b></div>
        <div>V: <b>${fmt(totalVisit)}h</b></div>
        <div style="color:${totalDiff < -0.25 ? '#ff8a80' : totalDiff > 0.25 ? '#82b1ff' : '#b9f6ca'};">
          Diff: <b>${totalDiffSign}${fmt(totalDiff)}h</b>
        </div>
      </div>
    `;

    td.innerHTML = html;
    tr.appendChild(td);
  });

  // Log hours
  const clientName = getClientName();
  const allByDCW = {};
  dayCells.forEach(({ visits }) => {
    visits.forEach(v => {
      const dcw = v.dcw || 'Unknown';
      if (!allByDCW[dcw]) allByDCW[dcw] = { sched: 0, visit: 0 };
      allByDCW[dcw].sched += v.schedHrs || 0;
      allByDCW[dcw].visit += v.visitHrs || 0;
    });
  });
  const rows = Object.entries(allByDCW).map(([dcw, hrs]) => ({
    clientName, dcw, schedHours: hrs.sched, visitHours: hrs.visit, diff: hrs.visit - hrs.sched
  }));
  if (rows.length > 0) logToSheets({ type: 'hours', data: rows });

  // ── Auth vs Scheduled mismatch — color entire calendar table ──
  checkCalendarAuthMismatch(calTable, dayCells);
}

function checkCalendarAuthMismatch(calTable, dayCells) {
  if (!calTable || !dayCells || dayCells.length === 0) return;

  document.querySelectorAll('.cc-auth-mismatch-banner,.cc-auth-row-flag').forEach(el => el.remove());
  calTable.style.removeProperty('outline');
  calTable.style.removeProperty('background-color');

  // Read A: and S: directly from HHAeXchange DOM summary row
  let authHrsFromDOM = null, schedHrsFromDOM = null;
  const calRows = [...calTable.querySelectorAll('tr')].slice(-3);
  calRows.forEach(row => {
    const txt = row.innerText || '';
    if (txt.includes('A:') && txt.includes('S:')) {
      const am = txt.match(/A:\s*([\d:]+)/);
      const sm = txt.match(/S:\s*([\d:]+)/);
      if (am && !authHrsFromDOM)  authHrsFromDOM  = parseHHMM(am[1]);
      if (sm && !schedHrsFromDOM) schedHrsFromDOM = parseHHMM(sm[1]);

      // Highlight the summary row if over/under
      if (authHrsFromDOM && schedHrsFromDOM) {
        const isOver  = schedHrsFromDOM > authHrsFromDOM + 0.1;
        const isUnder = schedHrsFromDOM < authHrsFromDOM - 0.1;
        if (isOver || isUnder) {
          row.style.setProperty('background-color', 'rgba(255,140,0,0.25)', 'important');
          row.style.setProperty('outline', '2px solid #ff8c00', 'important');
          const flag = document.createElement('span');
          flag.className = 'cc-auth-row-flag';
          flag.style.cssText = 'display:inline-block;background:#ff8c00;color:#000;font-size:9px;font-weight:900;padding:2px 7px;border-radius:3px;margin-left:8px;letter-spacing:1px;font-family:monospace;';
          flag.textContent = isOver ? 'OVER USED AUTH' : 'UNDER USED AUTH';
          row.appendChild(flag);
        }
      }
    }
  });

  // Fallback to computed values
  let totalSchedHrs = schedHrsFromDOM;
  let monthlyAuthHrs = authHrsFromDOM;

  if (!totalSchedHrs) {
    totalSchedHrs = 0;
    dayCells.forEach(({ visits }) => { visits.forEach(v => { totalSchedHrs += v.schedHrs || 0; }); });
  }

  if (!monthlyAuthHrs) {
    const authArr = window._ccAuthData;
    if (!authArr || authArr.length === 0) return;
    const today = new Date(); today.setHours(0,0,0,0);
    let auth = authArr.find(a => a.toDate >= today) || authArr[0];
    const now = new Date();
    const daysInMonth = new Date(now.getFullYear(), now.getMonth()+1, 0).getDate();
    monthlyAuthHrs = auth.dailyHrs * daysInMonth;
  }

  if (!monthlyAuthHrs || monthlyAuthHrs === 0) return;

  const diff = Math.abs(totalSchedHrs - monthlyAuthHrs);
  if (diff < 0.1) return;

  const isOver = totalSchedHrs > monthlyAuthHrs;
  const authLabel = isOver ? 'OVER USED AUTH' : 'UNDER USED AUTH';

  // Light orange for both over and under
  calTable.style.setProperty('outline', '3px solid #ff8c00', 'important');
  calTable.style.setProperty('background-color', 'rgba(255,140,0,0.06)', 'important');

  // Banner above table
  const banner = document.createElement('div');
  banner.className = 'cc-auth-mismatch-banner';
  banner.style.cssText = 'background:#ff8c00;color:#000;font-family:monospace;font-size:12px;font-weight:900;padding:8px 14px;border-radius:4px 4px 0 0;letter-spacing:1px;';
  banner.textContent = `⚠ ${authLabel}: Scheduled ${fmt(totalSchedHrs)}h vs Auth ${fmt(monthlyAuthHrs)}h (${isOver?'+':'-'}${fmt(diff)}h)`;
  calTable.parentNode.insertBefore(banner, calTable);

  // Add to floater
  window._ccAuthFlag = { label: authLabel, isOver, totalSchedHrs, monthlyAuthHrs, diff };
}

// ─── 3. CAREGIVER CALENDAR ────────────────────────────────────────
function parseCaregiverVisitsFromCell(cell) {
  const visits = [];
  const lines = (cell.innerText || '').split('\n').map(l => l.trim()).filter(l => l);

  let i = 0;
  while (i < lines.length) {
    // Not anchored with $ at the end \u2014 the visit-confirmed time and the
    // "IO" indicator live in separate <td>s of the SAME <tr>, so innerText
    // often merges them onto one line ("0000 - 1439 IO"). Matching the time
    // range as a prefix (not the whole line) still finds it correctly.
    const schedMatch = lines[i].match(/^(\d{4})\s*[-\u2013]\s*(\d{4})\b/);
    if (!schedMatch) { i++; continue; }

    const scheduledRange = schedMatch[1] + '-' + schedMatch[2];
    const nextLine = lines[i+1] || '';
    const visitMatch = nextLine.match(/^(\d{4})\s*[-\u2013]\s*(\d{4})\b/);
    const visitRange = visitMatch ? (visitMatch[1] + '-' + visitMatch[2]) : null;

    let clientName = 'Unknown';
    const searchFrom = visitMatch ? i + 2 : i + 1;
    for (let j = searchFrom; j < Math.min(searchFrom + 5, lines.length); j++) {
      const l = lines[j];
      if (/^[A-Za-z]/.test(l) && !/^(IO|DF|B$)/i.test(l) && l.length > 2) {
        clientName = l; break;
      }
    }

    const schedInterval = parseRangeToInterval(scheduledRange);
    const visitInterval  = visitRange ? parseRangeToInterval(visitRange) : null;
    const schedHrs = parseVisitHours(scheduledRange);
    const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

    let svDiffMins = 0;
    if (schedInterval && visitInterval) {
      svDiffMins = Math.abs(schedInterval.start - visitInterval.start) +
                   Math.abs(schedInterval.end - visitInterval.end);
    }

    visits.push({ scheduled: scheduledRange, visit: visitRange, schedHrs, visitHrs, schedInterval, visitInterval, svDiffMins, clientName });
    i = visitMatch ? i + 2 : i + 1;
  }
  return visits;
}

function runCaregiverCalendar() {
  injectHourCounterBtn();
  document.querySelectorAll('.cc-overlap-banner,.cc-diff-banner,.cc-week-hrs-cell,.cc-week-hrs-header').forEach(el => el.remove());
  document.querySelectorAll('.cc-overlap-highlight,.cc-diff-highlight').forEach(el => {
    el.style.removeProperty('outline');
    el.style.removeProperty('background-color');
    el.classList.remove('cc-overlap-highlight','cc-diff-highlight');
  });

  const allTds = [...document.querySelectorAll('td')];
  const dayCells = [];

  allTds.forEach(td => {
    const text = td.innerText || '';
    if (!text.match(/\d{4}\s*[-\u2013]\s*\d{4}/)) return;
    const lines = text.split('\n').map(l => l.trim()).filter(l => l);
    // Day number can be in first few lines (not necessarily line 0)
    let dayNum = NaN;
    for (let k = 0; k < Math.min(4, lines.length); k++) {
      const n = parseInt(lines[k]);
      if (!isNaN(n) && n >= 1 && n <= 31 && lines[k].match(/^\d{1,2}$/)) { dayNum = n; break; }
    }
    if (isNaN(dayNum)) return;
    const visits = parseCaregiverVisitsFromCell(td);
    if (visits.length > 0) dayCells.push({ dayNum, td, visits });
  });

  if (dayCells.length === 0) return;

  // Only show diff highlights on caregiver calendar — no overlap detection
  dayCells.forEach(({ dayNum, td, visits }) => {
    let hasDiff = false;
    const diffDetails = [];

    visits.forEach(v => {
      if (v.svDiffMins > 15) {
        hasDiff = true;
        diffDetails.push(`${v.clientName}: S=${v.scheduled} V=${v.visit||'N/A'} (${v.svDiffMins}min)`);
      }
    });

    if (hasDiff) {
      td.style.setProperty('outline','3px solid #f9a825','important');
      td.style.setProperty('background-color','rgba(249,168,37,0.12)','important');
      td.classList.add('cc-diff-highlight');
      const banner = document.createElement('div');
      banner.className = 'cc-diff-banner';
      banner.style.cssText = 'background:#f9a825;color:#333;font-family:monospace;font-size:10px;font-weight:700;padding:4px 7px;border-radius:3px;margin-top:5px;line-height:1.6;white-space:pre-wrap;';
      banner.textContent = '⚠ SCHED DIFF >15MIN\n' + diffDetails.join('\n');
      td.appendChild(banner);
    }
  });

  // ── Weekly hours column for caregiver calendar ─────────────────
  const calTable = dayCells[0]?.td?.closest('table');
  if (!calTable) return;

  const headerRow = calTable.querySelector('tr');
  if (headerRow && !headerRow.querySelector('.cc-week-hrs-header')) {
    const th = document.createElement('th');
    th.className = 'cc-week-hrs-header';
    th.style.cssText = 'background:#002447;color:white;font-size:11px;font-family:monospace;padding:6px 8px;text-align:left;white-space:nowrap;border-left:2px solid #4caf50;min-width:160px;';
    th.textContent = 'CC Hours';
    headerRow.appendChild(th);
  }

  const rowMap = new Map();
  dayCells.forEach(({ td, visits }) => {
    const tr = td.parentElement;
    if (!tr) return;
    if (!rowMap.has(tr)) rowMap.set(tr, []);
    rowMap.get(tr).push(...visits);
  });

  rowMap.forEach((visits, tr) => {
    if (tr.querySelector('.cc-week-hrs-cell')) return;

    // Aggregate by client
    const byClient = {};
    visits.forEach(v => {
      const c = v.clientName || 'Unknown';
      if (!byClient[c]) byClient[c] = { sched: 0, visit: 0 };
      byClient[c].sched += v.schedHrs || 0;
      byClient[c].visit += v.visitHrs || 0;
    });

    const td = document.createElement('td');
    td.className = 'cc-week-hrs-cell';
    td.style.cssText = 'vertical-align:top;border-left:2px solid #4caf50;padding:6px 8px;background:#f1f8f1;font-family:monospace;font-size:11px;min-width:160px;';

    let html = '';
    Object.entries(byClient).forEach(([client, hrs]) => {
      const diff = hrs.visit - hrs.sched;
      const diffColor = diff < -0.25 ? '#c62828' : diff > 0.25 ? '#1565c0' : '#2e7d32';
      const diffSign  = diff >= 0 ? '+' : '';
      html += `
        <div style="margin-bottom:8px;border-bottom:1px solid #c8e6c9;padding-bottom:6px;">
          <div style="font-weight:700;color:#1b5e20;font-size:10px;margin-bottom:3px;">${client}</div>
          <div style="color:#555;">Sched: <b>${fmt(hrs.sched)}h</b></div>
          <div style="color:#555;">Visit: <b>${fmt(hrs.visit)}h</b></div>
          <div style="color:${diffColor};">Diff: <b>${diffSign}${fmt(diff)}h</b></div>
        </div>
      `;
    });

    const totalSched = Object.values(byClient).reduce((s, v) => s + v.sched, 0);
    const totalVisit = Object.values(byClient).reduce((s, v) => s + v.visit, 0);
    const totalDiff  = totalVisit - totalSched;
    const totalDiffSign = totalDiff >= 0 ? '+' : '';

    html += `
      <div style="background:#1b5e20;color:white;border-radius:4px;padding:4px 6px;margin-top:4px;">
        <div style="font-size:10px;color:#a5d6a7;">WEEK TOTAL</div>
        <div>S: <b>${fmt(totalSched)}h</b></div>
        <div>V: <b>${fmt(totalVisit)}h</b></div>
        <div style="color:${totalDiff < -0.25 ? '#ff8a80' : totalDiff > 0.25 ? '#82b1ff' : '#b9f6ca'};">
          Diff: <b>${totalDiffSign}${fmt(totalDiff)}h</b>
        </div>
      </div>
    `;

    td.innerHTML = html;
    tr.appendChild(td);
  });
}

// ─── GOOGLE SHEETS LOGGER ─────────────────────────────────────────
function logToSheets(data) {
  var SHEETS_URL = 'https://script.google.com/macros/s/AKfycbyM8t-5uJyMq8k2qvRNsW0_enmvi1ICv1gWuxwIST8oQogB8XhtoRljIx-gqD45Usl-rA/exec';
  fetch(SHEETS_URL, {
    method: 'POST', mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...data, timestamp: new Date().toISOString() })
  }).catch(() => {});
}

// ─── SAVE AUTH TO BACKGROUND (for expiry alerts) ──────────────────
function saveAuthToBackground(clientName, auths) {
  const payload = auths.map(a => ({
    clientName,
    authNum:    a.authNum,
    toDate:     a.toDate ? a.toDate.toISOString() : null,
    toDateStr:  a.toStr,
    fromDateStr: a.fromStr,
    dailyHrs:   a.dailyHrs,
    weeklyHrs:  a.weeklyHrs,
    maxHrs:     a.maxHrs,
    daysRemaining: a.daysRemaining
  }));
  try {
    chrome.runtime.sendMessage({ action: 'saveAuth', auths: payload });
  } catch(e) {}
}

// ─── SAVE OVERLAP TO BACKGROUND ───────────────────────────────────
function saveOverlapToBackground(clientName, dayNum, detail) {
  try {
    chrome.runtime.sendMessage({ action: 'saveOverlap', overlap: { clientName, dayNum, detail } });
  } catch(e) {}
}

// ─── VISIT FREQUENCY vs AUTH ALERT ───────────────────────────────
function runVisitFrequencyCheck(dayCells, authData) {
  if (!authData || authData.length === 0 || dayCells.length === 0) return;

  const activeAuth = authData.find(a => a.daysRemaining > 0) || authData[0];
  if (!activeAuth) return;

  // Count actual visit days
  const visitDays = dayCells.filter(d => d.visits.some(v => v.visitHrs > 0)).length;
  const totalDays  = dayCells.length;
  const visitRate  = visitDays / totalDays; // e.g. 0.71 = 5/7 days

  // Auth allows dailyHrs every day — if visitRate is significantly lower, flag it
  const expectedVisitDays = Math.round(totalDays * (activeAuth.weeklyHrs / (activeAuth.dailyHrs * 7)));
  const missedDays = Math.max(0, expectedVisitDays - visitDays);

  if (missedDays >= 2) {
    // Inject alert banner below auth table
    const existing = document.getElementById('cc-freq-alert');
    if (existing) existing.remove();

    const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
    if (!authTable) return;

    const alert = document.createElement('div');
    alert.id = 'cc-freq-alert';
    alert.style.cssText = `
      background:#fff3e0; border:2px solid #f57c00; border-radius:6px;
      padding:10px 14px; margin:8px 0; font-family:monospace; font-size:12px;
      color:#e65100;
    `;
    alert.innerHTML = `
      <b>⚠ Visit Frequency Alert</b><br>
      <span style="color:#555;">
        Auth allows <b style="color:#2e7d32">${activeAuth.dailyHrs ? activeAuth.dailyHrs.toFixed(2) : 'N/A'}h/day</b> —
        Client visited <b>${visitDays}</b> of <b>${totalDays}</b> calendar days shown.<br>
        Estimated <b style="color:#c62828">${missedDays} missed visit day(s)</b> based on authorization schedule.
      </span>
    `;
    authTable.parentNode.insertBefore(alert, authTable.nextSibling);
  }
}


// ─── AUTH EXPIRY BANNER ON CLIENT PAGE ───────────────────────────
function injectAuthExpiryBanners() {
  document.querySelectorAll('.cc-expiry-banner').forEach(el => el.remove());

  const authTable = document.getElementById('PatientAuthorization_uxGvAuthorization');
  if (!authTable) return;

  const today = new Date(); today.setHours(0,0,0,0);
  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 4) return;
    const toStr  = cells[3] ? cells[3].innerText.trim() : '';
    const authNum = cells[1] ? cells[1].innerText.trim() : '';
    const toDate = parseDate(toStr);
    if (!toDate) return;

    const daysLeft = Math.ceil((toDate - today) / 86400000);
    if (daysLeft > 30) return;

    const color   = daysLeft <= 7  ? '#c62828' : daysLeft <= 15 ? '#e65100' : '#1565c0';
    const bgColor = daysLeft <= 7  ? '#ffebee' : daysLeft <= 15 ? '#fff3e0' : '#e3f2fd';
    const icon    = daysLeft <= 7  ? '🚨' : daysLeft <= 15 ? '⚠' : 'ℹ';
    const label   = daysLeft <= 0  ? 'EXPIRED' : `${daysLeft} days left`;

    const banner = document.createElement('div');
    banner.className = 'cc-expiry-banner';
    banner.style.cssText = `
      background:${bgColor}; border-left:4px solid ${color};
      padding:5px 10px; font-family:monospace; font-size:11px;
      color:${color}; font-weight:700; margin-top:3px; border-radius:0 4px 4px 0;
    `;
    banner.textContent = `${icon} Auth ${authNum} — ${label} (expires ${toStr})`;

    const nextRow = row.nextSibling;
    if (nextRow && nextRow.classList && nextRow.classList.contains('cc-auth-info')) {
      nextRow.parentNode.insertBefore(banner, nextRow.nextSibling);
    } else {
      row.parentNode.insertBefore(banner, row.nextSibling);
    }
  });
}

// ─── DUPLICATE VISIT DETECTOR ─────────────────────────────────────
function runDuplicateVisitCheck(dayCells) {
  const duplicates = [];

  dayCells.forEach(({ dayNum, td, visits }) => {
    // Check if same DCW appears more than once on same day
    const dcwCounts = {};
    visits.forEach(v => {
      dcwCounts[v.dcw] = (dcwCounts[v.dcw] || 0) + 1;
    });

    Object.entries(dcwCounts).forEach(([dcw, count]) => {
      if (count > 1) {
        duplicates.push({ dayNum, dcw, count });
        // Highlight with orange outline
        td.style.setProperty('outline', '3px solid #ff6f00', 'important');
        const banner = document.createElement('div');
        banner.className = 'cc-dup-banner';
        banner.style.cssText = 'background:#ff6f00;color:white;font-family:monospace;font-size:10px;font-weight:700;padding:3px 7px;border-radius:3px;margin-top:4px;';
        banner.textContent = `⚠ DUPLICATE: ${dcw} scheduled ${count}x on day ${dayNum}`;
        td.appendChild(banner);
      }
    });
  });

  return duplicates;
}


// ─── POPUP SCAN HELPERS ───────────────────────────────────────────
function runEVVScan() {
  const rows = document.querySelectorAll('table tr');
  let missing = 0, gps = 0, total = 0;
  rows.forEach(r => { const t = r.innerText; if (!t.trim()) return; total++; if (/missing.*check|no.*check/i.test(t)) missing++; if (/gps.*fail|evv.*fail/i.test(t)) gps++; });
  if (total === 0) return [{ type:'info', icon:'ℹ', text:'Navigate to a visit list page', sub:'' }];
  const res = [{ type:'info', icon:'ℹ', text:`Scanned ${total} rows`, sub:'' }];
  if (missing > 0) res.push({ type:'danger', icon:'🚨', text:`${missing} missing check-in/out`, sub:'EVV compliance risk' });
  if (gps > 0) res.push({ type:'warn', icon:'⚠', text:`${gps} GPS flag(s)`, sub:'' });
  if (missing === 0 && gps === 0) res.push({ type:'success', icon:'✓', text:'No EVV issues detected', sub:'' });
  return res;
}

function runClaimScan() {
  const t = document.body.innerText;
  const denied = (t.match(/denied|rejected/gi)||[]).length;
  const pending = (t.match(/pending|submitted/gi)||[]).length;
  const paid = (t.match(/approved|paid/gi)||[]).length;
  const res = [];
  if (paid > 0)    res.push({ type:'success', icon:'✓',  text:`~${paid} approved/paid`, sub:'' });
  if (pending > 0) res.push({ type:'warn',    icon:'⏳', text:`~${pending} pending`, sub:'Follow up if >30 days' });
  if (denied > 0)  res.push({ type:'danger',  icon:'🚨', text:`~${denied} denied`, sub:'Action required' });
  if (res.length === 0) res.push({ type:'info', icon:'ℹ', text:'Navigate to billing page', sub:'' });
  return res;
}

function runMissedScan() {
  const t = document.body.innerText;
  const missed = (t.match(/missed|no.?show/gi)||[]).length;
  if (missed > 0) return [{ type:'danger', icon:'🚨', text:`${missed} missed/no-show mention(s)`, sub:'Review immediately' }];
  return [{ type:'success', icon:'✓', text:'No missed visits detected', sub:'' }];
}

// ─── APPOINTMENTS PAGE SCANNER ────────────────────────────────────

// ─── DISMISS STORAGE HELPERS ──────────────────────────────────────
function getDismissedKeys() {
  try {
    return JSON.parse(localStorage.getItem('_cc_dismissed') || '{}');
  } catch(e) { return {}; }
}
function isDismissed(key) {
  return !!getDismissedKeys()[key];
}
function dismissCard(key) {
  const dismissed = getDismissedKeys();
  dismissed[key] = true;
  localStorage.setItem('_cc_dismissed', JSON.stringify(dismissed));
}
function clearDismissed() {
  localStorage.removeItem('_cc_dismissed');
}
function makeDismissKey(type, ...parts) {
  return type + '_' + parts.map(p => String(p||'').replace(/\W+/g,'')).join('_');
}

let apptScannerActive = false;
let apptObserver = null;

function initAppointmentsScanner() {
  if (apptScannerActive) return;
  apptScannerActive = true;

  // Watch both grid containers for content to load
  const targets = ['divPatientCalendarGrid-container', 'divCaregiverCalendarGrid-container'];

  targets.forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;

    const obs = new MutationObserver(() => {
      // Debounce: wait for grid to finish rendering
      clearTimeout(el._ccScanTimer);
      el._ccScanTimer = setTimeout(() => {
        if (el.children.length > 0) {
          // Only scan if panel doesn't exist yet — don't wipe it if minimized
          if (!document.getElementById('cc-appt-panel')) {
            runAppointmentsOverlapScan();
          }
          injectApptRememberBtn();
        }
      }, 1500);
    });

    obs.observe(el, { childList: true, subtree: true });
  });

  // Also hook the Search button click
  const searchBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnSearch');
  if (searchBtn) {
    searchBtn.addEventListener('click', () => {
      // Remove old panel and clear old highlights when new search starts
      const old = document.getElementById('cc-appt-panel');
      if (old) old.remove();
      // Clear any old red highlights
      document.querySelectorAll('.cg-visit-item').forEach(b => {
        b.style.removeProperty('outline');
        b.style.removeProperty('background');
      });
    });
  }
}

// ── Member totals row: A: authorized, S: scheduled, C: confirmed, B: billing ──
// Gray flag = billing is under BOTH what was worked and what's authorized, i.e.
// there are billable hours being left on the table that a schedule change can
// recover. Uses B < A (not C <= A) because confirmed can legitimately run a few
// minutes over auth while there's still headroom under the auth cap to bill.
const CC_GRAY_MIN_GAP = 15; // minutes — ignore trivial gaps

function ccParseHM(str) {
  const m = String(str || '').match(/(\d+):(\d{2})/);
  return m ? parseInt(m[1], 10) * 60 + parseInt(m[2], 10) : null;
}
function ccFmtHM(mins) {
  const s = mins < 0 ? '-' : '';
  mins = Math.abs(mins);
  return s + Math.floor(mins / 60) + 'h' + String(mins % 60).padStart(2, '0') + 'm';
}

// Flags clients SCHEDULED OVER their weekly authorization (S > A) — e.g.
// A:71:45 S:74:45 means 3h05m more is scheduled than authorized for the
// week. Flag-only per your instruction: highlight it clearly, don't auto-trim
// any visits, since deciding which visit(s) to cut is a judgment call.
const CC_OVER_AUTH_MIN_GAP = 15; // minutes — ignore trivial overages
function ccFlagOverAuthMembers(container) {
  const out = [];
  if (!container) return out;
  const all = Array.from(container.querySelectorAll('*')).filter(el => {
    const t = el.innerText || '';
    return /A:\s*\d+:\d{2}/.test(t) && /S:\s*\d+:\d{2}/.test(t);
  });
  const cells = all.filter(el => !all.some(o => o !== el && el.contains(o)));

  cells.forEach(cell => {
    const t = cell.innerText || '';
    const A = ccParseHM((t.match(/A:\s*(\d+:\d{2})/) || [])[1]);
    const S = ccParseHM((t.match(/S:\s*(\d+:\d{2})/) || [])[1]);
    if (A === null || S === null) return;
    const over = S - A;
    if (over < CC_OVER_AUTH_MIN_GAP) return;

    let member = '';
    const row = cell.closest('tr') || cell.parentElement;
    if (row) {
      const link = row.querySelector('a');
      if (link) member = (link.textContent || '').trim();
    }
    if (!member) member = (t.split('\n')[0] || '').trim();

    try {
      cell.style.setProperty('outline', '2px solid #a1662f', 'important');
      cell.style.setProperty('background-color', 'rgba(161,102,47,0.28)', 'important');
      cell.title = 'OVER SCHEDULED — ' + ccFmtHM(S) + ' scheduled exceeds weekly auth ' + ccFmtHM(A) +
                   ' by ' + ccFmtHM(over) + '. Review which visit(s) to trim.';
    } catch (e) {}
    out.push({ member, A, S, over, el: cell });
  });
  return out;
}

// Every client's weekly A: (auth) vs S: (scheduled) — used to list who's over
// and who's under using their weekly authorized hours in the scan popup.
function ccScanAuthUsageList(container) {
  const out = [];
  if (!container) return out;
  const all = Array.from(container.querySelectorAll('*')).filter(el => {
    const t = el.innerText || '';
    return /A:\s*\d+:\d{2}/.test(t) && /S:\s*\d+:\d{2}/.test(t);
  });
  const cells = all.filter(el => !all.some(o => o !== el && el.contains(o)));
  cells.forEach(cell => {
    const t = cell.innerText || '';
    const A = ccParseHM((t.match(/A:\s*(\d+:\d{2})/) || [])[1]);
    const S = ccParseHM((t.match(/S:\s*(\d+:\d{2})/) || [])[1]);
    if (A === null || S === null) return;
    let member = '';
    const row = cell.closest('tr') || cell.parentElement;
    if (row) { const link = row.querySelector('a'); if (link) member = (link.textContent || '').trim(); }
    if (!member) member = (t.split('\n')[0] || '').trim();
    out.push({ member, A, S, diff: S - A });
  });
  return out;
}

function scanMemberTotals(container) {
  const out = [];
  if (!container) return out;
  // Find the tightest elements that carry all four totals (a parent row/table
  // also matches, so keep only those containing no other match).
  const all = Array.from(container.querySelectorAll('*')).filter(el => {
    const t = el.innerText || '';
    return /A:\s*\d+:\d{2}/.test(t) && /B:\s*\d+:\d{2}/.test(t) && /C:\s*\d+:\d{2}/.test(t);
  });
  const cells = all.filter(el => !all.some(o => o !== el && el.contains(o)));

  cells.forEach(cell => {
    const t = cell.innerText || '';
    const A = ccParseHM((t.match(/A:\s*(\d+:\d{2})/) || [])[1]);
    const S = ccParseHM((t.match(/S:\s*(\d+:\d{2})/) || [])[1]);
    const C = ccParseHM((t.match(/C:\s*(\d+:\d{2})/) || [])[1]);
    const B = ccParseHM((t.match(/B:\s*(\d+:\d{2})/) || [])[1]);
    if (A === null || C === null || B === null) return;
    if (!(B < C && B < A)) return;                 // billing must trail both
    const recoverable = Math.min(C, A) - B;        // capped at the auth ceiling
    if (recoverable < CC_GRAY_MIN_GAP) return;

    // Member name: nearest row's first link, falling back to the row text
    let member = '';
    const row = cell.closest('tr') || cell.parentElement;
    if (row) {
      const link = row.querySelector('a');
      if (link) member = (link.textContent || '').trim();
    }
    if (!member) member = (t.split('\n')[0] || '').trim();

    try {
      cell.style.setProperty('outline', '2px solid #9e9e9e', 'important');
      cell.style.setProperty('background-color', 'rgba(158,158,158,0.22)', 'important');
      cell.title = 'Schedule needs adjusting — billing ' + ccFmtHM(recoverable) +
                   ' under what was worked/authorized (A:' + ccFmtHM(A) + ' C:' + ccFmtHM(C) + ' B:' + ccFmtHM(B) + ')';
    } catch (e) {}
    out.push({ member, A, S, C, B, recoverable, el: cell });
  });
  return out;
}

// ── Color legend pinned above the calendar so the highlights are self-explanatory ──
const CC_LEGEND = [
  { c: '#ff4444', bg: 'rgba(255,68,68,0.15)',   t: 'Overlap — caregiver double-booked, or client double-staffed' },
  { c: '#ffd600', bg: 'rgba(255,214,0,0.18)',   t: 'Time difference — clock in/out off from schedule by >15 min' },
  { c: '#66bb6a', bg: 'rgba(102,187,106,0.18)', t: 'Time shifted — hours match (±15 min), window moved' },
  { c: '#9e9e9e', bg: 'rgba(158,158,158,0.22)', t: 'Schedule needs adjusting — billing under worked/authorized hours' },
  { c: '#a1662f', bg: 'rgba(161,102,47,0.28)',  t: 'Over scheduled — client\'s scheduled hours exceed weekly auth' }
];

function ccInjectLegend(grid) {
  if (document.getElementById('cc-legend')) return;
  // insertBefore(box, grid) only works if grid is actually a child of host —
  // fall back to prepending on <body> rather than throwing and killing the scan.
  const host = (grid && grid.parentElement) ? grid.parentElement : null;
  const box = document.createElement('div');
  box.id = 'cc-legend';
  box.style.cssText = 'display:flex;flex-wrap:wrap;gap:14px;align-items:center;' +
    'background:#fff;border:1px solid #d0d7e2;border-radius:6px;padding:8px 12px;' +
    'margin:8px 0;font-size:11px;font-family:Arial,sans-serif;color:#333;';
  const label = document.createElement('span');
  label.textContent = '⚕ Care Crafter legend:';
  label.style.cssText = 'font-weight:bold;color:#1a3a6b;';
  box.appendChild(label);
  CC_LEGEND.forEach(item => {
    const s = document.createElement('span');
    s.style.cssText = 'display:flex;align-items:center;gap:5px;';
    const sw = document.createElement('span');
    sw.style.cssText = 'width:14px;height:14px;border-radius:3px;flex-shrink:0;' +
      'border:2px solid ' + item.c + ';background:' + item.bg + ';';
    const tx = document.createElement('span');
    tx.textContent = item.t;
    s.appendChild(sw); s.appendChild(tx);
    box.appendChild(s);
  });
  try {
    if (host) host.insertBefore(box, grid);
    else document.body.insertBefore(box, document.body.firstChild);
  } catch (e) {
    try { document.body.insertBefore(box, document.body.firstChild); } catch (e2) {}
  }
}

// ── Auto-detect fixes ──────────────────────────────────────────────────────
// Watch the calendar for edits. When a visit is corrected in HHAeXchange the
// grid re-renders; we re-scan, diff the problem set against the previous one,
// and report what dropped off. The ccScanning guard stops our own highlight
// writes from retriggering the observer in a loop.
let ccLastResults  = null;
let ccAutoWatchOn  = false;
let ccScanning     = false;
let ccFixedTotal   = 0;
let ccLastSig      = '';
let ccAutoTimer    = null;

function ccProblemKeys(res) {
  const keys = new Set();
  if (!res) return keys;
  (res.overlaps  || []).forEach(o => keys.add(makeDismissKey('ov', o.caregiver, o.date, o.client1, o.client2)));
  (res.hourDiffs || []).forEach(d => keys.add(makeDismissKey('df', d.caregiver, d.date, d.client || d.patient)));
  return keys;
}

// Report fixes inside the floating panel (a banner under the stats row, plus a
// pulse on the running "✓ N fixed" badge). Falls back to a screen toast only if
// the panel is closed, so the count is never silently lost.
function ccShowFixedToast(n, total) {
  const summary = document.getElementById('cc-appt-panel-summary');

  if (summary) {
    let b = document.getElementById('cc-fixed-banner');
    if (!b) {
      b = document.createElement('div');
      b.id = 'cc-fixed-banner';
      b.style.cssText = 'padding:7px 14px;background:#1b5e20;color:#c8e6c9;font-size:12px;' +
        'font-weight:bold;border-bottom:1px solid #2e7d32;transition:opacity 0.4s;';
      summary.insertAdjacentElement('afterend', b);
    }
    b.textContent = '✓ ' + n + ' fixed just now — ' + total + ' total this session';
    b.style.opacity = '1';
    clearTimeout(b._hide);
    b._hide = setTimeout(() => {
      b.style.opacity = '0';
      setTimeout(() => { if (b.parentNode) b.remove(); }, 400);
    }, 6000);

    const badge = document.getElementById('cc-appt-panel-fixed');
    if (badge && badge.animate) {
      try {
        badge.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.3)' }, { transform: 'scale(1)' }],
                      { duration: 600, easing: 'ease-out' });
      } catch (e) {}
    }
    return;
  }

  // Panel closed — fall back to a brief screen toast
  let t = document.getElementById('cc-fixed-toast');
  if (!t) {
    t = document.createElement('div');
    t.id = 'cc-fixed-toast';
    t.style.cssText = 'position:fixed;bottom:24px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
      'background:#1b5e20;color:#c8e6c9;border:1px solid #2e7d32;border-radius:8px;padding:10px 18px;' +
      'font-family:Arial,sans-serif;font-size:13px;font-weight:bold;box-shadow:0 4px 18px rgba(0,0,0,0.45);' +
      'transition:opacity 0.3s;';
    document.body.appendChild(t);
  }
  t.textContent = '✓ ' + n + ' fixed — ' + total + ' total this session';
  t.style.opacity = '1';
  clearTimeout(t._hide);
  t._hide = setTimeout(() => { t.style.opacity = '0'; }, 4000);
}

// Cheap fingerprint of the calendar. textContent (not innerText) avoids forcing
// a layout pass, so this is safe to call on a timer.
function ccGridSignature(grid) {
  if (!grid) return '';
  const n = grid.querySelectorAll('.cg-visit-item').length;
  const t = grid.textContent || '';
  return n + ':' + t.length;
}

// Re-scan, then report how many problems disappeared. Panel scroll position is
// preserved so an auto-refresh doesn't yank the list out from under you.
function ccRescanAndReport() {
  const panel = document.getElementById('cc-appt-panel');
  let scrollEl = null, savedTop = 0;
  if (panel) {
    scrollEl = Array.from(panel.querySelectorAll('*'))
      .find(el => el.scrollHeight > el.clientHeight + 10);
    if (scrollEl) savedTop = scrollEl.scrollTop;
  }

  const before = ccProblemKeys(ccLastResults);
  ccScanning = true;
  try { runAppointmentsOverlapScan(); } catch (e) {}
  ccScanning = false;
  const after = ccProblemKeys(ccLastResults);

  if (savedTop) {
    const p2 = document.getElementById('cc-appt-panel');
    if (p2) {
      const s2 = Array.from(p2.querySelectorAll('*'))
        .find(el => el.scrollHeight > el.clientHeight + 10);
      if (s2) s2.scrollTop = savedTop;
    }
  }

  let fixed = 0;
  before.forEach(k => { if (!after.has(k)) fixed++; });
  if (fixed > 0) { ccFixedTotal += fixed; ccShowFixedToast(fixed, ccFixedTotal); }
  return fixed;
}

function ccStartAutoWatch(grid) {
  if (ccAutoWatchOn || !grid) return;
  ccAutoWatchOn = true;
  let timer = null;

  // 1) Event-driven: react quickly to an edit as it happens.
  const obs = new MutationObserver(() => {
    if (ccScanning) return;
    clearTimeout(timer);
    timer = setTimeout(() => {
      ccLastSig = ccGridSignature(document.getElementById('divPatientCalendarGrid-container') ||
                                  document.getElementById('divCaregiverCalendarGrid-container'));
      ccRescanAndReport();
    }, 1200);
  });
  obs.observe(grid, { childList: true, subtree: true, characterData: true });

  // 2) Safety net: poll every 10s in case a change slips past the observer
  //    (e.g. an iframe/table swap). Only rescans when the grid actually
  //    changed, so an idle page never rebuilds the panel.
  ccLastSig = ccGridSignature(grid);
  if (ccAutoTimer) clearInterval(ccAutoTimer);
  ccAutoTimer = setInterval(() => {
    if (ccScanning) return;
    const live = document.getElementById('divPatientCalendarGrid-container') ||
                 document.getElementById('divCaregiverCalendarGrid-container');
    if (!live || !live.children.length) return;
    const sig = ccGridSignature(live);
    if (sig === ccLastSig) return;   // nothing changed — skip the rebuild
    ccLastSig = sig;
    ccRescanAndReport();
  }, 10000);
}

function runAppointmentsOverlapScan() {
  // Remove old panel
  const old = document.getElementById('cc-appt-panel');
  if (old) old.remove();

  // Determine which view is active
  const patientGrid = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');

  let results = { overlaps: [], hourDiffs: [], totalVisits: 0 };

  let activeGrid = null;
  if (patientGrid && patientGrid.children.length > 0) {
    results = scanPatientGrid(patientGrid);
    activeGrid = patientGrid;
  } else if (caregiverGrid && caregiverGrid.children.length > 0) {
    results = scanCaregiverGrid(caregiverGrid);
    activeGrid = caregiverGrid;
  } else {
    return;
  }

  results.scheduleFixes = scanMemberTotals(activeGrid);
  results.overAuth = ccFlagOverAuthMembers(activeGrid);
  results.authUsage = ccScanAuthUsageList(activeGrid);
  ccInjectLegend(activeGrid);
  ccLastResults = results;
  ccStartAutoWatch(activeGrid);

  injectApptPanel({ overlaps: results.overlaps, hourDiffs: results.hourDiffs, totalVisits: results.totalVisits, authUsage: results.authUsage, panelId: 'cc-appt-panel', title: '⚕ Care Crafter — Schedule Scan' });

  // Inject remember button into panel footer
  const footer = document.getElementById('cc-appt-panel-footer');
  if (footer && !footer.querySelector('#cc-appt-remember-btn')) {
    const remBtn = document.createElement('button');
    remBtn.id = 'cc-appt-remember-btn';
    remBtn.textContent = '💾 Remember';
    remBtn.title = 'Scan all visits and save to billing memory — used to flag unconfirmed visits on the Add Internal Batch Invoice page';
    remBtn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;font-weight:bold;';
    remBtn.addEventListener('click', () => {
      const statusLbl = document.getElementById('cc-appt-remember-status') || document.createElement('span');
      scanApptAndRemember(remBtn, statusLbl);
    });
    // Status label next to button
    const statusLbl = document.createElement('span');
    statusLbl.id = 'cc-appt-remember-status';
    statusLbl.style.cssText = 'font-size:10px;color:#888;margin-right:8px;';
    chrome.storage.local.get(['_cc_billing_memory'], r => {
      if (r._cc_billing_memory) {
        const d = r._cc_billing_memory;
        const unconf = d.visits.filter(v => !v.isConfirmed).length;
        statusLbl.textContent = `Saved ${new Date(d.savedAt).toLocaleDateString()} · ${unconf} unconf`;
        statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
      }
    });
    footer.insertBefore(statusLbl, footer.firstChild);
    footer.insertBefore(remBtn, footer.firstChild);
  }

  // ── Missed Visit Tracker: export a snapshot, or compare against one ──
  if (footer && !footer.querySelector('#cc-missed-export-btn')) {
    const mStatus = document.createElement('span');
    mStatus.id = 'cc-missed-status';
    mStatus.style.cssText = 'font-size:10px;color:#ff8a80;margin-right:8px;';

    const expBtn = document.createElement('button');
    expBtn.id = 'cc-missed-export-btn';
    expBtn.textContent = '📤 Export for Billing';
    expBtn.title = 'Download a snapshot of every visit on this page (JSON to import on the billing page + CSV of the missed ones for Excel)';
    expBtn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;font-weight:bold;';
    expBtn.addEventListener('click', () => ccExportMissed(expBtn));

    const cmpInput = document.createElement('input');
    cmpInput.type = 'file';
    cmpInput.accept = '.json,application/json';
    cmpInput.style.display = 'none';
    cmpInput.addEventListener('change', e => {
      if (e.target.files[0]) ccCompareMissed(e.target.files[0], mStatus);
      e.target.value = '';
    });

    const cmpBtn = document.createElement('button');
    cmpBtn.id = 'cc-missed-compare-btn';
    cmpBtn.textContent = '📥 Compare';
    cmpBtn.title = 'Upload an earlier missed-visits .json export to see which missed visits have been fixed since then';
    cmpBtn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;font-weight:bold;';
    cmpBtn.addEventListener('click', () => cmpInput.click());

    footer.insertBefore(mStatus, footer.firstChild);
    footer.insertBefore(cmpBtn, footer.firstChild);
    footer.insertBefore(cmpInput, footer.firstChild);
    footer.insertBefore(expBtn, footer.firstChild);
  }

  // ── Auto-fix schedule vs actual time diffs ≥15min ──
  if (footer && !footer.querySelector('#cc-fix-diffs-btn')) {
    const fixBtn = document.createElement('button');
    fixBtn.id = 'cc-fix-diffs-btn';
    fixBtn.textContent = '🔧 Fix Schedule Diffs';
    fixBtn.title = 'Find visits where the scheduled time doesn\'t match the actual clock-in/out (≥15min off) and update the schedule to match — shows a preview before changing anything';
    fixBtn.style.cssText = 'background:#3a2a1a;color:#ffb74d;border:1px solid #7a5a2a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;font-weight:bold;';
    fixBtn.addEventListener('click', () => ccScanAndPreviewScheduleFixes(fixBtn));
    footer.insertBefore(fixBtn, footer.firstChild);
  }
}

// ─── MISSED VISIT TRACKER ─────────────────────────────────────────
// Snapshots every visit on the Appointments page — who, which member,
// what was scheduled, and whether the DCW actually clocked in/out.
// Export it now, re-upload the JSON days later, and it reports which
// missed visits got a V: time filled in (fixed) in the meantime.

function ccCollectVisits() {
  const out = [];
  document.querySelectorAll('.cg-visit-item').forEach(block => {
    const d = extractVisitData(block);
    if (!d.visitId) return;
    out.push({
      visitId: d.visitId,
      member: d.clientName || '',
      fne: d.clientFne || '',
      caregiver: d.caregiverName || '',
      caregiverId: d.caregiverId || '',
      date: d.dateStr || '',
      sched: d.schedRange || '',
      clockIn: d.clockIn || '',
      clockOut: d.clockOut || '',
      status: d.missedType,
      source: 'appointments'
    });
  });
  return out;
}

function ccMissedLabel(t) {
  return t === 'no_in_out' ? 'No clock-in or clock-out'
       : t === 'no_out'    ? 'No clock-out'
       : t === 'no_in'     ? 'No clock-in'
       : 'Complete';
}

function ccDownloadFile(name, content, type) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(new Blob([content], { type }));
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 5000);
}

// Reliable scroll-and-collect for the virtualizing Appointments grid — shared
// by both "Scan All & Remember" and "Export for Billing" so they always see
// the exact same complete visit list. A simple "scroll then read the DOM once"
// misses most rows because the grid recycles DOM nodes as you scroll; this
// snapshots every visit block at EACH scroll step, same as the proven
// scanApptAndRemember routine.
async function ccScanApptGrid(onProgress) {
  const patientGrid   = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');
  const activeGrid = (patientGrid  && patientGrid.children.length > 0) ? patientGrid  :
                     (caregiverGrid && caregiverGrid.children.length > 0) ? caregiverGrid : null;
  if (!activeGrid) return [];

  const scrollEl = activeGrid.querySelector('.cg-container-wrap') || activeGrid;
  const allRecords = [];
  const seenKeys   = new Set();

  function collectVisibleVisits() {
    activeGrid.querySelectorAll('.cg-visit-item').forEach(block => {
      const visitId = block.getAttribute('data-visit-id') || '';
      const rowContainer = block.closest('.cg-row-container');
      if (!rowContainer) return;
      const calCell = block.closest('[data-date-value]');
      if (!calCell) return;
      const rawDate = calCell.getAttribute('data-date-value');
      if (!rawDate) return;

      const patientCellEl = rowContainer.querySelector('.cg-patient-cell[data-patient-id]');
      const patientId = (patientCellEl ? patientCellEl.getAttribute('data-patient-id') : null)
                        || rowContainer.getAttribute('data-row-id');
      if (!patientId) return;

      const cgDiv        = block.querySelector('[data-caregiver-id]');
      const caregiverId  = cgDiv ? (cgDiv.getAttribute('data-caregiver-id') || '') : '';
      const caregiverName = cgDiv ? ((cgDiv.querySelector('.cg-text-link, span') || {}).textContent || '').trim() : '';

      const dedupKey = visitId || (patientId + '_' + rawDate + '_' + caregiverId + '_' + caregiverName);
      if (seenKeys.has(dedupKey)) return;
      seenKeys.add(dedupKey);

      const dm = rawDate.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      const dateNorm = dm ? dm[1].padStart(2,'0') + '/' + dm[2].padStart(2,'0') + '/' + dm[3] : rawDate;

      let clientName = '', clientFne = '';
      const patCell = rowContainer.querySelector('.cg-patient-cell a.cg-word-break-string');
      if (patCell) {
        const full = patCell.textContent.trim();
        clientName = full.split('\n')[0].trim();
        const fneM = full.match(/(FNE-\d+)/i);
        if (fneM) clientFne = fneM[1].toUpperCase();
      }

      const confirmedMinute = parseInt(block.getAttribute('data-confirmedminute') || '0');
      const scheduledMinute = parseInt(block.getAttribute('data-scheduledminute') || '0');

      const evvSpans = block.querySelectorAll('.cg-visit-evv');
      const evvIn    = evvSpans.length >= 1 ? evvSpans[0].textContent.trim() : '';
      const evvOut   = evvSpans.length >= 2 ? evvSpans[1].textContent.trim() : '';
      const hasFullEVV = evvIn !== '' && evvIn !== '0000' && evvOut !== '' && evvOut !== '0000';

      const totalEl = block.querySelector('[data-visittotal-id]');
      let confirmedFromTotal = false;
      if (totalEl) {
        const cm = totalEl.textContent.match(/C:(\d+):(\d+)/);
        if (cm) confirmedFromTotal = (parseInt(cm[1]) * 60 + parseInt(cm[2])) > 0;
      }
      const isConfirmed = confirmedFromTotal || confirmedMinute > 0 || hasFullEVV;

      let missedType = 'complete';
      if (!isConfirmed) missedType = (!evvIn || evvIn === '0000') && (!evvOut || evvOut === '0000') ? 'no_in_out'
                                     : (!evvOut || evvOut === '0000') ? 'no_out' : 'no_in';

      allRecords.push({
        visitId, patientId, date: dateNorm,
        caregiver: caregiverName, caregiverName, caregiverId,
        member: clientName, memberName: clientName, clientName,
        fne: clientFne, clientFne,
        clockIn: evvIn, clockOut: evvOut, sched: '',
        schedMins: scheduledMinute || null, confirmedMins: confirmedMinute || null,
        status: missedType, isConfirmed, source: 'appointments'
      });
    });
  }

  scrollEl.scrollTop = 0;
  await new Promise(r => setTimeout(r, 500));
  collectVisibleVisits();

  const scrollStep = 300;
  let lastScrollTop = -1, stuckCount = 0;
  while (true) {
    scrollEl.scrollTop += scrollStep;
    await new Promise(r => setTimeout(r, 200));
    collectVisibleVisits();
    if (scrollEl.scrollTop === lastScrollTop) {
      stuckCount++;
      if (stuckCount >= 3) break;
    } else stuckCount = 0;
    lastScrollTop = scrollEl.scrollTop;
    if (onProgress) {
      const pct = Math.round((scrollEl.scrollTop / (scrollEl.scrollHeight - scrollEl.clientHeight || 1)) * 100);
      onProgress(Math.min(pct, 99), allRecords.length);
    }
  }
  return allRecords;
}

async function ccExportMissed(btn) {
  const orig = btn ? btn.textContent : '';
  if (btn) btn.disabled = true;
  const all = await ccScanApptGrid((pct, n) => { if (btn) btn.textContent = `⏳ ${pct}% (${n} visits)...`; });
  if (btn) { btn.textContent = orig; btn.disabled = false; }
  if (!all.length) {
    alert('No visits found. Make sure the Appointments grid is loaded, then try again.');
    return;
  }
  const missed = all.filter(v => v.status !== 'complete');
  const stamp = new Date().toISOString().slice(0, 10);

  // JSON = the file you re-upload later / import on the billing page — keeps
  // EVERY visit (not just missed ones), so the billing importer can tell
  // which client-days are fully clean vs which have a problem visit.
  ccDownloadFile('missed-visits-' + stamp + '.json',
    JSON.stringify({ exportedAt: new Date().toISOString(), source: 'appointments', totalVisits: all.length, missedCount: missed.length, visits: all }),
    'application/json');

  // CSV = readable copy of just the missed ones, for Excel.
  const hdr = ['Member', 'FNE', 'Caregiver', 'Caregiver #', 'Date', 'Scheduled', 'Clock In', 'Clock Out', 'Status'];
  const rows = missed.map(v => [v.member, v.fne, v.caregiver, v.caregiverId, v.date, v.sched, v.clockIn, v.clockOut, ccMissedLabel(v.status)]);
  const csv = [hdr, ...rows].map(r => r.map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(',')).join('\n');
  ccDownloadFile('missed-visits-' + stamp + '.csv', csv, 'text/csv');

  if (btn) { const o = btn.textContent; btn.textContent = '✓ ' + all.length + ' total, ' + missed.length + ' missed'; setTimeout(() => btn.textContent = o, 3500); }
}

// ─── SCHEDULE-DIFF AUTO-FIX ─────────────────────────────────────────
// Finds fully-confirmed visits (real EVV clock-in/out on file) whose
// scheduled time is off from the actual clocked time by >=15min, and
// offers to update the schedule to match — with a preview + explicit
// confirm before anything is actually written to HHAeXchange.

function ccFmtHHMM(t) {
  if (!t || t.length !== 4) return t || '--:--';
  return t.slice(0, 2) + ':' + t.slice(2);
}

// Round an HHMM clock time to the NEAREST 15-minute mark — HHAeXchange
// schedules are always on a 15-min grid; the actual EVV clock-in/out itself
// is never changed, only the schedule we set to match it. 1-7 min past a
// mark rounds down, 8-14 min rounds up (e.g. 13:02 -> 13:00, 13:08 -> 13:15).
function ccRoundToQuarterHour(hhmm) {
  if (!hhmm || hhmm.length !== 4) return hhmm;
  const total = parseInt(hhmm.slice(0, 2), 10) * 60 + parseInt(hhmm.slice(2), 10);
  let rounded = Math.round(total / 15) * 15;
  rounded = ((rounded % 1440) + 1440) % 1440; // wrap midnight
  const rh = Math.floor(rounded / 60), rm = rounded % 60;
  return String(rh).padStart(2, '0') + String(rm).padStart(2, '0');
}

// Reads every client's weekly A: (authorized) / S: (scheduled) totals from
// the same grid cells scanMemberTotals() looks at, but without that function's
// billing-shortfall filter — used to cap schedule fixes so they never push a
// client's weekly scheduled hours past what's authorized.
function ccScanMemberAuthSched(container) {
  const out = {};
  if (!container) return out;
  const all = Array.from(container.querySelectorAll('*')).filter(el => {
    const t = el.innerText || '';
    return /A:\s*\d+:\d{2}/.test(t) && /S:\s*\d+:\d{2}/.test(t);
  });
  const cells = all.filter(el => !all.some(o => o !== el && el.contains(o)));
  cells.forEach(cell => {
    const t = cell.innerText || '';
    const A = ccParseHM((t.match(/A:\s*(\d+:\d{2})/) || [])[1]);
    const S = ccParseHM((t.match(/S:\s*(\d+:\d{2})/) || [])[1]);
    if (A === null) return;
    const row = cell.closest('tr') || cell.parentElement;
    const link = row ? row.querySelector('a') : null;
    const member = link ? (link.textContent || '').trim() : (t.split('\n')[0] || '').trim();
    if (!member) return;
    out[ccMemberKey(member)] = { auth: A, sched: S != null ? S : A };
  });
  return out;
}

function ccHHMMToMin(hhmm) { return parseInt(hhmm.slice(0, 2), 10) * 60 + parseInt(hhmm.slice(2), 10); }
function ccMinToHHMM(min) { min = ((min % 1440) + 1440) % 1440; return String(Math.floor(min / 60)).padStart(2, '0') + String(min % 60).padStart(2, '0'); }
function ccDurationMins(startHHMM, endHHMM) {
  let d = ccHHMMToMin(endHHMM) - ccHHMMToMin(startHHMM);
  if (d <= 0) d += 1440; // overnight wrap
  return d;
}

async function ccScanScheduleDiffCandidates(onProgress) {
  const patientGrid   = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');
  const activeGrid = (patientGrid && patientGrid.children.length > 0) ? patientGrid :
                     (caregiverGrid && caregiverGrid.children.length > 0) ? caregiverGrid : null;
  if (!activeGrid) return [];

  const scrollEl = activeGrid.querySelector('.cg-container-wrap') || activeGrid;
  const candidates = [];
  const seenKeys = new Set();
  // Actual-time interval for every visit seen (regardless of diff status) —
  // used to exclude any visit involved in an overlap from auto-fixing.
  const intervalsById = new Map();

  function collect() {
    activeGrid.querySelectorAll('.cg-visit-item[data-visit-id]').forEach(block => {
      const visitId = block.getAttribute('data-visit-id') || '';
      if (!visitId) return;

      // Track this visit's real clock-in/out window for overlap detection,
      // whether or not it ends up being a schedule-diff candidate below.
      if (!intervalsById.has(visitId)) {
        const evvSpans0 = block.querySelectorAll('.cg-visit-evv');
        const evvIn0  = evvSpans0.length >= 1 ? evvSpans0[0].textContent.trim() : '';
        const evvOut0 = evvSpans0.length >= 2 ? evvSpans0[1].textContent.trim() : '';
        if (evvIn0.length === 4 && evvOut0.length === 4) {
          const rc0 = block.closest('.cg-row-container');
          const pc0 = rc0 ? rc0.querySelector('.cg-patient-cell a.cg-word-break-string') : null;
          const memberKey0 = pc0 ? ccMemberKey(pc0.textContent.trim().split('\n')[0]) : '';
          const cgDiv0 = block.querySelector('[data-caregiver-id]');
          const caregiverId0 = cgDiv0 ? (cgDiv0.getAttribute('data-caregiver-id') || '') : '';
          const cc0 = block.closest('[data-date-value]');
          const date0 = cc0 ? cc0.getAttribute('data-date-value') : '';
          let s0 = ccHHMMToMin(evvIn0), e0 = ccHHMMToMin(evvOut0);
          if (e0 <= s0) e0 += 1440; // overnight wrap
          intervalsById.set(visitId, { visitId, caregiverId: caregiverId0, memberKey: memberKey0, date: date0, start: s0, end: e0 });
        }
      }

      if (seenKeys.has(visitId)) return;

      const scheduledMinute = parseInt(block.getAttribute('data-scheduledminute') || '0');
      const confirmedMinute = parseInt(block.getAttribute('data-confirmedminute') || '0');
      if (!scheduledMinute || !confirmedMinute) return;                 // need both real durations
      if (Math.abs(scheduledMinute - confirmedMinute) < 15) return;     // not a meaningful diff

      const evvSpans = block.querySelectorAll('.cg-visit-evv');
      const evvIn  = evvSpans.length >= 1 ? evvSpans[0].textContent.trim() : '';
      const evvOut = evvSpans.length >= 2 ? evvSpans[1].textContent.trim() : '';
      if (!evvIn || !evvOut) return;                                    // need real actual times to fix TO

      const link = block.querySelector('a[data-event-type="visit"]');
      const sM = link ? link.textContent.match(/S:(\d{4})\s*-\s*(\d{4})/) : null;
      const schedStart = sM ? sM[1] : '', schedEnd = sM ? sM[2] : '';
      if (!schedStart || !schedEnd) return;

      const newStart = ccRoundToQuarterHour(evvIn);
      const newEnd   = ccRoundToQuarterHour(evvOut);
      if (schedStart === newStart && schedEnd === newEnd) return;       // already on target, nothing to fix

      const rowContainer = block.closest('.cg-row-container');
      const patCell = rowContainer ? rowContainer.querySelector('.cg-patient-cell a.cg-word-break-string') : null;
      const member = patCell ? patCell.textContent.trim().split('\n')[0].trim() : '';
      const cgDiv = block.querySelector('[data-caregiver-id]');
      const caregiver = cgDiv ? ((cgDiv.querySelector('.cg-text-link, span') || {}).textContent || '').trim() : '';
      const calCell = block.closest('[data-date-value]');
      const date = calCell ? calCell.getAttribute('data-date-value') : '';

      seenKeys.add(visitId);
      candidates.push({ visitId, member, caregiver, date, schedStart, schedEnd, evvIn, evvOut, newStart, newEnd,
        diffMins: Math.abs(scheduledMinute - confirmedMinute) });
    });
  }

  scrollEl.scrollTop = 0;
  await new Promise(r => setTimeout(r, 500));
  collect();
  const scrollStep = 300;
  let lastScrollTop = -1, stuckCount = 0;
  while (true) {
    scrollEl.scrollTop += scrollStep;
    await new Promise(r => setTimeout(r, 200));
    collect();
    if (scrollEl.scrollTop === lastScrollTop) { stuckCount++; if (stuckCount >= 3) break; }
    else stuckCount = 0;
    lastScrollTop = scrollEl.scrollTop;
    if (onProgress) {
      const pct = Math.round((scrollEl.scrollTop / (scrollEl.scrollHeight - scrollEl.clientHeight || 1)) * 100);
      onProgress(Math.min(pct, 99), candidates.length);
    }
  }
  scrollEl.scrollTop = 0;

  // ── Exclude any visit involved in an overlap ──
  // Same caregiver double-booked, or same client double-staffed by two
  // caregivers at overlapping times — editing a schedule while there's an
  // unresolved overlap is too risky to automate, so skip it entirely.
  const overlappingVisitIds = new Set();
  function flagOverlaps(keyFn) {
    const groups = {};
    intervalsById.forEach(iv => {
      const key = keyFn(iv);
      if (!key) return;
      (groups[key] = groups[key] || []).push(iv);
    });
    Object.values(groups).forEach(list => {
      for (let i = 0; i < list.length; i++) {
        for (let j = i + 1; j < list.length; j++) {
          const a = list[i], b = list[j];
          const overlap = Math.min(a.end, b.end) - Math.max(a.start, b.start);
          if (overlap >= 1) { overlappingVisitIds.add(a.visitId); overlappingVisitIds.add(b.visitId); }
        }
      }
    });
  }
  flagOverlaps(iv => iv.caregiverId ? iv.caregiverId + '_' + iv.date : null); // same caregiver, double-booked
  flagOverlaps(iv => iv.memberKey   ? iv.memberKey   + '_' + iv.date : null); // same client, double-staffed

  const skippedForOverlap = candidates.filter(c => overlappingVisitIds.has(c.visitId)).length;
  let filtered = candidates.filter(c => !overlappingVisitIds.has(c.visitId));
  candidates.length = 0;
  candidates.push(...filtered);

  // ── Cap fixes against each client's weekly authorized hours ──
  // Extending a schedule to match actual clock times can push a client past
  // their weekly auth. Track running scheduled minutes per client (starting
  // from their current weekly S: total) and trim any fix that would exceed
  // their A: total — the corrected start is kept, but the end is capped as
  // far as remaining auth allows (rounded down to a 15-min mark).
  const authMap = ccScanMemberAuthSched(activeGrid);
  const runningSched = {};
  candidates.forEach(c => {
    const key = ccMemberKey(c.member);
    const info = authMap[key];
    if (!info) return; // no auth data found for this client — leave the fix as-is
    if (runningSched[key] == null) runningSched[key] = info.sched;

    const oldDur = ccDurationMins(c.schedStart, c.schedEnd);
    const targetDur = ccDurationMins(c.newStart, c.newEnd);
    const delta = targetDur - oldDur;

    if (delta <= 0) { runningSched[key] += delta; return; } // shrinking/unchanged — never a problem

    const remaining = info.auth - runningSched[key];
    if (delta <= remaining) { runningSched[key] += delta; return; } // fits within auth fine

    const allowed = Math.max(0, Math.floor(remaining / 15) * 15); // round down, never over cap
    const cappedDur = oldDur + allowed;
    c.newEnd = ccMinToHHMM(ccHHMMToMin(c.newStart) + cappedDur);
    c.authCapped = true;
    c.authNote = 'Capped — full fix would exceed weekly auth (' + ccFmtHM(info.auth) + ') by ' +
                 ccFmtHM(delta - allowed) + '; extended ' + ccFmtHM(allowed) + ' instead of ' + ccFmtHM(delta);
    runningSched[key] += allowed;
  });
  // Drop anything the capping reduced back down to "no actual change."
  const trimmed = candidates.filter(c => !(c.newStart === c.schedStart && c.newEnd === c.schedEnd));
  trimmed.skippedForOverlap = skippedForOverlap;

  return trimmed;
}

async function ccScanAndPreviewScheduleFixes(btn) {
  const orig = btn.textContent;
  btn.disabled = true;
  const candidates = await ccScanScheduleDiffCandidates((pct, n) => { btn.textContent = `⏳ ${pct}% (${n} found)...`; });
  btn.textContent = orig;
  btn.disabled = false;
  if (!candidates.length) {
    const skippedOverlap = candidates.skippedForOverlap || 0;
    alert('No fixable schedule differences found.' +
          (skippedOverlap ? ` (${skippedOverlap} skipped — involved in an overlap.)` :
           ' (Looking for fully-confirmed visits whose scheduled time is ≥15min off from actual clock-in/out.)'));
    return;
  }
  ccShowScheduleDiffPreview(candidates);
}

function ccShowScheduleDiffPreview(candidates) {
  document.getElementById('cc-diff-preview-overlay')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'cc-diff-preview-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:2147483600;display:flex;align-items:center;justify-content:center;font-family:Arial,sans-serif;';

  const box = document.createElement('div');
  box.style.cssText = 'background:#1a1a2e;color:#e0e0e0;border-radius:10px;width:min(680px,92vw);max-height:85vh;display:flex;flex-direction:column;box-shadow:0 8px 40px rgba(0,0,0,0.6);';

  const header = document.createElement('div');
  header.style.cssText = 'padding:14px 18px;border-bottom:1px solid #334;font-weight:bold;font-size:14px;';
  const cappedCount = candidates.filter(c => c.authCapped).length;
  const skippedOverlap = candidates.skippedForOverlap || 0;
  header.textContent = `🔧 Fix Schedule Diffs — ${candidates.length} visit(s) found` +
                        (cappedCount ? ` (${cappedCount} capped to stay within weekly auth)` : '') +
                        (skippedOverlap ? ` (${skippedOverlap} skipped — overlapping visit)` : '');

  const sub = document.createElement('div');
  sub.style.cssText = 'padding:8px 18px;font-size:11px;color:#aaa;border-bottom:1px solid #334;';
  sub.textContent = 'Review below, uncheck anything you don\'t want changed, then click Apply. Nothing is changed until you click Apply.';

  const list = document.createElement('div');
  list.style.cssText = 'overflow-y:auto;padding:10px 18px;flex:1;';

  candidates.forEach((c, i) => {
    const row = document.createElement('label');
    row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:8px 6px;border-bottom:1px solid #2a2e3d;cursor:pointer;';
    row.innerHTML = `
      <input type="checkbox" checked data-idx="${i}" style="width:16px;height:16px;flex-shrink:0;">
      <div style="flex:1;">
        <div style="font-weight:bold;font-size:12px;color:#ffffff;">${c.member || '(unknown member)'} <span style="color:#aaa;font-weight:normal;">— ${c.caregiver || ''} — ${c.date}</span></div>
        <div style="font-size:11px;margin-top:3px;line-height:1.6;">
          <span style="color:#888;">Current schedule (S:)</span> <span style="color:#ff8a80;">${ccFmtHHMM(c.schedStart)}-${ccFmtHHMM(c.schedEnd)}</span><br>
          <span style="color:#888;">Actual clock-in/out (V:)</span> <span style="color:#90caf9;">${ccFmtHHMM(c.evvIn)}-${ccFmtHHMM(c.evvOut)}</span> <span style="color:#888;">— never changed</span><br>
          <span style="color:#888;">New schedule (S:) →</span> <span style="color:#69f0ae;">${ccFmtHHMM(c.newStart)}-${ccFmtHHMM(c.newEnd)}</span> <span style="color:#888;">(${Math.floor(c.diffMins/60)}h${c.diffMins%60}m diff)</span>
        </div>
        ${c.authCapped ? `<div style="font-size:10px;color:#ffb74d;margin-top:2px;">⚠ ${c.authNote}</div>` : ''}
      </div>`;
    list.appendChild(row);
  });

  const footer = document.createElement('div');
  footer.style.cssText = 'padding:12px 18px;border-top:1px solid #334;display:flex;gap:10px;align-items:center;';
  const status = document.createElement('span');
  status.style.cssText = 'font-size:11px;color:#888;flex:1;';
  const abortState = { stop: false };
  let reloadTimer = null;

  const exportBtn = document.createElement('button');
  exportBtn.textContent = '📤 Export';
  exportBtn.title = 'Download the current candidate list (old schedule, actual, new schedule) as CSV + JSON';
  exportBtn.style.cssText = 'background:#1a3a2a;color:#69f0ae;border:1px solid #2a5a3a;border-radius:6px;padding:8px 14px;cursor:pointer;font-size:12px;font-weight:bold;';
  exportBtn.onclick = () => {
    const stamp = new Date().toISOString().slice(0, 10);
    const hdr = ['Member', 'Caregiver', 'Date', 'Sched Start', 'Sched End', 'Actual In', 'Actual Out',
                 'New Sched Start', 'New Sched End', 'Diff (min)', 'Auth Capped', 'Note', 'Visit ID'];
    const rows = candidates.map(c => [
      c.member, c.caregiver, c.date, ccFmtHHMM(c.schedStart), ccFmtHHMM(c.schedEnd),
      ccFmtHHMM(c.evvIn), ccFmtHHMM(c.evvOut), ccFmtHHMM(c.newStart), ccFmtHHMM(c.newEnd),
      c.diffMins, c.authCapped ? 'Yes' : 'No', c.authNote || '', c.visitId
    ]);
    const csv = [hdr, ...rows].map(r => r.map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(',')).join('\n');
    ccDownloadFile('schedule-diff-fixes-' + stamp + '.csv', csv, 'text/csv');
    ccDownloadFile('schedule-diff-fixes-' + stamp + '.json',
      JSON.stringify({ exportedAt: new Date().toISOString(), totalCandidates: candidates.length, candidates }),
      'application/json');
  };

  const cancelBtn = document.createElement('button');
  cancelBtn.textContent = 'Cancel';
  cancelBtn.style.cssText = 'background:#333;color:#ccc;border:none;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;';
  cancelBtn.onclick = () => {
    if (reloadTimer) clearTimeout(reloadTimer);
    abortState.stop = true;   // in case it's mid-run — Apply loop checks this and breaks
    overlay.remove();
  };
  const applyBtn = document.createElement('button');
  applyBtn.textContent = 'Apply Selected';
  applyBtn.style.cssText = 'background:#c62828;color:#fff;border:none;border-radius:6px;padding:8px 16px;cursor:pointer;font-size:12px;font-weight:bold;';
  applyBtn.onclick = async () => {
    const checked = Array.from(list.querySelectorAll('input[type="checkbox"]:checked')).map(cb => candidates[+cb.dataset.idx]);
    if (!checked.length) { status.textContent = 'Nothing selected.'; return; }
    applyBtn.disabled = true;
    cancelBtn.textContent = 'Stop';   // stays clickable — sets abort flag instead of being disabled

    // Shrink into a small corner widget (no backdrop) while applying, so the
    // actual page underneath is visible and you can watch each visit update.
    overlay.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:2147483600;font-family:Arial,sans-serif;background:transparent;display:block;pointer-events:none;';
    box.style.cssText = 'background:#1a1a2e;color:#e0e0e0;border-radius:10px;width:340px;max-height:220px;display:flex;flex-direction:column;box-shadow:0 8px 40px rgba(0,0,0,0.6);pointer-events:auto;border:1px solid #445;';
    list.style.cssText = 'overflow-y:auto;padding:6px 14px;flex:1;max-height:110px;';
    sub.style.display = 'none';

    const { ok, fail, results } = await ccApplyScheduleFixes(checked, (done, total, o, f, current) => {
      status.textContent = `${done}/${total} (${o} ok, ${f} failed)`;
      if (current) header.textContent = `🔧 Fixing: ${current.member || ''} ${current.date || ''}...`;
    }, abortState);
    // Replace the checkbox list with a per-visit results summary so it's
    // clear exactly which ones changed before the page reloads.
    header.textContent = '🔧 Fix Schedule Diffs — done';
    list.innerHTML = '';
    results.forEach(r => {
      const row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:8px 6px;border-bottom:1px solid #2a2e3d;';
      row.innerHTML = `
        <span style="font-size:16px;flex-shrink:0;">${r.success ? '✅' : '❌'}</span>
        <div style="flex:1;">
          <div style="font-weight:bold;font-size:12px;color:#ffffff;">${r.member || '(unknown member)'} <span style="color:#aaa;font-weight:normal;">— ${r.caregiver || ''} — ${r.date}</span></div>
          <div style="font-size:11px;margin-top:2px;color:${r.success ? '#69f0ae' : '#ff8a80'};">
            ${r.success ? 'S: ' + ccFmtHHMM(r.schedStart) + '-' + ccFmtHHMM(r.schedEnd) + ' → ' + ccFmtHHMM(r.newStart) + '-' + ccFmtHHMM(r.newEnd) : 'Failed: ' + r.error}
          </div>
        </div>`;
      list.appendChild(row);
    });
    status.textContent = (abortState.stop ? `Stopped — ` : `Done — `) + `${ok} fixed, ${fail} failed. Reloading in a few seconds (or close now).`;
    cancelBtn.textContent = 'Close now';
    cancelBtn.onclick = () => { if (reloadTimer) clearTimeout(reloadTimer); location.reload(); };
    reloadTimer = setTimeout(() => location.reload(), 6000);
  };
  footer.appendChild(status);
  footer.appendChild(exportBtn);
  footer.appendChild(cancelBtn);
  footer.appendChild(applyBtn);

  box.appendChild(header); box.appendChild(sub); box.appendChild(list); box.appendChild(footer);
  overlay.appendChild(box);
  document.body.appendChild(overlay);
}

// Applies fixes sequentially (one visit at a time) — clicks the real edit
// icon, sets the real input fields, clicks the real Save button, so it goes
// through HHAeXchange's own save logic exactly like a manual edit would.
async function ccApplyScheduleFixes(items, onProgress, abortState) {
  const setNativeValue = (el, value) => {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };
  const clickEl = (el) => el && el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

  // HHAeXchange pops an "Information has been saved." confirmation dialog
  // after every save — auto-dismiss it so the batch doesn't stall waiting
  // for a manual OK click on every single visit.
  const dismissSaveDialog = async () => {
    for (let tries = 0; tries < 15; tries++) {
      const btns = Array.from(document.querySelectorAll('button, a, input[type="button"]'))
        .filter(b => b.offsetParent !== null && b.textContent.trim().toUpperCase() === 'OK');
      if (btns.length) { clickEl(btns[btns.length - 1]); await new Promise(r => setTimeout(r, 250)); return true; }
      await new Promise(r => setTimeout(r, 200));
    }
    return false;
  };

  let ok = 0, fail = 0;
  const results = [];
  for (let i = 0; i < items.length; i++) {
    if (abortState && abortState.stop) break;
    const c = items[i];
    try {
      const block = document.querySelector('.cg-visit-item[data-visit-id="' + c.visitId + '"]');
      if (!block) throw new Error('visit not found on page (may need to reload)');
      block.scrollIntoView({ behavior: 'smooth', block: 'center' });
      await new Promise(r => setTimeout(r, 350));

      const editIcon = block.querySelector('svg.cg-edit-icon, .cg-edit-icon');
      clickEl(editIcon);
      await new Promise(r => setTimeout(r, 400));

      const startInput = block.querySelector('.cg-quick-edit-start-time');
      const endInput   = block.querySelector('.cg-quick-edit-end-time');
      if (!startInput || !endInput) throw new Error('edit fields did not open');

      setNativeValue(startInput, c.newStart);
      setNativeValue(endInput, c.newEnd);
      await new Promise(r => setTimeout(r, 200));

      const saveBtn = block.querySelector('.cg-edit-save-tick');
      if (!saveBtn) throw new Error('save button not found');
      clickEl(saveBtn);
      await new Promise(r => setTimeout(r, 600));
      await dismissSaveDialog();
      ok++;
      results.push({ ...c, success: true });
    } catch (err) {
      fail++;
      console.log('[CC-FIX-SCHEDULE] failed for visit', c.visitId, err.message);
      results.push({ ...c, success: false, error: err.message });
    }
    if (onProgress) onProgress(i + 1, items.length, ok, fail, items[i + 1]);
  }
  return { ok, fail, results };
}

function ccCompareMissed(file, statusEl) {
  const reader = new FileReader();
  reader.onload = e => {
    let old;
    try { old = JSON.parse(e.target.result); }
    catch (err) { statusEl.textContent = '⚠ Could not read that file — pick the .json export.'; return; }
    const oldVisits = (old && old.visits) || [];
    if (!oldVisits.length) { statusEl.textContent = '⚠ That file has no visit data in it.'; return; }

    const now = ccCollectVisits();
    if (!now.length) { statusEl.textContent = '⚠ No visits loaded on this page to compare against.'; return; }
    const nowById = {}; now.forEach(v => nowById[v.visitId] = v);
    const oldById = {}; oldVisits.forEach(v => oldById[v.visitId] = v);

    const fixed = [], stillOpen = [], notOnPage = [], newMissed = [];
    oldVisits.forEach(v => {
      if (v.status === 'complete') return;      // wasn't a missed visit back then
      const cur = nowById[v.visitId];
      if (!cur) { notOnPage.push(v); return; }  // week changed / visit deleted
      if (cur.status === 'complete') fixed.push(Object.assign({}, v, { nowIn: cur.clockIn, nowOut: cur.clockOut }));
      else stillOpen.push(cur);
    });
    now.forEach(v => { if (v.status !== 'complete' && !oldById[v.visitId]) newMissed.push(v); });

    ccShowCompareResults(old, fixed, stillOpen, notOnPage, newMissed);
    statusEl.textContent = '';
  };
  reader.readAsText(file);
}

function ccShowCompareResults(old, fixed, stillOpen, notOnPage, newMissed) {
  const existing = document.getElementById('cc-missed-report');
  if (existing) existing.remove();

  const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const when = old.exportedAt ? new Date(old.exportedAt).toLocaleDateString() : 'earlier';
  const wasMissed = fixed.length + stillOpen.length + notOnPage.length;
  const pct = wasMissed ? Math.round((fixed.length / wasMissed) * 100) : 0;

  // Agency rule: no more than 2 manual timesheets per client. Count each
  // member's CURRENT open missed visits and flag anyone over the limit.
  const perMember = {};
  stillOpen.concat(newMissed).forEach(v => {
    const k = (v.fne || v.member || '?');
    if (!perMember[k]) perMember[k] = { member: v.member, fne: v.fne, n: 0 };
    perMember[k].n++;
  });
  const overLimit = Object.values(perMember).filter(m => m.n > 2).sort((a, b) => b.n - a.n);

  const tbl = (rows, cols) => rows.length
    ? '<table style="width:100%;border-collapse:collapse;font-size:11px">' +
      '<tr style="background:#1a1d24">' + cols.map(c => '<th style="text-align:left;padding:5px 7px;color:#8b8fa8;font-weight:600;border-bottom:1px solid #2a2d38">' + c + '</th>').join('') + '</tr>' +
      rows.join('') + '</table>'
    : '<div style="color:#5a5f75;font-size:11px;padding:6px 2px">None</div>';

  const fixedRows = fixed.map(v =>
    '<tr><td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.member) + '<div style="color:#5a5f75;font-size:10px">' + esc(v.fne) + '</div></td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.caregiver) + '</td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.date) + '</td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f;color:#ff8a80">' + esc(ccMissedLabel(v.status)) + '</td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f;color:#69f0ae;font-weight:700">' + esc(v.nowIn) + ' - ' + esc(v.nowOut) + '</td></tr>').join('');

  const openRows = stillOpen.map(v =>
    '<tr><td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.member) + '<div style="color:#5a5f75;font-size:10px">' + esc(v.fne) + '</div></td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.caregiver) + '</td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f">' + esc(v.date) + '</td>' +
    '<td style="padding:5px 7px;border-bottom:1px solid #23262f;color:#ff8a80">' + esc(ccMissedLabel(v.status)) + '</td></tr>').join('');

  const p = document.createElement('div');
  p.id = 'cc-missed-report';
  p.style.cssText = 'position:fixed;top:60px;right:24px;width:640px;max-height:80vh;overflow:auto;background:#111318;border:1px solid #2a2d38;border-radius:12px;box-shadow:0 12px 48px rgba(0,0,0,.7);z-index:2147483646;font-family:system-ui,sans-serif;color:#e8eaed';
  p.innerHTML =
    '<div style="display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #23262f;background:#161920;border-radius:12px 12px 0 0">' +
      '<div style="font-size:13px;font-weight:700;flex:1">📋 Missed Visit Comparison</div>' +
      '<button id="cc-missed-close" style="background:none;border:none;color:#8b8fa8;font-size:18px;cursor:pointer;line-height:1">✕</button>' +
    '</div>' +
    '<div style="padding:14px">' +
      '<div style="font-size:11px;color:#8b8fa8;margin-bottom:12px">Comparing against your export from <b style="color:#e8eaed">' + esc(when) + '</b></div>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:14px">' +
        '<div style="background:#0f2417;border:1px solid #1b5e20;border-radius:8px;padding:10px"><div style="font-size:22px;font-weight:800;color:#69f0ae">' + fixed.length + '</div><div style="font-size:10px;color:#8b8fa8">FIXED</div></div>' +
        '<div style="background:#2a1416;border:1px solid #5c1a1f;border-radius:8px;padding:10px"><div style="font-size:22px;font-weight:800;color:#ff8a80">' + stillOpen.length + '</div><div style="font-size:10px;color:#8b8fa8">STILL OPEN</div></div>' +
        '<div style="background:#2a2416;border:1px solid #5c4a1a;border-radius:8px;padding:10px"><div style="font-size:22px;font-weight:800;color:#ffd54f">' + newMissed.length + '</div><div style="font-size:10px;color:#8b8fa8">NEW SINCE</div></div>' +
        '<div style="background:#161920;border:1px solid #2a2d38;border-radius:8px;padding:10px"><div style="font-size:22px;font-weight:800;color:#90caf9">' + pct + '%</div><div style="font-size:10px;color:#8b8fa8">FIX RATE</div></div>' +
      '</div>' +
      (overLimit.length
        ? '<div style="background:#2a1416;border:1px solid #5c1a1f;border-radius:8px;padding:10px 12px;margin-bottom:14px">' +
          '<div style="font-size:11px;font-weight:700;color:#ff8a80;margin-bottom:6px">⚠ Over the 2-timesheet limit (' + overLimit.length + ' member' + (overLimit.length > 1 ? 's' : '') + ')</div>' +
          overLimit.map(m => '<div style="font-size:11px;color:#e8eaed;padding:2px 0">' + esc(m.member) + ' <span style="color:#5a5f75">' + esc(m.fne) + '</span> — <b style="color:#ff8a80">' + m.n + ' open missed visits</b></div>').join('') +
          '</div>'
        : '') +
      '<div style="font-size:11px;font-weight:700;color:#69f0ae;margin:10px 0 6px">✓ Fixed since last export (' + fixed.length + ')</div>' +
      tbl([fixedRows], ['Member', 'Caregiver', 'Date', 'Was', 'Now V:']) +
      '<div style="font-size:11px;font-weight:700;color:#ff8a80;margin:16px 0 6px">✕ Still open (' + stillOpen.length + ')</div>' +
      tbl([openRows], ['Member', 'Caregiver', 'Date', 'Missing']) +
      (notOnPage.length ? '<div style="font-size:10px;color:#5a5f75;margin-top:12px">' + notOnPage.length + ' visit(s) from the old export are not on the page right now — make sure you are viewing the same week.</div>' : '') +
    '</div>';
  document.body.appendChild(p);
  p.querySelector('#cc-missed-close').addEventListener('click', () => p.remove());
}

function extractVisitData(block) {
  // Real HHAeXchange Appointments page structure (confirmed from actual HTML):
  //
  // div.cg-container-wrap
  //   div.cg-container
  //     div.cg-row-container[data-row-id="19786141"]
  //       div.cg-info-cell
  //         div.cg-patient-cell[data-patient-id="19786141"]
  //           a.cg-word-break-string => "ABDUL HAMEED, AMAL\n(FNE-900042)"
  //       div[data-date-value="4/27/2026"].cg-calendar-cell   ← DATE IS HERE
  //         div.cg-visit-cell
  //           div.cg-visit-item[data-visit-id][data-scheduledminute]
  //             a[data-event-type="visit"] => "S:1700 - 2200 (PCA)"
  //             span.cg-visit-span  → V:<span.cg-visit-evv>1656</span> - <span.cg-visit-evv>2159</span>
  //             div[data-visittotal-id] => "S:05:00  C:05:03"
  //             div[data-caregiver-id] span.cg-text-link => "SALIH, YASIR"

  const visitId = block.getAttribute('data-visit-id') || '';

  // ── Scheduled time from <a data-event-type="visit"> ──────────────
  let schedRange = null;
  const schedLink = block.querySelector('a[data-event-type="visit"]');
  if (schedLink) {
    const txt = schedLink.textContent.trim();
    const m = txt.match(/S:\s*(\d{3,4})\s*[-–]\s*(\d{3,4})/i);
    if (m) schedRange = m[1] + '-' + m[2];
  }

  // ── Actual visit time from span.cg-visit-span ────────────────────
  // Parsed as two INDEPENDENT halves so a partial punch is detectable:
  //   "V:0456 - 1602"  → in=0456  out=1602  (complete)
  //   "V:1714 -"       → in=1714  out=null  (no clock-out)
  //   "V: - 1602"      → in=null  out=1602  (no clock-in)
  //   "V: -"           → in=null  out=null  (never clocked in or out)
  // An empty V: means the DCW did not clock in/out — that's a missed visit.
  let visitRange = null, clockIn = null, clockOut = null;
  const visitSpan = block.querySelector('.cg-visit-span');
  if (visitSpan) {
    const raw = visitSpan.textContent.replace(/\s+/g, ' ').trim();
    const vIdx = raw.search(/V\s*:/i);
    const rest = vIdx === -1 ? raw : raw.slice(vIdx).replace(/^V\s*:\s*/i, '');
    const halves = rest.split(/[-–]/);
    const a = (halves[0] || '').trim();
    const b = (halves[1] || '').trim();
    if (/^\d{3,4}$/.test(a)) clockIn = a;
    if (/^\d{3,4}$/.test(b)) clockOut = b;
    if (clockIn && clockOut) visitRange = clockIn + '-' + clockOut;
  }
  // Classify what (if anything) is missing
  const missedType = (clockIn && clockOut) ? 'complete'
    : (!clockIn && !clockOut) ? 'no_in_out'
    : (clockIn && !clockOut) ? 'no_out'
    : 'no_in';

  // ── Caregiver name AND ID from [data-caregiver-id] span.cg-text-link ────
  let caregiverName = null;
  let caregiverId = null;
  const cgDiv = block.querySelector('[data-caregiver-id]');
  if (cgDiv) {
    caregiverId = cgDiv.getAttribute('data-caregiver-id');
    const cgEl = cgDiv.querySelector('.cg-text-link, span');
    if (cgEl) caregiverName = cgEl.textContent.trim();
  }

  // ── Scheduled vs confirmed hours from [data-visittotal-id] ───────
  // Format: "S:05:00  C:05:03"
  let schedHrs = null, confirmedHrs = null;
  const totalEl = block.querySelector('[data-visittotal-id]');
  if (totalEl) {
    const txt = totalEl.textContent.trim();
    const sm = txt.match(/S:([\d:]+)/);
    const cm = txt.match(/C:([\d:]+)/);
    if (sm) schedHrs = parseHHMM(sm[1]);
    if (cm) confirmedHrs = parseHHMM(cm[1]);
  }

  // ── Date: from parent div.cg-calendar-cell[data-date-value] ──────
  // The structure is NOT a <table>. It is:
  //   div.cg-row-container > div.cg-calendar-cell[data-date-value="4/27/2026"] > div.cg-visit-cell > div.cg-visit-item
  // We walk up: block → cg-visit-cell → cg-calendar-cell → data-date-value
  let dateStr = null;
  try {
    const visitCell = block.closest('.cg-visit-cell');
    const calCell = visitCell ? visitCell.closest('[data-date-value]') : null;
    if (calCell) dateStr = calCell.getAttribute('data-date-value');
  } catch(e) {}

  // ── Client name: from sibling cg-info-cell in the same cg-row-container ──
  // Walk up to cg-row-container, then find cg-patient-cell inside cg-info-cell
  let clientName = null;
  let patientId = null;
  let clientFne = null;
  try {
    const rowContainer = block.closest('.cg-row-container');
    if (rowContainer) {
      patientId = rowContainer.getAttribute('data-row-id');
      const patientCell = rowContainer.querySelector('.cg-patient-cell');
      if (patientCell) {
        const nameLink = patientCell.querySelector('a.cg-word-break-string');
        const full = (nameLink || patientCell).textContent.trim();
        // Text is "ABDUL HAMEED, AMAL\n(FNE-900042)" — name on line 1, FNE in parens
        clientName = full.split('\n')[0].trim();
        const fneM = full.match(/(FNE-\d+)/i);
        if (fneM) clientFne = fneM[1].toUpperCase();
      }
    }
  } catch(e) {}

  return { visitId, schedRange, visitRange, clockIn, clockOut, missedType,
           caregiverName, caregiverId, clientName, clientFne, patientId,
           dateStr, schedHrs, confirmedHrs, el: block };
}

function parseHHMM(str) {
  // "16:00" => 16.0 hours
  if (!str) return null;
  const m = str.match(/(\d+):(\d+)/);
  if (!m) return null;
  return parseInt(m[1]) + parseInt(m[2]) / 60;
}

function scanPatientGrid(grid) {
  const overlaps = [];
  const hourDiffs = [];
  const OVERLAP_THRESHOLD_MINS = 8;
  const HOUR_DIFF_THRESHOLD_MINS = 8;

  // Remove any old highlights from previous scan
  grid.querySelectorAll('.cg-visit-item').forEach(b => {
    b.style.removeProperty('outline');
    b.style.removeProperty('background');
  });

  const blocks = Array.from(grid.querySelectorAll('.cg-visit-item'));
  const totalVisits = blocks.length;
  if (totalVisits === 0) return { overlaps, hourDiffs, totalVisits };

  // In the Patient view, each row = one patient.
  // Each day cell = div.cg-calendar-cell[data-date-value].
  // Overlaps happen when the SAME caregiver appears in two different patients' cells
  // for the SAME date with overlapping times.
  //
  // Group key = caregiverKey + "_" + dateStr
  // That way: SALIH on 4/27 is separate from SALIH on 4/28 → no false positives.

  const caregiverDayMap = {};
  const patientDayMap = {};   // member + date → visits (to catch one member double-staffed)

  blocks.forEach(block => {
    const data = extractVisitData(block);

    // ── Hour diff check (sched vs confirmed, ignore C:00:00 = not yet confirmed) ──
    if (data.schedHrs !== null && data.confirmedHrs !== null && data.confirmedHrs > 0) {
      const diffMins = Math.abs(data.schedHrs - data.confirmedHrs) * 60;
      if (diffMins >= HOUR_DIFF_THRESHOLD_MINS) {
        hourDiffs.push({
          client:    data.clientName || 'Unknown',
          caregiver: data.caregiverName || 'Unknown',
          date:      data.dateStr || '',
          schedHrs:  data.schedHrs.toFixed(2),
          visitHrs:  data.confirmedHrs.toFixed(2),
          diffMins:  Math.round(diffMins),
          over:      data.confirmedHrs > data.schedHrs,
          el:        block
        });
        if (diffMins >= 15) {
          try {
            // Purple: clock-in matches but clock-out differs >15 min
            // Green: time window shifted but total hours match within 15 min
            // Yellow: both in+out differ
            let highlightColor = null;
            if (data.schedRange && data.visitRange) {
              const si = parseRangeToInterval(data.schedRange);
              const vi = parseRangeToInterval(data.visitRange);
              if (si && vi) {
                const inDiffMins = Math.abs(si.start - vi.start);
                const outDiffMins = Math.abs(si.end - vi.end);
                const schedDurMins = si.end - si.start;
                const visitDurMins = vi.end - vi.start;
                const durDiffMins = Math.abs(schedDurMins - visitDurMins);
                if (durDiffMins <= 15) {
                  // Hours match within 15 min — green (time shifted)
                  highlightColor = 'green';
                } else if (inDiffMins <= 15 && outDiffMins > 15) {
                  // Clock-in matches, clock-out off — purple
                  highlightColor = 'yellow';  // purple retired — folded into yellow
                } else {
                  highlightColor = 'yellow';
                }
              } else {
                highlightColor = 'yellow';
              }
            } else {
              highlightColor = 'yellow';
            }
            if (highlightColor === 'purple') {
              block.style.outline = '2px solid #ce93d8';
              block.style.background = 'rgba(206,147,216,0.18)';
            } else if (highlightColor === 'green') {
              block.style.outline = '2px solid #66bb6a';
              block.style.background = 'rgba(102,187,106,0.18)';
            } else {
              block.style.outline = '2px solid #ffd600';
              block.style.background = 'rgba(255,214,0,0.18)';
            }
          } catch(e) {}
        }
      }
    }

    // ── Overlap map: caregiver + date → list of visits ────────────
    // Only group if we have a real caregiver name, a scheduled time, and a date.
    if (data.caregiverName && data.schedRange && data.dateStr) {
      const schedInterval = parseRangeToInterval(data.schedRange);
      if (schedInterval) {
        // ── KEY RULE: clamp actual EVV time to the scheduled window.
        // If a DCW clocks in early (before schedule start) or out late (after schedule end),
        // those outside-schedule minutes must NOT count toward overlap detection —
        // they would create false overlaps against a neighbouring visit and block billing.
        // Effective interval = intersection of EVV time with scheduled window.
        // If no EVV times yet (unconfirmed visit) → use scheduled window as-is.
        let effStart = schedInterval.start;
        let effEnd   = schedInterval.end;
        if (data.visitRange) {
          const evvInterval = parseRangeToInterval(data.visitRange);
          if (evvInterval) {
            const clampedStart = Math.max(evvInterval.start, schedInterval.start);
            const clampedEnd   = Math.min(evvInterval.end,   schedInterval.end);
            // Only use clamped interval if it's valid (DCW worked inside schedule)
            if (clampedEnd > clampedStart) {
              effStart = clampedStart;
              effEnd   = clampedEnd;
            }
            // If clamped interval is empty (DCW only worked entirely outside schedule)
            // fall back to schedule window — still need to check for double-booking
          }
        }

        const cgKey  = data.caregiverId
          ? 'id_' + data.caregiverId
          : data.caregiverName.toLowerCase().replace(/\W+/g, '');
        const mapKey = cgKey + '_' + data.dateStr.replace(/\W+/g, '');
        if (!caregiverDayMap[mapKey]) caregiverDayMap[mapKey] = [];
        caregiverDayMap[mapKey].push({
          ...data,
          start: effStart,
          end:   effEnd
        });
      }
    }

    // ── Member double-staff map: same member + date → visits ──────
    // Catches ONE member scheduled with two different caregivers at
    // overlapping times (double-booked patient). Uses scheduled window.
    if ((data.patientId || data.clientName) && data.schedRange && data.dateStr) {
      const psi = parseRangeToInterval(data.schedRange);
      if (psi) {
        const pKey = String(data.patientId || data.clientName).replace(/\W+/g, '') + '_' + data.dateStr.replace(/\W+/g, '');
        if (!patientDayMap[pKey]) patientDayMap[pKey] = [];
        patientDayMap[pKey].push({ ...data, start: psi.start, end: psi.end });
      }
    }
  });

  // ── Detect overlaps: same caregiver, same date, effective intervals overlap ≥8 min ──
  Object.values(caregiverDayMap).forEach(visits => {
    if (visits.length < 2) return;
    for (let i = 0; i < visits.length; i++) {
      for (let j = i + 1; j < visits.length; j++) {
        const a = visits[i], b = visits[j];
        const overlapStart = Math.max(a.start, b.start);
        const overlapEnd   = Math.min(a.end,   b.end);
        const overlapMins  = overlapEnd - overlapStart;
        if (overlapMins >= OVERLAP_THRESHOLD_MINS) {
          overlaps.push({
            caregiver:   a.caregiverName,
            date:        a.dateStr || b.dateStr || '',
            client1:     a.clientName || 'Unknown',
            time1:       a.schedRange,
            visit1:      a.visitRange || null,
            client2:     b.clientName || 'Unknown',
            time2:       b.schedRange,
            visit2:      b.visitRange || null,
            overlapMins,
            elA: a.el, elB: b.el
          });
          try { a.el.style.outline = '2px solid #ff4444'; a.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
          try { b.el.style.outline = '2px solid #ff4444'; b.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
        }
      }
    }
  });

  // ── Detect member double-staffing: same member, same date, TWO different caregivers overlapping ──
  Object.values(patientDayMap).forEach(visits => {
    if (visits.length < 2) return;
    for (let i = 0; i < visits.length; i++) {
      for (let j = i + 1; j < visits.length; j++) {
        const a = visits[i], b = visits[j];
        // Only a conflict if two DIFFERENT caregivers (same caregiver = split/continuous shift, not a double-book)
        const sameCg = (a.caregiverId && b.caregiverId) ? a.caregiverId === b.caregiverId
          : (a.caregiverName || '').toLowerCase() === (b.caregiverName || '').toLowerCase();
        if (sameCg) continue;
        const overlapStart = Math.max(a.start, b.start);
        const overlapEnd   = Math.min(a.end,   b.end);
        const overlapMins  = overlapEnd - overlapStart;
        if (overlapMins >= OVERLAP_THRESHOLD_MINS) {
          overlaps.push({
            memberConflict: true,
            caregiver:  '👥 ' + (a.clientName || 'Member') + ' (2 caregivers)',
            date:       a.dateStr || b.dateStr || '',
            client1:    'CG: ' + (a.caregiverName || 'Unknown'),
            time1:      a.schedRange,
            visit1:     a.visitRange || null,
            client2:    'CG: ' + (b.caregiverName || 'Unknown'),
            time2:      b.schedRange,
            visit2:     b.visitRange || null,
            overlapMins,
            elA: a.el, elB: b.el
          });
          // Member double-staffing is an overlap too — same red as caregiver overlaps
          try { a.el.style.outline = '2px solid #ff4444'; a.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
          try { b.el.style.outline = '2px solid #ff4444'; b.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
        }
      }
    }
  });

  return { overlaps, hourDiffs, totalVisits };
}

function extractCaregiverVisitData(block) {
  // In the Caregiver view:
  //   div.cg-row-container[data-row-id="4660344"]
  //     div.cg-info-cell
  //       div.cg-caregiver-cell[data-caregiver-id="4660344"]
  //         a.cg-caregiver-name => "ACHARYA, DURGA\n(FNE-1639)"
  //     div[data-date-value="4/26/2026"].cg-calendar-cell
  //       div.cg-visit-cell
  //         div.cg-visit-item
  //           a[data-event-type="visit"] => "S:0630 - 1800 (PCA)"
  //           span.cg-visit-span
  //             span.cg-visit-evv => "0633"
  //             span.cg-visit-evv => "1803"
  //           div.cg-text-ellipsis[data-patient-id]
  //             span.cg-text-link => "ACHARYA, DIL"

  const visitId = block.getAttribute('data-visit-id') || '';

  // ── Scheduled time ──
  let schedRange = null;
  const schedLink = block.querySelector('a[data-event-type="visit"]');
  if (schedLink) {
    const txt = schedLink.textContent.trim();
    const m = txt.match(/S:\s*(\d{3,4})\s*[-–]\s*(\d{3,4})/i);
    if (m) schedRange = m[1] + '-' + m[2];
  }

  // ── Actual visit time from .cg-visit-evv spans ──
  let visitRange = null;
  const visitSpan = block.querySelector('.cg-visit-span');
  if (visitSpan) {
    const evvSpans = visitSpan.querySelectorAll('.cg-visit-evv');
    if (evvSpans.length >= 2) {
      const t1 = evvSpans[0].textContent.trim();
      const t2 = evvSpans[1].textContent.trim();
      if (t1 && t2) visitRange = t1 + '-' + t2;
    }
  }

  // ── Date from parent cg-calendar-cell ──
  let dateStr = null;
  try {
    const calCell = block.closest('[data-date-value]');
    if (calCell) dateStr = calCell.getAttribute('data-date-value');
  } catch(e) {}

  // ── Caregiver identity from cg-row-container ──
  let caregiverName = null;
  let caregiverId = null;
  try {
    const rowContainer = block.closest('.cg-row-container');
    if (rowContainer) {
      caregiverId = rowContainer.getAttribute('data-row-id');
      const cgCell = rowContainer.querySelector('.cg-caregiver-cell, .cg-caregiver-name');
      if (cgCell) {
        caregiverName = cgCell.textContent.trim().split('\n')[0].trim();
      }
    }
  } catch(e) {}

  // ── Client name from cg-text-ellipsis[data-patient-id] ──
  let clientName = null;
  try {
    const patientDiv = block.querySelector('[data-patient-id]');
    if (patientDiv) {
      const nameLink = patientDiv.querySelector('.cg-text-link, span');
      if (nameLink) clientName = nameLink.textContent.trim();
    }
  } catch(e) {}

  // ── Hours from S: and V: times directly ──
  const schedHrs = schedRange ? parseVisitHours(schedRange) : null;
  const visitHrs = visitRange ? parseVisitHours(visitRange) : null;

  return { visitId, schedRange, visitRange, caregiverName, caregiverId, clientName, dateStr, schedHrs, visitHrs, el: block };
}

function scanCaregiverGrid(grid) {
  const overlaps = [];
  const hourDiffs = [];
  const OVERLAP_THRESHOLD_MINS = 8;
  const HOUR_DIFF_THRESHOLD_MINS = 8;

  // Remove any old highlights
  grid.querySelectorAll('.cg-visit-item').forEach(b => {
    b.style.removeProperty('outline');
    b.style.removeProperty('background');
  });

  const blocks = Array.from(grid.querySelectorAll('.cg-visit-item'));
  const totalVisits = blocks.length;
  if (totalVisits === 0) return { overlaps, hourDiffs, totalVisits };

  // In Caregiver view: each row = one caregiver.
  // Group by caregiver ID + date to detect overlaps (2 visits same day same caregiver).
  // Also check S: vs V: time differences.

  const caregiverDayMap = {};

  blocks.forEach(block => {
    const data = extractCaregiverVisitData(block);

    // ── Hour diff: compare S: time vs V: time ──
    if (data.schedHrs !== null && data.visitHrs !== null && data.visitRange) {
      const diffMins = Math.abs((data.schedHrs - data.visitHrs) * 60);
      if (diffMins >= HOUR_DIFF_THRESHOLD_MINS) {
        hourDiffs.push({
          caregiver: data.caregiverName || 'Unknown',
          client:    data.clientName || 'Unknown',
          date:      data.dateStr || '',
          schedHrs:  data.schedHrs.toFixed(2),
          visitHrs:  data.visitHrs.toFixed(2),
          diffMins:  Math.round(diffMins),
          over:      data.visitHrs > data.schedHrs,
          el:        block
        });
        // Yellow highlight for 15min+ diff
        if (diffMins >= 15) {
          try {
            let highlightColor = 'yellow';
            if (data.schedRange && data.visitRange) {
              const si = parseRangeToInterval(data.schedRange);
              const vi = parseRangeToInterval(data.visitRange);
              if (si && vi) {
                const inDiffMins = Math.abs(si.start - vi.start);
                const outDiffMins = Math.abs(si.end - vi.end);
                const durDiffMins = Math.abs((si.end - si.start) - (vi.end - vi.start));
                if (durDiffMins <= 15) {
                  highlightColor = 'green';
                } else if (inDiffMins <= 15 && outDiffMins > 15) {
                  highlightColor = 'yellow';  // purple retired — folded into yellow
                }
              }
            }
            if (highlightColor === 'purple') {
              block.style.outline = '2px solid #ce93d8';
              block.style.background = 'rgba(206,147,216,0.18)';
            } else if (highlightColor === 'green') {
              block.style.outline = '2px solid #66bb6a';
              block.style.background = 'rgba(102,187,106,0.18)';
            } else {
              block.style.outline = '2px solid #ffd600';
              block.style.background = 'rgba(255,214,0,0.18)';
            }
          } catch(e) {}
        }
      }
    }

    // ── Overlap map: same caregiver + same date → check if times collide ──
    if (data.caregiverId && data.schedRange && data.dateStr) {
      const schedInterval = parseRangeToInterval(data.schedRange);
      if (schedInterval) {
        // Clamp EVV times to scheduled window so overtime doesn't create false overlaps
        let effStart = schedInterval.start;
        let effEnd   = schedInterval.end;
        if (data.visitRange) {
          const evvInterval = parseRangeToInterval(data.visitRange);
          if (evvInterval) {
            const clampedStart = Math.max(evvInterval.start, schedInterval.start);
            const clampedEnd   = Math.min(evvInterval.end,   schedInterval.end);
            // Only use clamped interval if it's valid (DCW worked inside schedule)
            if (clampedEnd > clampedStart) {
              effStart = clampedStart;
              effEnd   = clampedEnd;
            }
            // If clamped interval is empty (DCW only worked entirely outside schedule)
            // fall back to schedule window — still need to check for double-booking
          }
        }
        const mapKey = 'id_' + data.caregiverId + '_' + data.dateStr.replace(/\W+/g, '');
        if (!caregiverDayMap[mapKey]) caregiverDayMap[mapKey] = [];
        caregiverDayMap[mapKey].push({ ...data, start: effStart, end: effEnd });
      }
    }
  });

  Object.values(caregiverDayMap).forEach(visits => {
    if (visits.length < 2) return;
    for (let i = 0; i < visits.length; i++) {
      for (let j = i + 1; j < visits.length; j++) {
        const a = visits[i], b = visits[j];
        const overlapStart = Math.max(a.start, b.start);
        const overlapEnd   = Math.min(a.end,   b.end);
        const overlapMins  = overlapEnd - overlapStart;
        if (overlapMins >= OVERLAP_THRESHOLD_MINS) {
          overlaps.push({
            caregiver:   a.caregiverName || 'Unknown',
            date:        a.dateStr || '',
            client1:     a.clientName || a.schedRange || 'Visit 1',
            time1:       a.schedRange,
            visit1:      a.visitRange || null,
            client2:     b.clientName || b.schedRange || 'Visit 2',
            time2:       b.schedRange,
            visit2:      b.visitRange || null,
            overlapMins,
            elA: a.el, elB: b.el
          });
          try { a.el.style.outline = '2px solid #ff4444'; a.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
          try { b.el.style.outline = '2px solid #ff4444'; b.el.style.background = 'rgba(255,68,68,0.15)'; } catch(e) {}
        }
      }
    }
  });

  return { overlaps, hourDiffs, totalVisits };
}

// Maps a panel card's dismiss-key -> the visit block on the calendar, so
// clicking a card can scroll straight to the schedule that needs fixing.
const ccJumpMap = Object.create(null);

function ccJumpToVisit(el) {
  if (!el || !document.contains(el)) return false;
  try {
    el.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    const prevOutline = el.style.outline;
    const prevShadow  = el.style.boxShadow;
    let n = 0;
    const flash = setInterval(() => {
      el.style.setProperty('outline', n % 2 ? '4px solid #00e5ff' : '2px solid #ff4444', 'important');
      el.style.setProperty('box-shadow', n % 2 ? '0 0 16px 4px rgba(0,229,255,0.9)' : 'none', 'important');
      if (++n >= 6) {
        clearInterval(flash);
        el.style.outline = prevOutline;
        el.style.boxShadow = prevShadow;
      }
    }, 180);
  } catch (e) { return false; }
  return true;
}

function injectApptPanel({ overlaps, hourDiffs, totalVisits, authUsage, panelId, title }) {
  authUsage = authUsage || [];
  const AUTH_USAGE_MIN_GAP = 15; // minutes — ignore trivial gaps
  const overAuthList  = authUsage.filter(a => a.diff >=  AUTH_USAGE_MIN_GAP).sort((a, b) => b.diff - a.diff);
  const underAuthList = authUsage.filter(a => a.diff <= -AUTH_USAGE_MIN_GAP).sort((a, b) => a.diff - b.diff);
  panelId = panelId || 'cc-appt-panel';
  title   = title   || '⚕ Care Crafter — Schedule Scan';

  // Filter out dismissed items
  const visibleOverlaps = overlaps.filter(o => !isDismissed(makeDismissKey('ov', o.caregiver, o.date, o.client1, o.client2)));
  const allDiffs        = hourDiffs.filter(d => !isDismissed(makeDismissKey('df', d.caregiver, d.date, d.client||d.patient)));

  // ── Panel state (filter + sort + pagination) ──────────────────
  const PAGE_SIZE = 25;
  let filterDir   = 'all';   // 'all' | 'over' | 'under'
  let filterMins  = 0;       // minimum diffMins threshold
  let sortDir     = 'none';  // 'none' | 'asc' | 'desc'
  let diffPage    = 1;       // how many pages loaded so far
  let showOverAuth  = localStorage.getItem('_cc_show_over_auth')  !== 'false'; // default on
  let showUnderAuth = localStorage.getItem('_cc_show_under_auth') !== 'false'; // default on

  function getFilteredSorted() {
    let list = allDiffs.slice();
    if (filterDir === 'over')  list = list.filter(d => d.over);
    if (filterDir === 'under') list = list.filter(d => !d.over);
    if (filterMins > 0)        list = list.filter(d => d.diffMins >= filterMins);
    if (sortDir === 'asc')     list.sort((a, b) => a.diffMins - b.diffMins);
    if (sortDir === 'desc')    list.sort((a, b) => b.diffMins - a.diffMins);
    return list;
  }

  // ── Build panel shell ─────────────────────────────────────────
  const panel = document.createElement('div');
  panel.id = panelId;

  const savedSize = JSON.parse(localStorage.getItem('_cc_panel_size') || 'null');
  const savedW = savedSize ? savedSize.w : 380;
  const savedH = savedSize ? savedSize.h : null;

  panel.style.cssText = `
    position:fixed;top:60px;right:16px;width:${savedW}px;min-width:280px;min-height:120px;max-height:82vh;
    background:#1a1a2e;color:#e0e0e0;border-radius:10px;
    box-shadow:0 4px 24px rgba(0,0,0,0.6);z-index:999999;
    font-family:'Segoe UI',monospace;font-size:12px;overflow:hidden;
    border:1px solid #334;resize:both;
    ${savedH ? `height:${savedH}px;` : ''}
  `;

  const hasIssues = visibleOverlaps.length > 0 || allDiffs.length > 0 || overAuthList.length > 0 || underAuthList.length > 0;

  // ── Header ────────────────────────────────────────────────────
  panel.innerHTML = `
    <div id="${panelId}-header" style="background:linear-gradient(135deg,#0f3460,#16213e);
      padding:11px 14px;display:flex;justify-content:space-between;align-items:center;
      border-radius:10px 10px 0 0;cursor:pointer;user-select:none;">
      <span style="font-weight:bold;font-size:13px;letter-spacing:.3px;">${title}</span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="${panelId}-minimize" style="font-size:11px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="${panelId}-close"    style="cursor:pointer;font-size:16px;color:#aaa;">✕</span>
      </div>
    </div>

    <div id="${panelId}-summary" style="padding:9px 14px;border-bottom:1px solid #2a2a3e;
      display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#16213e;">
      <span style="color:#aaa;">📋 <strong style="color:#e0e0e0;">${totalVisits}</strong> visits</span>
      ${visibleOverlaps.length > 0
        ? `<span style="color:#ff6b6b;font-weight:bold;">🔴 ${visibleOverlaps.length} overlap${visibleOverlaps.length>1?'s':''}</span>`
        : `<span style="color:#51cf66;">✓ No overlaps</span>`}
      ${allDiffs.length > 0
        ? `<span style="color:#ffd43b;font-weight:bold;">⚠ ${allDiffs.length} time diff${allDiffs.length>1?'s':''}</span>`
        : `<span style="color:#51cf66;">✓ Times match</span>`}
      ${window._ccAuthFlag
        ? `<span style="color:#ff8c00;font-weight:bold;">🟠 ${window._ccAuthFlag.label}</span>`
        : ''}
      ${overAuthList.length > 0
        ? `<span id="${panelId}-toggle-over" style="color:#d08a4f;font-weight:bold;cursor:pointer;user-select:none;
             opacity:${showOverAuth ? '1' : '0.4'};" title="Click to show/hide">🟤 ${overAuthList.length} over auth</span>`
        : ''}
      ${underAuthList.length > 0
        ? `<span id="${panelId}-toggle-under" style="color:#64b5f6;font-weight:bold;cursor:pointer;user-select:none;
             opacity:${showUnderAuth ? '1' : '0.4'};" title="Click to show/hide">🔵 ${underAuthList.length} under auth</span>`
        : ''}
      ${ccFixedTotal > 0
        ? `<span id="${panelId}-fixed" style="color:#51cf66;font-weight:bold;background:rgba(81,207,102,0.14);
             border:1px solid #2e7d32;border-radius:10px;padding:1px 9px;">✓ ${ccFixedTotal} fixed</span>`
        : ''}
    </div>

    <div id="${panelId}-body" style="overflow-y:auto;max-height:calc(82vh - 160px);padding:10px 14px;">
      <div id="${panelId}-content"></div>
    </div>

    <div id="${panelId}-footer" style="padding:8px 14px;border-top:1px solid #2a2a3e;background:#16213e;
      display:flex;justify-content:space-between;align-items:center;gap:6px;flex-wrap:wrap;">
      <div style="display:flex;gap:10px;align-items:center;">
        <button id="${panelId}-clear-dismissed" style="background:transparent;border:none;color:#555;font-size:10px;cursor:pointer;padding:0;" title="Show all dismissed items again">↺ Reset dismissed</button>
        <button id="${panelId}-clear-memory" style="background:transparent;border:1px dashed #444;color:#888;font-size:10px;cursor:pointer;padding:2px 7px;border-radius:4px;" title="Wipes all remembered visits from Scan/Import — used by the billing page's blocking check. You'll need to re-scan before the next billability check.">🗑 Clear Memory</button>
      </div>
      <div style="display:flex;gap:6px;">
        <button id="${panelId}-export" style="background:#1a6e3c;color:#e0e0e0;border:1px solid #2a9e5c;
          border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;" title="Export to Excel">📥 Export</button>
        <button id="${panelId}-rescan" style="background:#0f3460;color:#e0e0e0;border:1px solid #334;
          border-radius:5px;padding:4px 12px;font-size:11px;cursor:pointer;">🔄 Rescan</button>
      </div>
    </div>
  `;

  document.body.appendChild(panel);

  // ── Filter / Sort toolbar (injected into body before content) ─
  const body = panel.querySelector(`#${panelId}-body`);

  if (allDiffs.length > 0) {
    const toolbar = document.createElement('div');
    toolbar.id = `${panelId}-toolbar`;
    toolbar.style.cssText = `
      display:flex;flex-wrap:wrap;gap:6px;align-items:center;
      padding:8px 0 10px;border-bottom:1px solid #2a2a3e;margin-bottom:10px;
    `;
    toolbar.innerHTML = `
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Filter:</span>
        <select id="${panelId}-filter-dir" style="background:#0f1824;color:#e0e0e0;border:1px solid #334;
          border-radius:4px;padding:2px 5px;font-size:11px;cursor:pointer;">
          <option value="all">All diffs</option>
          <option value="over">Over only</option>
          <option value="under">Under only</option>
        </select>
      </div>
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Min diff:</span>
        <input id="${panelId}-filter-h" type="number" min="0" max="99" placeholder="h"
          style="width:34px;background:#0f1824;color:#e0e0e0;border:1px solid #334;border-radius:4px;padding:2px 4px;font-size:11px;text-align:center;" />
        <span style="color:#555;font-size:10px;">h</span>
        <input id="${panelId}-filter-m" type="number" min="0" max="59" placeholder="m"
          style="width:34px;background:#0f1824;color:#e0e0e0;border:1px solid #334;border-radius:4px;padding:2px 4px;font-size:11px;text-align:center;" />
        <span style="color:#555;font-size:10px;">m</span>
      </div>
      <div style="display:flex;gap:4px;align-items:center;">
        <span style="color:#aaa;font-size:10px;">Sort:</span>
        <select id="${panelId}-sort" style="background:#0f1824;color:#e0e0e0;border:1px solid #334;
          border-radius:4px;padding:2px 5px;font-size:11px;cursor:pointer;">
          <option value="none">Default</option>
          <option value="asc">Smallest first</option>
          <option value="desc">Largest first</option>
        </select>
      </div>
      <span id="${panelId}-count" style="color:#aaa;font-size:10px;margin-left:auto;"></span>
    `;
    body.insertBefore(toolbar, body.querySelector(`#${panelId}-content`));

    // Wire up toolbar controls
    const dirSel  = toolbar.querySelector(`#${panelId}-filter-dir`);
    const hInput  = toolbar.querySelector(`#${panelId}-filter-h`);
    const mInput  = toolbar.querySelector(`#${panelId}-filter-m`);
    const sortSel = toolbar.querySelector(`#${panelId}-sort`);

    function applyControls() {
      filterDir  = dirSel.value;
      const h    = parseInt(hInput.value) || 0;
      const m    = parseInt(mInput.value) || 0;
      filterMins = h * 60 + m;
      sortDir    = sortSel.value;
      diffPage   = 1;
      renderContent();
    }

    [dirSel, sortSel].forEach(el => el.addEventListener('change', applyControls));
    [hInput, mInput].forEach(el => el.addEventListener('input',  applyControls));
  }

  // ── Render content (overlaps + paginated diffs) ───────────────
  function renderContent() {
    const content    = panel.querySelector(`#${panelId}-content`);
    const countLabel = panel.querySelector(`#${panelId}-count`);
    let html = '';

    // ── No results states ──
    if (!hasIssues && totalVisits > 0) {
      html += `<div style="color:#51cf66;text-align:center;padding:24px 0;">
        <div style="font-size:28px;margin-bottom:8px;">✅</div>
        <div style="font-weight:bold;">All Clear!</div>
        <div style="color:#aaa;font-size:11px;margin-top:4px;">No overlaps or time differences found.</div>
      </div>`;
    }
    if (totalVisits === 0) {
      html += `<div style="color:#aaa;text-align:center;padding:24px 0;">
        <div style="font-size:24px;margin-bottom:8px;">🔍</div>
        <div>Run a search to scan visits.</div>
      </div>`;
    }

    // ── Overlaps ──
    if (visibleOverlaps.length > 0) {
      html += `<div style="color:#ff6b6b;font-weight:bold;margin:4px 0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        🔴 OVERLAPPING SHIFTS
        <span style="background:#ff4444;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;">${visibleOverlaps.length}</span>
      </div>`;

      visibleOverlaps.forEach(o => {
        const dKey = makeDismissKey('ov', o.caregiver, o.date, o.client1, o.client2);
        ccJumpMap[dKey] = o.elA || o.elB;   // click the card -> scroll to the first conflicting visit
        html += `<div class="cc-card" data-dismiss-key="${dKey}" style="background:#2d1b1b;border-left:3px solid #ff4444;
          padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="color:#ff9999;font-weight:bold;font-size:12px;">${o.caregiver||'Unknown Caregiver'}</span>
            <div style="display:flex;gap:6px;align-items:center;">
              <span style="background:#ff4444;color:#fff;font-size:10px;padding:1px 6px;border-radius:8px;">${o.overlapMins} min</span>
              <button class="cc-dismiss-btn" data-key="${dKey}" style="background:#333;border:1px solid #555;color:#aaa;border-radius:4px;padding:1px 7px;font-size:10px;cursor:pointer;" title="Dismiss">✓</button>
            </div>
          </div>
          ${o.date ? `<div style="color:#888;font-size:10px;margin:2px 0;">${o.date}</div>` : ''}
          <div style="margin-top:6px;display:flex;flex-direction:column;gap:3px;">
            <div style="background:#1a0f0f;padding:4px 7px;border-radius:3px;">
              <span style="color:#aaa;font-size:10px;">Client 1: </span>
              <span style="color:#e0e0e0;">${o.client1}</span>
              <span style="color:#888;font-size:10px;margin-left:6px;">S:${o.time1||'N/A'}</span>
              <span style="color:#69f0ae;font-size:10px;margin-left:4px;">V:${o.visit1||'N/A'}</span>
            </div>
            <div style="background:#1a0f0f;padding:4px 7px;border-radius:3px;">
              <span style="color:#aaa;font-size:10px;">Client 2: </span>
              <span style="color:#e0e0e0;">${o.client2}</span>
              <span style="color:#888;font-size:10px;margin-left:6px;">S:${o.time2||'N/A'}</span>
              <span style="color:#69f0ae;font-size:10px;margin-left:4px;">V:${o.visit2||'N/A'}</span>
            </div>
          </div>
        </div>`;
      });
    }

    // ── Over / Under weekly auth usage ──
    if (showOverAuth && overAuthList.length > 0) {
      html += `<div style="color:#d08a4f;font-weight:bold;margin:12px 0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        🟤 OVER WEEKLY AUTH
        <span style="background:#a1662f;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;">${overAuthList.length}</span>
        <span id="${panelId}-hide-over" style="margin-left:auto;cursor:pointer;color:#888;font-size:14px;user-select:none;padding:0 4px;" title="Hide this section">✕</span>
      </div>`;
      overAuthList.forEach(a => {
        html += `<div style="background:#2a1c10;border-left:3px solid #a1662f;padding:7px 10px;margin-bottom:6px;border-radius:5px;">
          <span style="color:#f0c8a0;font-weight:bold;font-size:12px;">${a.member}</span>
          <div style="font-size:11px;color:#aaa;margin-top:2px;">A:${ccFmtHM(a.A)} → S:${ccFmtHM(a.S)}
            <span style="color:#ffb74d;font-weight:bold;">(+${ccFmtHM(a.diff)} over)</span></div>
        </div>`;
      });
    }
    if (showUnderAuth && underAuthList.length > 0) {
      html += `<div style="color:#64b5f6;font-weight:bold;margin:12px 0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        🔵 UNDER WEEKLY AUTH
        <span style="background:#1565c0;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;">${underAuthList.length}</span>
        <span id="${panelId}-hide-under" style="margin-left:auto;cursor:pointer;color:#888;font-size:14px;user-select:none;padding:0 4px;" title="Hide this section">✕</span>
      </div>`;
      underAuthList.forEach(a => {
        html += `<div style="background:#10202a;border-left:3px solid #1565c0;padding:7px 10px;margin-bottom:6px;border-radius:5px;">
          <span style="color:#a8d4f5;font-weight:bold;font-size:12px;">${a.member}</span>
          <div style="font-size:11px;color:#aaa;margin-top:2px;">A:${ccFmtHM(a.A)} → S:${ccFmtHM(a.S)}
            <span style="color:#64b5f6;font-weight:bold;">(${ccFmtHM(Math.abs(a.diff))} unused)</span></div>
        </div>`;
      });
    }

    // ── Time differences (filtered + sorted + paginated) ──
    const filtered = getFilteredSorted();
    const sliced   = filtered.slice(0, diffPage * PAGE_SIZE);
    const hasMore  = sliced.length < filtered.length;

    if (countLabel) countLabel.textContent = filtered.length + ' shown';

    if (filtered.length > 0) {
      html += `<div style="color:#ffd43b;font-weight:bold;margin:${visibleOverlaps.length>0?'12px':''}0 8px;font-size:12px;
        display:flex;align-items:center;gap:6px;">
        ⚠ TIME DIFFERENCES
        <span style="background:#e6a817;color:#1a1a00;border-radius:10px;padding:1px 7px;font-size:10px;">${filtered.length}</span>
      </div>`;

      sliced.forEach(d => {
        const diffColor = d.over ? '#ff9999' : '#ffd43b';
        const arrow     = d.over ? '↑ Over' : '↓ Under';
        const dKey      = makeDismissKey('df', d.caregiver, d.date, d.client||d.patient);
        ccJumpMap[dKey] = d.el;   // click the card -> scroll to this visit on the calendar
        const h = Math.floor(d.diffMins / 60);
        const m = d.diffMins % 60;
        const diffLabel = h > 0 ? `${h}h ${m}m` : `${m}m`;
        html += `<div class="cc-card" data-dismiss-key="${dKey}" style="background:#2a2410;border-left:3px solid #ffd43b;
          padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;">
            <span style="color:#ffd493;font-weight:bold;font-size:12px;">${d.caregiver||'Unknown'}</span>
            <div style="display:flex;gap:6px;align-items:center;">
              <span style="color:${diffColor};font-size:10px;font-weight:bold;">${arrow} ${diffLabel}</span>
              <button class="cc-dismiss-btn" data-key="${dKey}" style="background:#333;border:1px solid #555;color:#aaa;border-radius:4px;padding:1px 7px;font-size:10px;cursor:pointer;" title="Dismiss">✓</button>
            </div>
          </div>
          <div style="color:#888;font-size:10px;margin:2px 0;">
            ${d.client||d.patient||''}${d.date ? ' — ' + d.date : ''}
          </div>
          <div style="margin-top:6px;display:flex;gap:8px;">
            <div style="background:#1a1600;padding:4px 8px;border-radius:3px;flex:1;text-align:center;">
              <div style="color:#aaa;font-size:9px;">SCHEDULED</div>
              <div style="color:#e0e0e0;font-weight:bold;">${d.schedHrs}h</div>
            </div>
            <div style="background:#1a1600;padding:4px 8px;border-radius:3px;flex:1;text-align:center;">
              <div style="color:#aaa;font-size:9px;">ACTUAL</div>
              <div style="color:${diffColor};font-weight:bold;">${d.visitHrs}h</div>
            </div>
          </div>
        </div>`;
      });

      if (hasMore) {
        html += `<div id="${panelId}-load-more" style="text-align:center;padding:10px 0 4px;">
          <button style="background:#0f3460;color:#aaa;border:1px solid #334;border-radius:5px;
            padding:5px 18px;font-size:11px;cursor:pointer;">
            ↓ Load more (${filtered.length - sliced.length} remaining)
          </button>
        </div>`;
      }
    } else if (allDiffs.length > 0) {
      html += `<div style="color:#aaa;text-align:center;padding:16px 0;font-size:11px;">
        No time differences match the current filter.
      </div>`;
    }

    content.innerHTML = html;

    // Wire up the ✕ hide buttons on the Over/Under Auth section headers
    const hideOverBtn = content.querySelector(`#${panelId}-hide-over`);
    if (hideOverBtn) hideOverBtn.addEventListener('click', () => {
      showOverAuth = false;
      localStorage.setItem('_cc_show_over_auth', 'false');
      renderContent();
    });
    const hideUnderBtn = content.querySelector(`#${panelId}-hide-under`);
    if (hideUnderBtn) hideUnderBtn.addEventListener('click', () => {
      showUnderAuth = false;
      localStorage.setItem('_cc_show_under_auth', 'false');
      renderContent();
    });

    // Wire up dismiss buttons
    content.querySelectorAll('.cc-dismiss-btn').forEach(btn => {
      btn.addEventListener('click', e => {
        e.stopPropagation();
        dismissCard(btn.getAttribute('data-key'));
        const card = btn.closest('.cc-card');
        if (card) { card.style.transition='opacity 0.2s'; card.style.opacity='0'; setTimeout(()=>card.remove(),200); }
      });
    });

    // Click a card -> scroll the calendar to that visit and flash it
    content.querySelectorAll('.cc-card').forEach(card => {
      const key = card.getAttribute('data-dismiss-key');
      const target = ccJumpMap[key];
      if (!target) return;
      card.style.cursor = 'pointer';
      card.title = 'Click to jump to this visit on the calendar';
      card.addEventListener('click', e => {
        if (e.target.closest('.cc-dismiss-btn')) return;  // ✓ button keeps dismissing
        ccJumpToVisit(target);
      });
    });

    // Load more button
    const loadMoreBtn = content.querySelector(`#${panelId}-load-more button`);
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', () => { diffPage++; renderContent(); });
    }

    // Infinite scroll — load more when near bottom
    body.onscroll = () => {
      if (body.scrollTop + body.clientHeight >= body.scrollHeight - 80 && hasMore) {
        diffPage++;
        renderContent();
      }
    };
  }

  renderContent();

  // Resize observer
  const ro = new ResizeObserver(() => {
    localStorage.setItem('_cc_panel_size', JSON.stringify({ w: panel.offsetWidth, h: panel.offsetHeight }));
  });
  ro.observe(panel);

  // ── Over/Under auth toggles (click the header badge to show/hide) ──
  const toggleOverEl = panel.querySelector(`#${panelId}-toggle-over`);
  if (toggleOverEl) toggleOverEl.addEventListener('click', () => {
    showOverAuth = !showOverAuth;
    localStorage.setItem('_cc_show_over_auth', String(showOverAuth));
    toggleOverEl.style.opacity = showOverAuth ? '1' : '0.4';
    renderContent();
  });
  const toggleUnderEl = panel.querySelector(`#${panelId}-toggle-under`);
  if (toggleUnderEl) toggleUnderEl.addEventListener('click', () => {
    showUnderAuth = !showUnderAuth;
    localStorage.setItem('_cc_show_under_auth', String(showUnderAuth));
    toggleUnderEl.style.opacity = showUnderAuth ? '1' : '0.4';
    renderContent();
  });

  // ── Export to Excel ───────────────────────────────────────────
  panel.querySelector(`#${panelId}-export`).addEventListener('click', () => {
    try {
      const filtered = getFilteredSorted();
      // Build CSV rows
      const rows = [['Caregiver','Client/Patient','Date','Scheduled Hrs','Actual Hrs','Diff Mins','Diff Hrs/Min','Direction']];
      filtered.forEach(d => {
        const h = Math.floor(d.diffMins/60), m = d.diffMins%60;
        rows.push([
          d.caregiver||'',
          d.client||d.patient||'',
          d.date||'',
          d.schedHrs||'',
          d.visitHrs||'',
          d.diffMins,
          h>0?`${h}h ${m}m`:`${m}m`,
          d.over?'Over':'Under'
        ]);
      });
      // Also add overlaps sheet
      const ovRows = [['Caregiver','Date','Client 1','Sched 1','Visit 1','Client 2','Sched 2','Visit 2','Overlap Mins']];
      visibleOverlaps.forEach(o => {
        ovRows.push([o.caregiver||'',o.date||'',o.client1||'',o.time1||'',o.visit1||'',o.client2||'',o.time2||'',o.visit2||'',o.overlapMins]);
      });

      // Use SheetJS if available, else fall back to CSV download
      if (typeof XLSX !== 'undefined') {
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(rows),   'Time Diffs');
        XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(ovRows), 'Overlaps');
        XLSX.writeFile(wb, 'CareCrafter_Scan_' + new Date().toISOString().slice(0,10) + '.xlsx');
      } else {
        // CSV fallback
        const allRows = [['TYPE','CAREGIVER','CLIENT','DATE','SCHED HRS','ACTUAL HRS','DIFF MINS','DIRECTION']];
        filtered.forEach(d => allRows.push(['TimeDiff', d.caregiver||'', d.client||d.patient||'', d.date||'', d.schedHrs||'', d.visitHrs||'', d.diffMins, d.over?'Over':'Under']));
        visibleOverlaps.forEach(o => allRows.push(['Overlap', o.caregiver||'', o.client1+'/'+o.client2, o.date||'', '','','',o.overlapMins+' min overlap']));
        const csv = allRows.map(r => r.map(v => `"${String(v).replace(/"/g,'""')}"`).join(',')).join('\n');
        const a = document.createElement('a');
        a.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
        a.download = 'CareCrafter_Scan_' + new Date().toISOString().slice(0,10) + '.csv';
        a.click();
      }
    } catch(e) { alert('Export error: ' + e.message); }
  });

  // ── Standard controls ──────────────────────────────────────────
  panel.querySelector(`#${panelId}-clear-dismissed`).addEventListener('click', () => {
    clearDismissed(); panel.remove();
    if (panelId === 'cc-appt-panel') runAppointmentsOverlapScan();
    else if (panelId === 'cc-vm-panel') runVisitMaintenanceScan(true);
  });

  const clearMemBtn = panel.querySelector(`#${panelId}-clear-memory`);
  if (clearMemBtn) clearMemBtn.addEventListener('click', () => {
    if (!confirm('Clear all remembered visits (from Scan/Import)? You\'ll need to re-scan before the next billability check.')) return;
    chrome.storage.local.remove(['_cc_billing_memory']);
  });

  panel.querySelector(`#${panelId}-close`).addEventListener('click', () => panel.remove());

  let minimized = false;
  panel.querySelector(`#${panelId}-minimize`).addEventListener('click', e => {
    e.stopPropagation();
    minimized = !minimized;
    const bodyEl   = panel.querySelector(`#${panelId}-body`);
    const summary  = panel.querySelector(`#${panelId}-summary`);
    const footer   = panel.querySelector(`#${panelId}-footer`);
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      [bodyEl, summary, footer].forEach(el => { if(el){el.style.overflow='hidden';el.style.height='0';el.style.padding='0';el.style.margin='0';}});
      panel.style.height='auto'; panel.style.maxHeight='none'; panel.style.minHeight='0'; panel.style.resize='none';
    } else {
      [bodyEl, summary, footer].forEach(el => { if(el){el.style.overflow='';el.style.height='';el.style.padding='';el.style.margin='';}});
      panel.style.height=panel.dataset.fullH||''; panel.style.maxHeight='82vh'; panel.style.minHeight='120px'; panel.style.resize='both';
    }
    panel.querySelector(`#${panelId}-minimize`).textContent = minimized ? '□' : '─';
  });

  panel.querySelector(`#${panelId}-rescan`).addEventListener('click', () => {
    panel.remove();
    if (panelId === 'cc-appt-panel') runAppointmentsOverlapScan();
    else if (panelId === 'cc-vm-panel') runVisitMaintenanceScan(true);
  });

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector(`#${panelId}-header`);
  header.addEventListener('mousedown', e => {
    if (e.target.id === `${panelId}-close` || e.target.id === `${panelId}-minimize`) return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top  = (e.clientY - dragY) + 'px';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });
}


// ─── MASTER WEEK SCANNER ─────────────────────────────────────────

function initMasterWeekScanner() {
  // If masterchild blocks already exist, scan immediately
  if (document.querySelectorAll('.masterchild').length > 0) {
    runMasterWeekScan();
    return;
  }
  // Otherwise watch for them to load
  const obs = new MutationObserver(() => {
    if (document.querySelectorAll('.masterchild').length > 0) {
      obs.disconnect();
      clearTimeout(window._ccMWScanTimer);
      window._ccMWScanTimer = setTimeout(runMasterWeekScan, 800);
    }
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

function parseMasterWeekTime(rangeStr) {
  // "0600-1800" => { start: 360, end: 1080, hours: 12.0 }
  if (!rangeStr) return null;
  const m = rangeStr.replace(/\s/g, '').match(/^(\d{3,4})[-\u2013](\d{3,4})$/);
  if (!m) return null;
  const start = timeToMinutes(m[1]);
  const end   = timeToMinutes(m[2]);
  if (start === null || end === null) return null;
  let diff = end - start;
  if (diff < 0) diff += 1440;
  return { start, end: end < start ? end + 1440 : end, hours: Math.round((diff / 60) * 100) / 100 };
}

function runMasterWeekScan() {
  const existing = document.getElementById('cc-mw-panel');
  if (existing) existing.remove();

  const DAY_ORDER = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];

  // Each .masterchild is one shift block (may share patient with others)
  const masterChildren = Array.from(document.querySelectorAll('.masterchild'));
  if (masterChildren.length === 0) return;

  // DCW map: key = "Name (ID)" => { days: { Mon: hours, Tue: hours, ... }, shifts: [] }
  const dcwMap = {};
  const overlapList = [];

  // Also track all shifts per day for overlap detection
  // shiftsByDay: { Mon: [{dcw, start, end, hours}], ... }
  const shiftsByDay = {};
  DAY_ORDER.forEach(d => shiftsByDay[d] = []);

  masterChildren.forEach(child => {
    // Find the table inside this masterchild
    const table = child.querySelector('table');
    if (!table) return;

    const rows = Array.from(table.querySelectorAll('tr'));
    if (rows.length < 2) return;

    // Find column headers (day names) from first row
    const headerCells = Array.from(rows[0].querySelectorAll('th, td'));
    const dayColMap = {}; // colIndex => dayName
    headerCells.forEach((cell, idx) => {
      const txt = cell.innerText.trim();
      const dayMatch = DAY_ORDER.find(d => txt.startsWith(d));
      if (dayMatch) dayColMap[idx] = dayMatch;
    });

    // Find the Hours row and Caregiver row
    let hoursRowData = null;   // { colIndex: timeRange }
    let caregiverData = null;  // { name, id }

    rows.forEach(row => {
      const cells = Array.from(row.querySelectorAll('th, td'));
      const firstTxt = (cells[0] ? cells[0].innerText.trim() : '');

      if (/^hours?$/i.test(firstTxt)) {
        // Hours row: each day column has a time range like "0600-1800"
        hoursRowData = {};
        cells.forEach((cell, idx) => {
          if (dayColMap[idx]) {
            const noData = cell.querySelector('.no-data');
            if (!noData) {
              const timeStr = cell.innerText.trim().replace(/\s+/g, '');
              if (/^\d{3,4}-\d{3,4}$/.test(timeStr)) {
                hoursRowData[dayColMap[idx]] = timeStr;
              }
            }
          }
        });
      }

      if (/^caregiver$/i.test(firstTxt)) {
        // Caregiver row: name is repeated in each ACTIVE day column.
        // Example: cells[0] = "Caregiver" (label), cells[dayColIdx] = "ACHARYA ISHORI, FNE-1640"
        // WRONG approach: reading cells[0] → gets "Caregiver" (the label)
        // CORRECT approach: read the day column cells and take first non-empty one
        cells.forEach((cell, idx) => {
          if (!dayColMap[idx]) return; // only check day columns, not the label column
          if (caregiverData) return;   // already found it
          const noData = cell.querySelector('.no-data');
          if (noData) return;
          const cellTxt = cell.innerText.trim();
          // Must be a real name: has letters, not just "--" or empty
          if (cellTxt && cellTxt !== '--' && /[A-Za-z]/.test(cellTxt)) {
            caregiverData = { name: cellTxt };
          }
        });
      }
    });

    if (!hoursRowData || !caregiverData) return;

    const dcwKey = caregiverData.name;
    if (!dcwMap[dcwKey]) dcwMap[dcwKey] = { days: {}, totalHours: 0 };

    // Register each active day for this DCW
    Object.entries(hoursRowData).forEach(([day, rangeStr]) => {
      const parsed = parseMasterWeekTime(rangeStr);
      if (!parsed) return;

      // Add to DCW map
      if (!dcwMap[dcwKey].days[day]) dcwMap[dcwKey].days[day] = 0;
      dcwMap[dcwKey].days[day] += parsed.hours;
      dcwMap[dcwKey].totalHours = (dcwMap[dcwKey].totalHours || 0) + parsed.hours;

      // Track for overlap detection
      shiftsByDay[day].push({ dcw: dcwKey, start: parsed.start, end: parsed.end, hours: parsed.hours, rangeStr });
    });
  });

  // Detect overlaps within each day
  let totalOverlaps = 0;
  DAY_ORDER.forEach(day => {
    const shifts = shiftsByDay[day];
    if (shifts.length < 2) return;
    for (let i = 0; i < shifts.length; i++) {
      for (let j = i + 1; j < shifts.length; j++) {
        const a = shifts[i], b = shifts[j];
        if (a.dcw === b.dcw) continue;
        const oStart = Math.max(a.start, b.start);
        const oEnd   = Math.min(a.end, b.end);
        const oMins  = oEnd - oStart;
        if (oMins >= 8) {
          totalOverlaps++;
          overlapList.push({
            day,
            dcw1: a.dcw, range1: a.rangeStr,
            dcw2: b.dcw, range2: b.rangeStr,
            overlapMins: oMins
          });
        }
      }
    }
  });

  // Agency total hours
  const agencyTotal = Object.values(dcwMap).reduce((sum, d) => sum + (d.totalHours || 0), 0);

  // ── Build floating panel ──
  const panel = document.createElement('div');
  panel.id = 'cc-mw-panel';
  panel.style.cssText = `
    position: fixed; top: 60px; right: 16px; width: 340px; max-height: 85vh;
    background: #1a1a2e; color: #e0e0e0; border-radius: 10px;
    box-shadow: 0 4px 28px rgba(0,0,0,0.7); z-index: 999999;
    font-family: 'Segoe UI', monospace; font-size: 12px; overflow: hidden;
    border: 1px solid #2a2a4a;
  `;

  const dcwEntries = Object.entries(dcwMap);

  let html = `
    <div id="cc-mw-header" style="
      background: linear-gradient(135deg,#0f3460,#16213e);
      padding: 11px 14px; display: flex; justify-content: space-between;
      align-items: center; border-radius: 10px 10px 0 0;
      cursor: pointer; user-select: none;">
      <span style="font-weight:bold;font-size:13px;letter-spacing:.3px;">
        ⚕ Care Crafter — Master Week
      </span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="cc-mw-minimize" style="font-size:14px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="cc-mw-close" style="cursor:pointer;font-size:16px;color:#aaa;">✕</span>
      </div>
    </div>

    <div id="cc-mw-summary" style="
      padding: 9px 14px; border-bottom: 1px solid #2a2a3e;
      display: flex; flex-wrap: wrap; gap: 10px; align-items: center;
      background: #16213e;">
      <span style="color:#aaa;">👥 <strong style="color:#e0e0e0;">${dcwEntries.length}</strong> DCW${dcwEntries.length !== 1 ? 's' : ''}</span>
      <span style="color:#4ade80;font-weight:bold;">⏱ ${agencyTotal.toFixed(1)}h total</span>
      ${totalOverlaps > 0
        ? `<span style="color:#ff6b6b;font-weight:bold;">🔴 ${totalOverlaps} overlap${totalOverlaps !== 1 ? 's' : ''}</span>`
        : `<span style="color:#51cf66;">✓ No overlaps</span>`}
    </div>

    <div id="cc-mw-body" style="overflow-y:auto;max-height:calc(85vh - 120px);padding:10px 14px;">
  `;

  // ── Agency total box at top ──
  html += `
    <div style="
      background: linear-gradient(135deg,#0d4f3c,#1b5e20);
      border-radius: 8px; padding: 10px 14px; margin-bottom: 12px;
      border: 1px solid #2e7d32;">
      <div style="font-size:10px;color:#a5d6a7;letter-spacing:.5px;margin-bottom:4px;">AGENCY WEEKLY TOTAL</div>
      <div style="font-size:22px;font-weight:bold;color:#69f0ae;letter-spacing:-.5px;">${agencyTotal.toFixed(1)} hrs</div>
      <div style="font-size:10px;color:#81c784;margin-top:2px;">${dcwEntries.length} caregiver${dcwEntries.length !== 1 ? 's' : ''} across ${Object.values(shiftsByDay).filter(s => s.length > 0).length} active days</div>
    </div>
  `;

  // ── Per-DCW breakdown ──
  if (dcwEntries.length > 0) {
    html += `<div style="color:#90caf9;font-weight:bold;font-size:11px;margin-bottom:8px;letter-spacing:.4px;">📋 DCW BREAKDOWN</div>`;

    dcwEntries.forEach(([name, data]) => {
      const activeDays = DAY_ORDER.filter(d => data.days[d]);
      const dayBadges = DAY_ORDER.map(d => {
        if (!data.days[d]) return `<span style="color:#444;font-size:10px;">${d.substring(0,2)}</span>`;
        return `<span style="background:#1b5e20;color:#a5d6a7;border-radius:3px;padding:1px 5px;font-size:10px;font-weight:bold;">${d.substring(0,2)} ${data.days[d].toFixed(1)}h</span>`;
      }).join(' ');

      // Check if this DCW has any overlaps
      const hasOverlap = overlapList.some(o => o.dcw1 === name || o.dcw2 === name);

      html += `
        <div style="
          background: #1e2140; border-radius: 7px; padding: 10px 12px;
          margin-bottom: 9px; border-left: 3px solid ${hasOverlap ? '#ff4444' : '#1565c0'};
        ">
          <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
            <div style="font-weight:bold;color:#90caf9;font-size:11px;line-height:1.4;max-width:220px;">${name}</div>
            <div style="text-align:right;white-space:nowrap;">
              <div style="font-size:16px;font-weight:bold;color:#69f0ae;">${(data.totalHours||0).toFixed(1)}h</div>
              <div style="font-size:9px;color:#888;">${activeDays.length} day${activeDays.length !== 1 ? 's' : ''}</div>
            </div>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:4px;">${dayBadges}</div>
          ${hasOverlap ? `<div style="color:#ff8a80;font-size:10px;margin-top:6px;">⚠ Has scheduling overlap</div>` : ''}
        </div>
      `;
    });
  } else {
    html += `<div style="color:#888;text-align:center;padding:20px 0;">No shift data found.<br><span style="font-size:10px;">Make sure the Master Week page has loaded.</span></div>`;
  }

  // ── Overlaps section ──
  if (overlapList.length > 0) {
    html += `
      <div style="color:#ff6b6b;font-weight:bold;font-size:11px;margin:10px 0 8px;letter-spacing:.4px;">
        🔴 OVERLAPPING SHIFTS
        <span style="background:#ff4444;color:#fff;border-radius:10px;padding:1px 7px;font-size:10px;margin-left:6px;">${overlapList.length}</span>
      </div>
    `;
    overlapList.forEach(o => {
      html += `
        <div style="background:#2d1b1b;border-left:3px solid #ff4444;padding:9px 10px;margin-bottom:8px;border-radius:5px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:5px;">
            <span style="color:#ff9999;font-weight:bold;">${o.day}</span>
            <span style="background:#ff4444;color:#fff;font-size:10px;padding:1px 7px;border-radius:8px;">${o.overlapMins} min overlap</span>
          </div>
          <div style="font-size:11px;color:#ccc;line-height:1.6;">
            <div>📌 ${o.dcw1} <span style="color:#888;">${o.range1}</span></div>
            <div>📌 ${o.dcw2} <span style="color:#888;">${o.range2}</span></div>
          </div>
        </div>
      `;
    });
  }

  html += `</div>`; // end body

  // ── Footer ──
  html += `
    <div style="padding:8px 14px;border-top:1px solid #2a2a3e;background:#16213e;
      display:flex;justify-content:space-between;align-items:center;">
      <span style="color:#555;font-size:10px;">⚙ threshold: 8 min</span>
      <button id="cc-mw-rescan" style="background:#0f3460;color:#e0e0e0;border:1px solid #334;
        border-radius:5px;padding:4px 12px;font-size:11px;cursor:pointer;">
        🔄 Rescan
      </button>
    </div>
  `;

  panel.innerHTML = html;
  document.body.appendChild(panel);

  // ── Event listeners ──
  panel.querySelector('#cc-mw-close').addEventListener('click', () => panel.remove());

  panel.querySelector('#cc-mw-rescan').addEventListener('click', () => {
    panel.remove();
    runMasterWeekScan();
  });

  let minimized = false;
  panel.querySelector('#cc-mw-minimize').addEventListener('click', (e) => {
    e.stopPropagation();
    minimized = !minimized;
    const body    = panel.querySelector('#cc-mw-body');
    const summary = panel.querySelector('#cc-mw-summary');
    const footer  = panel.querySelector('#cc-mw-body + div');
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      [body, summary, footer].forEach(el => { if (el) { el.style.overflow='hidden'; el.style.height='0'; el.style.padding='0'; el.style.margin='0'; } });
      panel.style.height = 'auto'; panel.style.maxHeight = 'none'; panel.style.minHeight = '0'; panel.style.resize = 'none';
    } else {
      [body, summary, footer].forEach(el => { if (el) { el.style.overflow=''; el.style.height=''; el.style.padding=''; el.style.margin=''; } });
      panel.style.height = panel.dataset.fullH || ''; panel.style.maxHeight = '82vh'; panel.style.minHeight = '120px'; panel.style.resize = 'both';
    }
    panel.querySelector('#cc-mw-minimize').textContent = minimized ? '□' : '─';
  });

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector('#cc-mw-header');
  header.addEventListener('mousedown', (e) => {
    if (e.target.id === 'cc-mw-close' || e.target.id === 'cc-mw-minimize') return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    panel.style.left = (e.clientX - dragX) + 'px';
    panel.style.top  = (e.clientY - dragY) + 'px';
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // ── Auth vs Scheduled mismatch check for Master Week ──
  checkMasterWeekAuthMismatch(agencyTotal);
}

// ─── MASTER WEEK AUTH OVERLAY ─────────────────────────────────────
function runMasterWeekAuthOverlay() {
  document.querySelectorAll('.cc-mw-auth-info').forEach(el => el.remove());
  document.querySelectorAll('.cc-mw-injected').forEach(el => el.remove());

  const authTable = document.getElementById('uxUclMasterWeek_PatientAuthorizations_uxGvAuthorization');
  if (!authTable) return;

  const dataRows = [...authTable.querySelectorAll('tr')].filter(r => !r.querySelector('th'));
  const DAY_NAMES = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const DAY_COLS  = [10,11,12,13,14,15,16];
  const today = new Date(); today.setHours(0,0,0,0);

  dataRows.forEach(row => {
    const cells = [...row.querySelectorAll('td')];
    if (cells.length < 10) return;

    const authNum = cells[1]  ? cells[1].innerText.trim()  : '';
    const fromStr = cells[2]  ? cells[2].innerText.trim()  : '';
    const toStr   = cells[3]  ? cells[3].innerText.trim()  : '';
    const maxStr  = cells[9]  ? cells[9].innerText.trim()  : '';

    const fromDate = parseDate(fromStr);
    const toDate   = parseDate(toStr);
    const maxHrs   = parseHours(maxStr);
    if (!fromDate || !toDate || !maxHrs) return;

    const isExpired = toDate < today;
    const totalDays = daysBetween(fromDate, toDate);
    const dailyHrs  = maxHrs / totalDays;
    const weeklyHrs = dailyHrs * 7;
    const daysRemaining   = Math.max(0, daysBetween(today, toDate));
    const projectedRemain = daysRemaining * dailyHrs;

    // Inject daily hour badge under Mon-Sun columns
    DAY_COLS.forEach(ci => {
      if (cells[ci] && !cells[ci].querySelector('.cc-mw-injected')) {
        const div = document.createElement('div');
        div.className = 'cc-mw-injected';
        div.style.cssText = 'color:#00695c;font-size:11px;font-weight:700;font-family:monospace;margin-top:3px;';
        div.textContent = fmt(dailyHrs) + 'h';
        cells[ci].appendChild(div);
      }
    });

    // Expiry banner - inject as a row ABOVE if expired/expiring soon
    let bannerColor = null, bannerText = null;
    if (isExpired) {
      bannerColor = '#c62828'; bannerText = '🔴 EXPIRED — ' + toStr;
    } else if (daysRemaining <= 7) {
      bannerColor = '#b71c1c'; bannerText = '🔴 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    } else if (daysRemaining <= 15) {
      bannerColor = '#e65100'; bannerText = '🟠 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    } else if (daysRemaining <= 30) {
      bannerColor = '#1565c0'; bannerText = '🔵 EXPIRING IN ' + daysRemaining + ' DAYS — ' + toStr;
    }

    if (bannerColor) {
      const bannerRow = document.createElement('tr');
      bannerRow.className = 'cc-mw-auth-info';
      const bannerTd = document.createElement('td');
      bannerTd.colSpan = cells.length;
      bannerTd.style.cssText = `background:${bannerColor};color:#fff;font-family:monospace;font-size:11px;font-weight:700;padding:3px 14px;`;
      bannerTd.textContent = bannerText;
      bannerRow.appendChild(bannerTd);
      row.parentNode.insertBefore(bannerRow, row);
    }

    // Green info row below the data row
    const rc = isExpired ? '#c62828' : projectedRemain < maxHrs * 0.15 ? '#e65100' : '#2e7d32';
    const remFlag = isExpired ? '🚨 EXPIRED' : projectedRemain <= 0 ? '🚨 EXHAUSTED' : projectedRemain < maxHrs * 0.15 ? '⚠ LOW' : '✓';
    const infoRow = document.createElement('tr');
    infoRow.className = 'cc-mw-auth-info';
    const td = document.createElement('td');
    td.colSpan = cells.length;
    td.style.cssText = 'background:#e8f5e9;padding:7px 14px;font-family:monospace;font-size:12px;border-bottom:2px solid #81c784;';
    td.innerHTML = `
      <b style="color:#1b5e20;">⚕ ${authNum}</b> &nbsp;&nbsp;
      <span style="color:#555">${fromStr} – ${toStr} | <b>${totalDays} total days</b></span> &nbsp;&nbsp;
      Daily: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b> &nbsp;&nbsp;
      Weekly: <b style="color:#2e7d32">${fmt(weeklyHrs)}h</b> &nbsp;&nbsp;
      Remaining: <b style="color:${rc}">${fmt(projectedRemain)}h ${remFlag} (${daysRemaining} days left)</b>
      <br>
      <span style="color:#777;font-size:11px;">
        ${DAY_NAMES.map(d => `${d}: <b style="color:#2e7d32">${fmt(dailyHrs)}h</b>`).join(' | ')}
      </span>
    `;
    infoRow.appendChild(td);
    row.parentNode.insertBefore(infoRow, row.nextSibling);

    // Store weekly auth hours globally for mismatch check
    if (!window._ccMWAuthWeeklyHrs || weeklyHrs > window._ccMWAuthWeeklyHrs) {
      window._ccMWAuthWeeklyHrs = weeklyHrs;
    }
  });

  // Watch for AJAX reloads
  if (!window._ccMWAuthObserver) {
    window._ccMWAuthObserver = new MutationObserver(() => {
      if (!document.querySelector('.cc-mw-auth-info')) {
        clearTimeout(window._ccMWAuthTimer);
        window._ccMWAuthTimer = setTimeout(runMasterWeekAuthOverlay, 600);
      }
    });
    window._ccMWAuthObserver.observe(document.body, { childList: true, subtree: true });
  }
}

// ─── PATIENT SEARCH ENHANCEMENTS ─────────────────────────────────
// This runs on the OUTER page (PatientSearch_ns.aspx) — watches for iframe load
function initPatientSearchEnhancements() {
  if (document.getElementById('cc-patient-search-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-patient-search-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // The results load into an iframe — watch for it to get src set / load
  const observer = new MutationObserver(() => {
    const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
    if (iframe) {
      iframe.removeEventListener('load', onIframeLoad);
      iframe.addEventListener('load', onIframeLoad);
    }
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Also attach immediately if iframe already exists
  const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
  if (iframe) iframe.addEventListener('load', onIframeLoad);
}

function onIframeLoad() {
  setTimeout(() => {
    try {
      const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframePatientSearch');
      if (!iframe || !iframe.contentDocument) return;
      highlightUnassignedCoordinatorRows(iframe.contentDocument);
    } catch(e) {}
  }, 400);
}

// This ALSO runs directly inside the results iframe page itself
// (because all_frames:true injects content.js into the iframe too)
function initPatientSearchResultsPage() {
  if (document.getElementById('cc-results-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-results-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // ── Auto-sort by Start Date DESC (newest first) ────────────────
  // IMPORTANT: SortXSLT lives in the PAGE's JS context, not the
  // extension's isolated world. We must inject a <script> tag to call it.
  let sortDone = false;

  function autoSortStartDate() {
    if (sortDone) return;
    const table = document.getElementById('tdSearchResults');
    if (!table || table.querySelectorAll('tbody tr').length === 0) return;
    sortDone = true;

    // Inject a script tag into the page so SortXSLT runs in page context
    const s = document.createElement('script');
    s.textContent = 'if(typeof SortXSLT==="function"){SortXSLT(1,"StartDate","DESC");}';
    document.head.appendChild(s);
    s.remove();
  }

  // Watch for AJAX results to appear after Search click
  const sortObs = new MutationObserver(() => {
    clearTimeout(window._ccSortTimer);
    window._ccSortTimer = setTimeout(autoSortStartDate, 500);
  });
  sortObs.observe(document.body, { childList: true, subtree: true });
  setTimeout(autoSortStartDate, 800);

  // Coordinator highlights + watch for pagination
  highlightUnassignedCoordinatorRows(document);
  const observer = new MutationObserver(() => {
    clearTimeout(window._ccResultTimer);
    window._ccResultTimer = setTimeout(() => highlightUnassignedCoordinatorRows(document), 600);
  });
  observer.observe(document.body, { childList: true, subtree: true });
}

// ─── CAREGIVER SEARCH — NEWEST DCW BY FNE CODE ────────────────────
function ccParseFne(text) {
  // Match codes like "FNE-1640" (prefix 2-5 letters, dash, number)
  const m = (text || '').match(/\b([A-Za-z]{2,5})-(\d{2,6})\b/);
  if (!m) return null;
  return { prefix: m[1].toUpperCase(), num: parseInt(m[2], 10), raw: m[1].toUpperCase() + '-' + m[2] };
}

function ccFindCaregiverRows() {
  // The results table = the table with the most rows containing an FNE-style code
  const tables = Array.from(document.querySelectorAll('table'));
  let best = [], bestCount = 0;
  tables.forEach(t => {
    const trs = Array.from(t.querySelectorAll('tr')).filter(tr => ccParseFne(tr.innerText || ''));
    if (trs.length > bestCount) { bestCount = trs.length; best = trs; }
  });
  return best;
}

function ccExtractCurrentPage() {
  const rows = ccFindCaregiverRows();
  const out = [];
  rows.forEach(tr => {
    const txt = tr.innerText || '';
    const fne = ccParseFne(txt);
    if (!fne) return;
    const link = tr.querySelector('a');
    let name = link ? link.textContent.trim().split('\n')[0].trim() : '';
    if (!name) {
      const c0 = tr.querySelector('td');
      if (c0) name = (c0.innerText || '').split('\n')[0].trim();
    }
    const dobM = txt.match(/\b\d{2}\/\d{2}\/\d{4}\b/);
    const phoneM = txt.match(/\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b/);
    const status = /inactive/i.test(txt) ? 'Inactive' : /active/i.test(txt) ? 'Active' : '';
    out.push({ name, code: fne.raw, prefix: fne.prefix, num: fne.num,
      dob: dobM ? dobM[0] : '', phone: phoneM ? phoneM[0] : '', status });
  });
  return out;
}

function ccExtractCaregivers() {
  const seen = {};
  const uniq = ccExtractCurrentPage().filter(r => { if (seen[r.code]) return false; seen[r.code] = 1; return true; });
  uniq.sort((a, b) => b.num - a.num);
  return uniq;
}

// ── Pagination helpers (results are server-paged via SortXSLT) ──
function ccWait(ms) { return new Promise(r => setTimeout(r, ms)); }

function ccPageLabelEl() {
  return Array.from(document.querySelectorAll('.input-group-label')).find(s => /Page\s+\d+\s+of\s+\d+/i.test(s.textContent || '')) || null;
}
function ccPageInfo() {
  const el = ccPageLabelEl();
  const m = el ? el.textContent.match(/Page\s+(\d+)\s+of\s+(\d+)/i) : null;
  return m ? { cur: +m[1], total: +m[2] } : { cur: 1, total: 1 };
}
function ccFirstCode() {
  const rows = ccFindCaregiverRows();
  if (!rows.length) return '';
  const f = ccParseFne(rows[0].innerText || '');
  return f ? f.raw : '';
}
function ccPageSig() {
  // Signature of the current page: page number + first & last FNE code shown
  const info = ccPageInfo();
  const rows = ccFindCaregiverRows();
  const first = rows.length ? ccParseFne(rows[0].innerText || '') : null;
  const last = rows.length ? ccParseFne(rows[rows.length - 1].innerText || '') : null;
  return info.cur + '|' + rows.length + '|' + (first ? first.raw : '') + '|' + (last ? last.raw : '');
}
// Call the page's own SortXSLT(pageNum, '', 'ASC') via the background script's
// MAIN-world executeScript — this bypasses the page's Content-Security-Policy,
// unlike a content-script-injected <script> tag which CSP can silently block
// (confirmed: SortXSLT exists and is reachable, but plain script-tag injection
// had zero effect on this page — CSP was blocking it).
// IMPORTANT: only ONE navigation call may be in flight at a time (ASP.NET AJAX
// UpdatePanel ignores overlapping partial postbacks).
function ccRunSortXSLT(pageNum) {
  return new Promise(resolve => {
    try {
      chrome.runtime.sendMessage({ action: 'runSortXSLT', page: pageNum, col: '', dir: 'ASC' }, () => resolve());
    } catch (e) { resolve(); }
  });
}
async function ccGotoPage(pageNum) {
  const before = ccPageSig();
  await ccRunSortXSLT(pageNum);
  // ASP.NET partial postbacks can take a few seconds — poll generously (~20s)
  for (let i = 0; i < 80; i++) {
    await ccWait(250);
    if (ccPageSig() !== before) { await ccWait(300); return true; } // small settle delay
  }
  return false;
}
async function ccScanAllPages(onStatus) {
  const all = {};
  const total = ccPageInfo().total || 1;
  for (let p = 1; p <= total; p++) {
    if (ccPageInfo().cur !== p) {
      const ok = await ccGotoPage(p);
      if (!ok) break; // could not navigate — stop rather than loop forever
    }
    if (onStatus) onStatus(ccPageInfo().cur, total);
    ccExtractCurrentPage().forEach(r => { if (!all[r.code]) all[r.code] = r; });
  }
  return Object.values(all).sort((a, b) => b.num - a.num);
}
async function ccRunFneScan() {
  const btn = document.getElementById('cc-fne-btn');
  const info = ccPageInfo();
  if (info.total <= 1) { ccShowFnePanel(ccExtractCaregivers()); return; }
  if (btn) { btn.disabled = true; btn.dataset.orig = btn.textContent; }
  let recs = [];
  try {
    recs = await ccScanAllPages((p, t) => { if (btn) btn.textContent = '⏳ Scanning page ' + p + ' of ' + t + '...'; });
  } catch (e) { recs = ccExtractCaregivers(); }
  if (btn) { btn.disabled = false; btn.textContent = btn.dataset.orig || '🆕 Find Newest DCWs'; }
  ccShowFnePanel(recs);
}

function initCaregiverSearchScanner() {
  if (document.getElementById('cc-cgsearch-init')) return;
  const marker = document.createElement('div');
  marker.id = 'cc-cgsearch-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  function tryInject() {
    if (document.getElementById('cc-fne-btn')) return;
    if (ccFindCaregiverRows().length < 2) return; // wait for results
    const btn = document.createElement('button');
    btn.id = 'cc-fne-btn';
    btn.textContent = '🆕 Find Newest DCWs';
    btn.title = 'Sort all caregivers by FNE code — highest number = most recent hire';
    btn.style.cssText = 'position:fixed;top:118px;right:22px;z-index:99998;background:#1e3a5f;color:#fff;border:none;border-radius:8px;padding:10px 16px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,0.3);font-family:system-ui,sans-serif';
    btn.onclick = ccRunFneScan;
    document.body.appendChild(btn);
  }
  const obs = new MutationObserver(() => {
    clearTimeout(window._ccCgTimer);
    window._ccCgTimer = setTimeout(tryInject, 500);
  });
  obs.observe(document.body, { childList: true, subtree: true });
  setTimeout(tryInject, 1000);
}

function ccShowFnePanel(recs) {
  if (!recs) recs = ccExtractCaregivers();
  if (!recs.length) { alert('No caregivers with FNE codes found. Run a Search first.'); return; }

  // Highlight any of the top-10 newest that happen to be visible on the current page
  document.querySelectorAll('.cc-fne-rank').forEach(el => el.remove());
  const topRank = {};
  recs.slice(0, 10).forEach((r, i) => { topRank[r.code] = i + 1; });
  ccFindCaregiverRows().forEach(tr => {
    const f = ccParseFne(tr.innerText || '');
    if (!f || !topRank[f.raw]) return;
    const rank = topRank[f.raw];
    tr.querySelectorAll('td').forEach(td => td.style.setProperty('background-color', rank === 1 ? '#c8e6c9' : '#e8f5e9', 'important'));
    const c0 = tr.querySelector('td');
    if (c0) {
      const b = document.createElement('span');
      b.className = 'cc-fne-rank';
      b.textContent = '#' + rank + ' NEWEST ';
      b.style.cssText = 'display:inline-block;background:#2e7d32;color:#fff;font-size:9px;font-weight:800;padding:1px 5px;border-radius:4px;margin-right:4px';
      c0.prepend(b);
    }
  });

  const ov = document.createElement('div');
  ov.id = 'cc-fne-ov';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif';
  const rowsHtml = recs.map((r, i) => '<tr style="border-bottom:1px solid #eee;' + (i < 3 ? 'background:#f1f8e9' : '') + '">' +
    '<td style="padding:7px 10px;font-weight:700;color:' + (i < 3 ? '#2e7d32' : '#999') + '">' + (i + 1) + '</td>' +
    '<td style="padding:7px 10px;font-weight:600">' + r.name + '</td>' +
    '<td style="padding:7px 10px;font-family:monospace;color:#1565c0;font-weight:700">' + r.code + '</td>' +
    '<td style="padding:7px 10px">' + r.dob + '</td>' +
    '<td style="padding:7px 10px">' + r.phone + '</td>' +
    '<td style="padding:7px 10px">' + r.status + '</td></tr>').join('');
  ov.innerHTML = '<div style="background:#fff;border-radius:12px;width:780px;max-width:92vw;max-height:86vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.4)">' +
    '<div style="padding:16px 20px;background:#1e3a5f;color:#fff;display:flex;align-items:center;gap:12px">' +
      '<div style="flex:1"><div style="font-size:16px;font-weight:800">🆕 Newest DCWs by FNE Code</div>' +
      '<div style="font-size:12px;opacity:0.85;margin-top:2px">' + recs.length + ' caregivers · highest FNE first (newest hires). Top 10 highlighted in green below.</div></div>' +
      '<button id="cc-fne-csv" style="background:#4caf50;color:#fff;border:none;border-radius:6px;padding:8px 14px;font-size:12px;font-weight:700;cursor:pointer">⬇ Export CSV</button>' +
      '<button id="cc-fne-x" style="background:rgba(255,255,255,0.2);color:#fff;border:none;border-radius:6px;padding:8px 12px;font-size:14px;cursor:pointer">✕</button>' +
    '</div>' +
    '<div style="overflow-y:auto">' +
      '<table style="width:100%;border-collapse:collapse;font-size:13px">' +
        '<thead><tr style="position:sticky;top:0;background:#f5f5f5;z-index:1">' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">RANK</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">NAME</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">FNE CODE</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">DOB</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">PHONE</th>' +
          '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">STATUS</th>' +
        '</tr></thead><tbody>' + rowsHtml + '</tbody></table></div></div>';
  document.body.appendChild(ov);
  document.getElementById('cc-fne-x').onclick = () => ov.remove();
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  document.getElementById('cc-fne-csv').onclick = () => {
    const csv = [['Rank', 'Name', 'FNE Code', 'DOB', 'Phone', 'Status']]
      .concat(recs.map((r, i) => [i + 1, r.name, r.code, r.dob, r.phone, r.status]))
      .map(row => row.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'newest-dcws-' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
  };
}

// ─── APPOINTMENTS — AUTH vs SCHEDULE/CONFIRMED COMPARE ────────────
function ccCol(row, tokens) {
  const k = Object.keys(row).find(k => { const kl = k.toLowerCase(); return tokens.every(t => kl.includes(t)); });
  return k ? row[k] : '';
}
function ccParseMDY(s) {
  const m = String(s).match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  return m ? new Date(+m[3], +m[1] - 1, +m[2]) : null;
}

function initApptAuthCompare() {
  const marker = document.createElement('div');
  marker.id = 'cc-authcmp-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  if (document.getElementById('cc-authcmp-btn')) return;
  const btn = document.createElement('button');
  btn.id = 'cc-authcmp-btn';
  btn.textContent = '📋 Auth vs Schedule';
  btn.title = 'Upload the Patient Authorization Report — compares each member\'s active weekly authorization to this week\'s scheduled & confirmed hours';
  btn.style.cssText = 'position:fixed;bottom:20px;left:20px;z-index:99998;background:#5b3fa8;color:#fff;border:none;border-radius:8px;padding:10px 16px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 4px 14px rgba(0,0,0,0.3);font-family:system-ui,sans-serif';
  const inp = document.createElement('input');
  inp.type = 'file';
  inp.accept = '.xlsx,.xls';
  inp.style.display = 'none';
  inp.addEventListener('change', e => { if (e.target.files[0]) { ccAuthCompareFile(e.target.files[0]); e.target.value = ''; } });
  btn.onclick = () => inp.click();
  document.body.appendChild(btn);
  document.body.appendChild(inp);
}

function ccAuthCompareFile(file) {
  const btn = document.getElementById('cc-authcmp-btn');
  if (btn) btn.textContent = '⏳ Reading...';
  const reader = new FileReader();
  reader.onload = e => {
    let wb;
    try { wb = XLSX.read(new Uint8Array(e.target.result), { type: 'array' }); }
    catch (err) { alert('Could not read Excel: ' + err.message); if (btn) btn.textContent = '📋 Auth vs Schedule'; return; }
    const ws = wb.Sheets['Detail Data'] || wb.Sheets[wb.SheetNames[wb.SheetNames.length - 1]];
    const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
    if (btn) btn.textContent = '📋 Auth vs Schedule';
    ccBuildAuthCompare(rows);
  };
  reader.readAsArrayBuffer(file);
}

// Build map: FNE code -> active authorization (period contains today)
function ccBuildAuthMap(rows) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const byFne = {};
  rows.forEach(r => {
    const fne = String(ccCol(r, ['admission']) || '').trim().toUpperCase();
    if (!fne) return;
    const name = String(ccCol(r, ['member', 'name']) || '').trim();
    const weekly = parseFloat(ccCol(r, ['weekly', 'alloc'])) || 0;
    const range = String(ccCol(r, ['auth', 'from']) || '');
    const dm = range.match(/(\d{1,2}\/\d{1,2}\/\d{4})\s*[-–]\s*(\d{1,2}\/\d{1,2}\/\d{4})/);
    const from = dm ? ccParseMDY(dm[1]) : null;
    const to = dm ? ccParseMDY(dm[2]) : null;
    const active = from && to && from <= today && today <= to;
    const rec = { fne, name, weekly, from, to, active };
    if (!byFne[fne]) byFne[fne] = [];
    byFne[fne].push(rec);
  });
  // For each member pick the ACTIVE auth (period contains today); else the latest by From date
  const out = {};
  Object.keys(byFne).forEach(fne => {
    const list = byFne[fne];
    const actives = list.filter(a => a.active);
    let chosen;
    if (actives.length) chosen = actives.sort((a, b) => (b.from || 0) - (a.from || 0))[0];
    else chosen = list.sort((a, b) => (b.from || 0) - (a.from || 0))[0];
    out[fne] = chosen;
  });
  return out;
}

// Sum each patient's scheduled + confirmed hours for the displayed week
function ccApptWeeklyTotals() {
  const grid = document.getElementById('divPatientCalendarGrid-container');
  const totals = {};
  if (!grid || grid.children.length === 0) return { totals, patientView: false };
  grid.querySelectorAll('.cg-row-container').forEach(row => {
    const cell = row.querySelector('.cg-patient-cell');
    if (!cell) return;
    const link = cell.querySelector('a.cg-word-break-string') || cell;
    const txt = link.textContent || '';
    const fneM = txt.match(/\b([A-Za-z]{2,5}-\d{2,6})\b/);
    const fne = fneM ? fneM[1].toUpperCase() : null;
    const name = txt.split('\n')[0].replace(/\(.*/, '').trim();
    const key = fne || name;
    if (!totals[key]) totals[key] = { name, fne, sched: 0, conf: 0, visits: 0 };
    row.querySelectorAll('.cg-visit-item').forEach(block => {
      const totalEl = block.querySelector('[data-visittotal-id]');
      if (!totalEl) return;
      const t = totalEl.textContent || '';
      const sm = t.match(/S:([\d:]+)/); const cm = t.match(/C:([\d:]+)/);
      if (sm) totals[key].sched += parseHHMM(sm[1]) || 0;
      if (cm) totals[key].conf += parseHHMM(cm[1]) || 0;
      totals[key].visits++;
    });
  });
  return { totals, patientView: true };
}

function ccBuildAuthCompare(rows) {
  const authMap = ccBuildAuthMap(rows);
  const { totals, patientView } = ccApptWeeklyTotals();
  if (!patientView) { alert('Please switch the Appointments page to the PATIENT calendar view, run a search so members appear, then upload again.'); return; }
  const keys = Object.keys(totals);
  if (!keys.length) { alert('No members found on the page. Run a search on the Appointments page first.'); return; }

  const recs = keys.map(k => {
    const t = totals[k];
    const auth = t.fne ? authMap[t.fne] : null;
    const weekly = auth ? auth.weekly : null;
    const schedD = weekly != null ? t.sched - weekly : null;
    const confD = weekly != null ? t.conf - weekly : null;
    return { name: auth ? auth.name : t.name, fne: t.fne || '—', weekly,
      sched: t.sched, conf: t.conf, schedD, confD, hasAuth: !!auth, active: auth ? auth.active : false };
  });
  // Sort: biggest problems first (largest absolute scheduled delta)
  recs.sort((a, b) => Math.abs((b.schedD || 0)) - Math.abs((a.schedD || 0)));
  ccShowAuthComparePanel(recs);
}

function ccFmtDelta(d) {
  if (d == null) return '<span style="color:#999">—</span>';
  if (Math.abs(d) < 0.5) return '<span style="color:#2e7d32;font-weight:700">✓ On target</span>';
  const over = d > 0;
  const color = over ? '#c62828' : '#e65100';
  const label = over ? 'OVER' : 'UNDER';
  return '<span style="color:' + color + ';font-weight:700">' + label + ' ' + (over ? '+' : '') + d.toFixed(1) + 'h</span>';
}

function ccShowAuthComparePanel(recs) {
  document.getElementById('cc-authcmp-ov') && document.getElementById('cc-authcmp-ov').remove();
  const over = recs.filter(r => r.schedD != null && r.schedD > 0.5).length;
  const under = recs.filter(r => r.schedD != null && r.schedD < -0.5).length;
  const noAuth = recs.filter(r => !r.hasAuth).length;

  const rowsHtml = recs.map(r => {
    const bg = (r.schedD != null && r.schedD > 0.5) ? '#ffebee' : (r.schedD != null && r.schedD < -0.5) ? '#fff3e0' : '';
    return '<tr style="border-bottom:1px solid #eee;background:' + bg + '">' +
      '<td style="padding:7px 10px;font-weight:600">' + r.name + (r.hasAuth && !r.active ? ' <span style="font-size:9px;color:#e65100">(no active auth — latest shown)</span>' : '') + '</td>' +
      '<td style="padding:7px 10px;font-family:monospace;color:#1565c0">' + r.fne + '</td>' +
      '<td style="padding:7px 10px;text-align:center;font-weight:700">' + (r.weekly != null ? r.weekly.toFixed(1) : '<span style="color:#c62828">no auth</span>') + '</td>' +
      '<td style="padding:7px 10px;text-align:center">' + r.sched.toFixed(1) + '</td>' +
      '<td style="padding:7px 10px">' + ccFmtDelta(r.schedD) + '</td>' +
      '<td style="padding:7px 10px;text-align:center">' + r.conf.toFixed(1) + '</td>' +
      '<td style="padding:7px 10px">' + ccFmtDelta(r.confD) + '</td></tr>';
  }).join('');

  const ov = document.createElement('div');
  ov.id = 'cc-authcmp-ov';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:system-ui,sans-serif';
  ov.innerHTML = '<div style="background:#fff;border-radius:12px;width:920px;max-width:94vw;max-height:88vh;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,0.4)">' +
    '<div style="padding:16px 20px;background:#5b3fa8;color:#fff;display:flex;align-items:center;gap:12px">' +
      '<div style="flex:1"><div style="font-size:16px;font-weight:800">📋 Auth vs Schedule — This Week</div>' +
      '<div style="font-size:12px;opacity:0.9;margin-top:2px">' + recs.length + ' members · <b style="color:#ffcdd2">' + over + ' over-scheduled</b> · <b style="color:#ffe0b2">' + under + ' under-scheduled</b>' + (noAuth ? ' · ' + noAuth + ' no auth match' : '') + '</div></div>' +
      '<button id="cc-authcmp-csv" style="background:#4caf50;color:#fff;border:none;border-radius:6px;padding:8px 14px;font-size:12px;font-weight:700;cursor:pointer">⬇ Export CSV</button>' +
      '<button id="cc-authcmp-x" style="background:rgba(255,255,255,0.2);color:#fff;border:none;border-radius:6px;padding:8px 12px;font-size:14px;cursor:pointer">✕</button>' +
    '</div>' +
    '<div style="overflow-y:auto"><table style="width:100%;border-collapse:collapse;font-size:13px">' +
      '<thead><tr style="position:sticky;top:0;background:#f5f5f5;z-index:1">' +
        '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">MEMBER</th>' +
        '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">FNE</th>' +
        '<th style="padding:8px 10px;text-align:center;font-size:11px;color:#888">WEEKLY AUTH</th>' +
        '<th style="padding:8px 10px;text-align:center;font-size:11px;color:#888">SCHEDULED</th>' +
        '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">SCHED vs AUTH</th>' +
        '<th style="padding:8px 10px;text-align:center;font-size:11px;color:#888">CONFIRMED</th>' +
        '<th style="padding:8px 10px;text-align:left;font-size:11px;color:#888">CONF vs AUTH</th>' +
      '</tr></thead><tbody>' + rowsHtml + '</tbody></table></div></div>';
  document.body.appendChild(ov);
  document.getElementById('cc-authcmp-x').onclick = () => ov.remove();
  ov.onclick = e => { if (e.target === ov) ov.remove(); };
  document.getElementById('cc-authcmp-csv').onclick = () => {
    const csv = [['Member', 'FNE', 'Weekly Auth', 'Scheduled', 'Sched vs Auth', 'Confirmed', 'Conf vs Auth']]
      .concat(recs.map(r => [r.name, r.fne, r.weekly != null ? r.weekly.toFixed(1) : 'no auth',
        r.sched.toFixed(1), r.schedD != null ? r.schedD.toFixed(1) : '',
        r.conf.toFixed(1), r.confD != null ? r.confD.toFixed(1) : '']))
      .map(row => row.map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'auth-vs-schedule-' + new Date().toISOString().slice(0, 10) + '.csv';
    a.click();
  };
}

function highlightUnassignedCoordinatorRows(doc) {
  const rows = doc.querySelectorAll('table tr');
  if (rows.length === 0) return;

  // Find coordinator column index from header row
  let coordColIdx = -1;
  rows.forEach(row => {
    if (coordColIdx !== -1) return;
    const ths = row.querySelectorAll('th, td[style*="background"]');
    ths.forEach((th, idx) => {
      if (/coordinator/i.test(th.innerText)) coordColIdx = idx;
    });
  });

  rows.forEach(row => {
    if (row.querySelector('th')) return;
    const cells = row.querySelectorAll('td');
    if (cells.length < 3) return;

    let coordText = '';
    if (coordColIdx !== -1 && cells[coordColIdx]) {
      coordText = cells[coordColIdx].innerText.trim();
    } else {
      // Fallback: check every cell for blank/Default/Unassigned
      cells.forEach(cell => {
        const t = cell.innerText.trim();
        if (t === '' || /^default$/i.test(t) || /^unassigned$/i.test(t)) coordText = t;
      });
    }

    const isUnassigned = coordText === '' || /^default$/i.test(coordText) || /^unassigned$/i.test(coordText);
    if (isUnassigned && !row.querySelector('.cc-coord-warn')) {
      row.querySelectorAll('td').forEach(td => {
        td.style.setProperty('background-color', '#ffe0b2', 'important');
      });
      const firstCell = cells[0];
      if (firstCell) {
        const icon = document.createElement('span');
        icon.className = 'cc-coord-warn';
        icon.title = 'No coordinator assigned';
        icon.style.cssText = 'color:#e65100;font-weight:700;margin-right:4px;font-size:12px;';
        icon.textContent = '⚠ ';
        firstCell.prepend(icon);
      }
    }
  });
}



// ─── AUTH VS SCHEDULED MISMATCH — MASTER WEEK ────────────────────
function checkMasterWeekAuthMismatch(agencyTotalHrs) {
  // Remove previous mismatch banners
  document.querySelectorAll('.cc-mw-mismatch-banner').forEach(el => el.remove());

  const authWeeklyHrs = window._ccMWAuthWeeklyHrs;
  if (!authWeeklyHrs || !agencyTotalHrs) return;

  const diff = Math.abs(agencyTotalHrs - authWeeklyHrs);
  if (diff === 0) return;

  const isOver = agencyTotalHrs > authWeeklyHrs;

  let bgColor, borderColor, bannerBg, textColor, label;
  if (diff > 2) {
    bgColor     = 'rgba(198,40,40,0.08)';
    borderColor = '#c62828';
    bannerBg    = '#c62828';
    textColor   = '#fff';
    label = `🔴 MASTER WEEK MISMATCH >2h: Scheduled ${fmt(agencyTotalHrs)}h vs Auth ${fmt(authWeeklyHrs)}h/wk (${isOver ? '+' : '-'}${fmt(diff)}h)`;
  } else {
    bgColor     = 'rgba(249,168,37,0.10)';
    borderColor = '#f9a825';
    bannerBg    = '#f9a825';
    textColor   = '#333';
    label = `🟡 MASTER WEEK MISMATCH ≤2h: Scheduled ${fmt(agencyTotalHrs)}h vs Auth ${fmt(authWeeklyHrs)}h/wk (${isOver ? '+' : '-'}${fmt(diff)}h)`;
  }

  // Find the master week schedule table and color it
  const mwTables = document.querySelectorAll('.masterchild table, table.hhax-table');
  mwTables.forEach(t => {
    t.style.setProperty('outline', `3px solid ${borderColor}`, 'important');
    t.style.setProperty('background-color', bgColor, 'important');
  });

  // Inject banner at top of page content
  const banner = document.createElement('div');
  banner.className = 'cc-mw-mismatch-banner';
  banner.style.cssText = `background:${bannerBg};color:${textColor};font-family:monospace;font-size:12px;font-weight:700;padding:7px 14px;border-radius:4px;margin:8px 0;`;
  banner.textContent = label;
  const mainContent = document.querySelector('main, .hhax-main-content, #mainContentRegion, body');
  if (mainContent) mainContent.insertBefore(banner, mainContent.firstChild);
}

// ─── PREBILLING ENHANCEMENTS ──────────────────────────────────────
function initPrebillingEnhancements() {
  const marker = document.createElement('div');
  marker.id = 'cc-prebilling-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // Inject the compliance banner + scan button immediately
  injectPrebillingBanner();
  injectPrebillingScanBtn();

  // Show the "multiple missed visits" floater from any existing memory
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    if (r._cc_billing_memory) updatePrebillingFloater(r._cc_billing_memory);
  });

  // ── Auto-sort by Visit Date DESC (latest first) ────────────────
  function autoSortByVisitDateDesc() {
    if (window._ccPrebillSorted) return;
    const allLinks = Array.from(document.querySelectorAll('th a, thead a'));
    const visitDateLink = allLinks.find(a => {
      const txt = a.innerText.trim().toLowerCase();
      return txt.includes('visit date') || txt.includes('service date');
    });
    if (visitDateLink) {
      try {
        if (typeof SortXSLT === 'function') {
          SortXSLT(1, 'VisitDate', 'DESC');
          window._ccPrebillSorted = true;
          return;
        }
      } catch(e) {}
      visitDateLink.click();
      setTimeout(() => {
        const links2 = Array.from(document.querySelectorAll('th a, thead a'));
        const vdLink2 = links2.find(a => a.innerText.trim().toLowerCase().includes('visit date') || a.innerText.trim().toLowerCase().includes('service date'));
        if (vdLink2) vdLink2.click();
      }, 800);
      window._ccPrebillSorted = true;
    }
  }

  setTimeout(autoSortByVisitDateDesc, 1200);
  setTimeout(autoSortByVisitDateDesc, 2500);

  // Watch for results to load — re-inject button + EVV bars
  const observer = new MutationObserver(() => {
    clearTimeout(window._ccPrebillTimer);
    window._ccPrebillTimer = setTimeout(() => {
      injectPrebillingScanBtn();
      injectEVVUrgencyBars();
    }, 600);
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Also run after delays in case results already loaded
  setTimeout(() => { injectPrebillingScanBtn(); injectEVVUrgencyBars(); }, 1500);
  setTimeout(() => { injectPrebillingScanBtn(); injectEVVUrgencyBars(); }, 3500);
}

// ── Inject "Scan Prebilling & Remember" button ─────────────────
function injectPrebillingScanBtn() {
  if (document.getElementById('cc-prebill-scan-wrap')) return;

  // Best anchor: above the results table
  const anchor = document.getElementById('tdSearchResults') ||
                 document.getElementById('tdScroll') ||
                 document.querySelector('.scrollpane.table-scroll') ||
                 document.getElementById('ctl00_ContentPlaceHolder1_divPrebillingReportInternalScroll');
  if (!anchor) return;

  const wrap = document.createElement('div');
  wrap.id = 'cc-prebill-scan-wrap';
  wrap.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0 4px 0;font-family:Arial,sans-serif;flex-wrap:wrap;';

  const btn = document.createElement('button');
  btn.id = 'cc-prebill-scan-btn';
  btn.textContent = '💾 Scan Prebilling & Remember';
  btn.title = 'Scan all prebilling rows across all pages and merge into billing memory — used to flag unconfirmed visits on the Add Internal Batch Invoice page. Works alongside the Appointments scan.';
  btn.style.cssText = 'background:#1a2a4a;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 12px;font-size:11px;cursor:pointer;font-weight:bold;';

  const statusLbl = document.createElement('span');
  statusLbl.id = 'cc-prebill-scan-status';
  statusLbl.style.cssText = 'font-size:11px;color:#888;font-family:monospace;';

  // Pre-populate with existing memory info
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    if (r._cc_billing_memory) {
      const d = r._cc_billing_memory;
      const unconf = d.visits.filter(v => !v.isConfirmed).length;
      const savedTime = new Date(d.savedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      statusLbl.textContent = `Last saved ${savedTime} · ${d.totalVisits || d.visits.length} visits · ${unconf} unconfirmed`;
      statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
    } else {
      statusLbl.textContent = 'No memory saved yet — click to scan';
      statusLbl.style.color = '#888';
    }
  });

  // Export button — writes the shared visitId-keyed format the billing page imports.
  const expBtn = document.createElement('button');
  expBtn.id = 'cc-prebill-export-btn';
  expBtn.textContent = '📤 Export for Billing';
  expBtn.title = 'Export what was scanned (unconfirmed = missed) in the shared format, so you can import it on the Add Internal Batch Invoice page and cross out unbillable client-days.';
  expBtn.style.cssText = 'background:#1a3a2a;color:#69f0ae;border:1px solid #2a7a5a;border-radius:5px;padding:5px 12px;font-size:11px;cursor:pointer;font-weight:bold;';
  expBtn.addEventListener('click', () => ccPrebillingExport(expBtn));

  btn.addEventListener('click', () => scanPrebillingAndRemember(btn, statusLbl));
  wrap.appendChild(btn);
  wrap.appendChild(expBtn);
  wrap.appendChild(statusLbl);
  anchor.parentNode.insertBefore(wrap, anchor);
}

// Export prebilling records (from billing memory) in the shared format. The
// billing importer treats isConfirmed===false as "bad", so unconfirmed visits
// drive the cross-out there.
function ccPrebillingExport(btn) {
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    const mem = r._cc_billing_memory;
    if (!mem || !mem.visits || !mem.visits.length) {
      alert('Nothing scanned yet. Click "Scan Prebilling & Remember" first, then export.');
      return;
    }
    const visits = mem.visits.map(v => ({
      visitId: v.visitId, member: v.memberName || v.member || '', fne: v.clientFne || v.fne || '', date: v.date || '',
      caregiver: v.caregiverName || '', caregiverId: v.caregiverId || '',
      isConfirmed: v.isConfirmed, source: v.source || 'prebilling'
    }));
    const stamp = new Date().toISOString().slice(0, 10);
    ccDownloadFile('prebilling-' + stamp + '.json',
      JSON.stringify({ exportedAt: new Date().toISOString(), source: 'prebilling', totalVisits: visits.length, visits }),
      'application/json');
    const unconf = visits.filter(v => v.isConfirmed === false);
    const hdr = ['Member', 'FNE/Caregiver', 'Date', 'Confirmed', 'Visit ID'];
    const csv = [hdr, ...unconf.map(v => [v.member, v.caregiver, v.date, 'No', v.visitId])]
      .map(a => a.map(x => '"' + String(x == null ? '' : x).replace(/"/g, '""') + '"').join(',')).join('\n');
    ccDownloadFile('prebilling-unconfirmed-' + stamp + '.csv', csv, 'text/csv');
    if (btn) { const o = btn.textContent; btn.textContent = '✓ ' + unconf.length + ' unconf'; setTimeout(() => btn.textContent = o, 2500); }
  });
}

// ── Prebilling page scanner ────────────────────────────────────
async function scanPrebillingAndRemember(btn, statusLbl) {
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Scanning...'; }
  if (statusLbl) { statusLbl.textContent = 'Scanning...'; statusLbl.style.color = '#90caf9'; }

  const allRecords = [];
  const seenKeys   = new Set();
  let pageNum      = 1;

  // ── Parse military time range "0430-1230" → minutes duration ──
  function parseSchedMilitary(range) {
    const m = (range || '').replace(/\s/g, '').match(/^(\d{2})(\d{2})-(\d{2})(\d{2})$/);
    if (!m) return null;
    const start = parseInt(m[1]) * 60 + parseInt(m[2]);
    const end   = parseInt(m[3]) * 60 + parseInt(m[4]);
    const diff  = end > start ? end - start : end + 1440 - start;
    return diff > 0 ? diff : null;
  }

  // ── Snapshot all rows on current page ──
  function scanCurrentPage() {
    const tbody = document.querySelector(
      '#tblDetails tbody, table.hhax-table-soy tbody, table.sortableTable tbody'
    );
    if (!tbody) return 0;

    let count = 0;
    Array.from(tbody.querySelectorAll('tr:not(.cc-evv-bar-row)')).forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 13) return;

      const dateText = tds[0].textContent.trim();
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;

      // Patient ID from link onclick
      const patLink = tds[1].querySelector('a');
      const patM = (patLink?.getAttribute('onclick') || '').match(/RedirectToInternalPatientPage\((\d+)\)/);
      const patientId = patM ? patM[1] : null;
      if (!patientId) return;

      // Caregiver ID + name
      const cgLink  = tds[5].querySelector('a');
      const cgM     = (cgLink?.getAttribute('onclick') || '').match(/RedirectToAidePage\((\d+)\)/);
      const caregiverId   = cgM ? cgM[1] : null;
      const caregiverName = cgLink
        ? (cgLink.childNodes[0]?.textContent?.trim() || tds[5].textContent.split('\n')[0].trim()).replace(/\s+/g, ' ').trim()
        : tds[5].textContent.split('\n')[0].trim();

      // Visit ID from edit button id="VID-NNN-VISITID"
      const lastTd  = tds[tds.length - 1];
      const editBtn = lastTd.querySelector('a[id^="VID-"]');
      const vidM    = editBtn?.id?.match(/VID-\d+-(\d+)/);
      let visitId   = vidM ? vidM[1] : null;
      if (!visitId) {
        const ocM = (editBtn?.getAttribute('onclick') || '').match(/RedirectToVisitPage\((\d+)/);
        if (ocM) visitId = ocM[1];
      }

      // Dedup by visitId or composite key
      const dedupKey = visitId || (patientId + '_' + dateText + '_' + (caregiverId || caregiverName));
      if (seenKeys.has(dedupKey)) return;
      seenKeys.add(dedupKey);

      // Confirmation status:
      // - tds[9] = Visit Time: warning triangle = missing EVV
      // - tds[12] = Problems: "Incomplete Confirmation" = unconfirmed
      const hasEVVWarning = !!tds[9].querySelector('.warning, .fa-exclamation-triangle');
      const problemsText  = tds[12] ? tds[12].textContent : '';
      const isConfirmed   = !hasEVVWarning && !problemsText.includes('Incomplete Confirmation');

      const schedRange = tds[8].textContent.trim();
      const memberName = tds[2].textContent.trim();
      // Admission ID column (tds[1]) shows "FNE-900173" — same stable code
      // printed on the billing grid, unlike names which vary in format
      // across pages. Use it as the primary cross-page match key.
      const fneM2 = tds[1].textContent.match(/(FNE-\d+)/i);
      const clientFne = fneM2 ? fneM2[1].toUpperCase() : '';

      allRecords.push({
        visitId,
        date:         dateText,
        patientId,
        memberName,
        clientFne,
        caregiverId,
        caregiverName,
        schedRange,
        schedMins:    parseSchedMilitary(schedRange),
        isConfirmed,
        source:       'prebilling'
      });
      count++;
    });
    return count;
  }

  // ── Wait for page to change after clicking Next ──
  async function waitForPageChange(prevFirstId) {
    await new Promise(resolve => {
      let tries = 0;
      const check = setInterval(() => {
        tries++;
        const firstRow = document.querySelector(
          '#tblDetails tbody tr:not(.cc-evv-bar-row), table.hhax-table-soy tbody tr:not(.cc-evv-bar-row)'
        );
        const curId = firstRow?.querySelector('a[id^="VID-"]')?.id;
        if ((curId && curId !== prevFirstId) || tries >= 60) { clearInterval(check); resolve(); }
      }, 200);
    });
    await new Promise(r => setTimeout(r, 400));
  }

  // ── Scan page 1 ──
  scanCurrentPage();
  if (statusLbl) statusLbl.textContent = `Page ${pageNum} scanned (${allRecords.length} rows)...`;

  // ── Auto-paginate ──
  while (pageNum < 100) {
    const pagingDiv = document.getElementById('divPrebillingReportInternalPaging') ||
                      document.querySelector('[id*="Paging"]');
    if (!pagingDiv) break;

    // Find Next link by common text patterns
    const pagerLinks = Array.from(pagingDiv.querySelectorAll('a, button'));
    const nextLink = pagerLinks.find(el => {
      const t = el.textContent.trim();
      return t === '>' || t === '>>' || t.toLowerCase() === 'next';
    });
    if (!nextLink) break;

    // Check if disabled
    const isDisabled = nextLink.classList.contains('disabled') ||
                       nextLink.hasAttribute('disabled') ||
                       nextLink.getAttribute('aria-disabled') === 'true';
    if (isDisabled) break;

    const prevFirstRow = document.querySelector(
      '#tblDetails tbody tr:not(.cc-evv-bar-row), table.hhax-table-soy tbody tr:not(.cc-evv-bar-row)'
    );
    const prevFirstId = prevFirstRow?.querySelector('a[id^="VID-"]')?.id;

    nextLink.click();
    await waitForPageChange(prevFirstId);

    pageNum++;
    if (statusLbl) statusLbl.textContent = `Page ${pageNum} scanning (${allRecords.length} rows so far)...`;
    if (btn) btn.textContent = `⏳ Page ${pageNum}...`;

    const newRows = scanCurrentPage();
    if (newRows === 0) break; // Empty page — done
  }

  // ── Merge into existing memory ─────────────────────────────────
  // Prebilling scanner MERGES — it doesn't overwrite appointments data.
  // Records already in memory are updated (isConfirmed refreshed from prebilling).
  // New records (not previously seen) are appended.
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    const mem = r._cc_billing_memory || { visits: [], savedAt: null };

    // Index existing records by visitId for O(1) update
    const byVisitId = {};
    mem.visits.forEach((v, i) => { if (v.visitId) byVisitId[v.visitId] = i; });

    let added = 0, updated = 0;
    allRecords.forEach(rec => {
      if (rec.visitId && rec.visitId in byVisitId) {
        Object.assign(mem.visits[byVisitId[rec.visitId]], rec);
        updated++;
      } else {
        if (rec.visitId) byVisitId[rec.visitId] = mem.visits.length;
        mem.visits.push(rec);
        added++;
      }
    });

    // Recompute aggregates
    const sortedDates = mem.visits.map(v => v.date).filter(Boolean).sort();
    mem.dateRange   = sortedDates.length
      ? sortedDates[0] + (sortedDates[sortedDates.length - 1] !== sortedDates[0]
          ? ' – ' + sortedDates[sortedDates.length - 1] : '')
      : '';
    mem.totalVisits = mem.visits.length;
    mem.savedAt     = new Date().toISOString();

    const unconf = mem.visits.filter(v => !v.isConfirmed).length;

    chrome.storage.local.set({ _cc_billing_memory: mem }, () => {
      if (btn) { btn.disabled = false; btn.textContent = '💾 Scan Prebilling & Remember'; }
      if (statusLbl) {
        statusLbl.textContent = `✓ ${allRecords.length} rows merged (${added} new · ${updated} updated) · ${unconf} unconfirmed · ${mem.dateRange}`;
        statusLbl.style.color = unconf > 0 ? '#ff8a80' : '#69f0ae';
      }
      updatePrebillingFloater(mem);
    });
  });
}

// Floater listing members with MULTIPLE unconfirmed (missed) visits and the
// total scheduled hours tied up in them — the clients most at risk of unbillable
// days. Built from prebilling/appointments records in billing memory.
function updatePrebillingFloater(mem) {
  const visits = (mem && mem.visits) || [];
  // Group unconfirmed/missed visits by member
  const byMember = {};
  visits.forEach(v => {
    const bad = (v.isConfirmed === false) || (v.status && v.status !== 'complete');
    if (!bad) return;
    const name = v.memberName || v.member || v.clientName || 'Unknown';
    const key = ccMemberKey(name);
    if (!byMember[key]) byMember[key] = { name, count: 0, mins: 0, dates: new Set() };
    byMember[key].count++;
    byMember[key].mins += (v.schedMins || 0);
    if (v.date) byMember[key].dates.add(v.date);
  });
  const multi = Object.values(byMember).filter(m => m.count >= 2)
    .sort((a, b) => b.count - a.count || b.mins - a.mins);

  let panel = document.getElementById('cc-prebill-floater');
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'cc-prebill-floater';
    panel.style.cssText = 'position:fixed;top:90px;right:20px;width:320px;max-height:70vh;z-index:2147483000;' +
      'background:#111318;border:1px solid #2a2e3d;border-radius:10px;box-shadow:0 8px 30px rgba(0,0,0,0.6);' +
      'font-family:Arial,sans-serif;color:#e0e0e0;display:flex;flex-direction:column;overflow:hidden;';
    const hdr = document.createElement('div');
    hdr.id = 'cc-pbf-header';
    hdr.style.cssText = 'background:#1a1d24;padding:9px 12px;font-size:12px;font-weight:bold;cursor:move;' +
      'display:flex;align-items:center;gap:8px;border-bottom:1px solid #2a2e3d;';
    hdr.innerHTML = '<span style="color:#ff8a80;">⚠ Multiple Missed Visits</span>' +
      '<button id="cc-pbf-close" style="margin-left:auto;background:none;border:none;color:#888;cursor:pointer;font-size:15px;">✕</button>';
    const body = document.createElement('div');
    body.id = 'cc-pbf-body';
    body.style.cssText = 'padding:10px 12px;overflow-y:auto;';
    const footer = document.createElement('div');
    footer.id = 'cc-pbf-footer';
    footer.style.cssText = 'padding:8px 12px;border-top:1px solid #2a2e3d;';
    footer.innerHTML = '<button id="cc-pbf-clear-memory" style="width:100%;background:transparent;color:#888;' +
      'border:1px dashed #444;border-radius:6px;padding:5px;font-size:10px;cursor:pointer;" ' +
      'title="Wipes all remembered visits from Scan/Import so nothing stale lingers. You\'ll need to re-scan before the next billability check.">' +
      '🗑 Clear Memory</button>';
    footer.querySelector('#cc-pbf-clear-memory').addEventListener('click', () => {
      if (!confirm('Clear all remembered visits (from Scan/Import)? You\'ll need to re-scan before the next billability check.')) return;
      chrome.storage.local.remove(['_cc_billing_memory'], () => updatePrebillingFloater(null));
    });
    panel.appendChild(hdr); panel.appendChild(body); panel.appendChild(footer);
    document.body.appendChild(panel);
    hdr.querySelector('#cc-pbf-close').addEventListener('click', () => panel.remove());
    // Drag
    let dr = false, ox = 0, oy = 0;
    hdr.addEventListener('mousedown', e => { if (e.target.id === 'cc-pbf-close') return; dr = true; ox = e.clientX - panel.offsetLeft; oy = e.clientY - panel.offsetTop; });
    document.addEventListener('mousemove', e => { if (!dr) return; panel.style.left = (e.clientX - ox) + 'px'; panel.style.top = (e.clientY - oy) + 'px'; panel.style.right = 'auto'; });
    document.addEventListener('mouseup', () => dr = false);
  }

  const body = panel.querySelector('#cc-pbf-body');
  if (!multi.length) {
    body.innerHTML = '<div style="color:#69f0ae;text-align:center;padding:14px 0;font-size:12px;">✅ No member has 2+ missed/unconfirmed visits.</div>';
    return;
  }
  const totalHrs = multi.reduce((s, m) => s + m.mins, 0);
  let html = '<div style="font-size:11px;color:#aaa;margin-bottom:8px;">' + multi.length +
    ' member(s) with 2+ missed visits · ' + fmtMins(totalHrs) + ' scheduled hrs at risk</div>';
  multi.forEach(m => {
    html += '<div style="background:#1a1d24;border-left:3px solid #ff5252;border-radius:4px;padding:7px 9px;margin-bottom:6px;">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;">' +
      '<span style="font-weight:bold;font-size:12px;color:#fff;">' + m.name + '</span>' +
      '<span style="background:#3a1a1a;color:#ff8a80;border-radius:10px;padding:1px 8px;font-size:11px;font-weight:bold;">' + m.count + ' missed</span></div>' +
      '<div style="font-size:10px;color:#999;margin-top:3px;">' + fmtMins(m.mins) + ' scheduled · ' + m.dates.size + ' day(s)</div></div>';
  });
  body.innerHTML = html;
}

function injectPrebillingBanner() {
  if (document.getElementById('cc-prebill-banner')) return;

  const banner = document.createElement('div');
  banner.id = 'cc-prebill-banner';
  banner.style.cssText = [
    'background:#c62828',
    'color:#fff',
    'font-family:Arial,sans-serif',
    'font-size:13px',
    'font-weight:700',
    'padding:10px 18px',
    'margin:8px 0 4px 0',
    'border-left:5px solid #7f0000',
    'border-radius:4px',
    'letter-spacing:0.2px',
    'box-shadow:0 2px 6px rgba(0,0,0,0.2)',
    'display:block',
    'box-sizing:border-box',
    'position:relative',
    'z-index:1',
    'line-height:1.5',
  ].join(';');

  banner.innerHTML = '<span style="font-size:16px;margin-right:8px;">⚠️</span><span>Timesheets / EVV visits must be submitted within <u>24–72 hours</u> after the shift or end of pay period. Failure to submit on time may result in claim denial.</span>';

  // Insert AFTER the page header, inside the content area — NOT at the very top
  // This avoids blocking the sticky nav dropdown menus
  const pageHeader = document.querySelector('.hhax-page-header');
  if (pageHeader && pageHeader.parentNode) {
    pageHeader.parentNode.insertBefore(banner, pageHeader.nextSibling);
    return;
  }
  const card = document.querySelector('.hhax-card');
  if (card) {
    card.parentNode.insertBefore(banner, card);
    return;
  }
  const main = document.querySelector('.hhax-main-content') || document.getElementById('mainContent') || document.body;
  main.appendChild(banner);
}

function injectEVVUrgencyBars() {
  // Remove any previously injected bar rows first
  document.querySelectorAll('.cc-evv-bar-row').forEach(el => el.remove());
  document.querySelectorAll('.cc-evv-bar').forEach(el => el.remove());

  const resultsDiv = document.getElementById('ctl00_ContentPlaceHolder1_divPrebillingReportInternalScroll');
  const iframe = document.getElementById('ctl00_ContentPlaceHolder1_iframe');

  let doc = document;
  if ((!resultsDiv || resultsDiv.innerHTML.trim().length < 100) && iframe && iframe.contentDocument && iframe.contentDocument.body) {
    doc = iframe.contentDocument;
  }

  const rows = Array.from(doc.querySelectorAll('table tr'));
  if (rows.length === 0) return;

  // Find date column index from header
  let dateColIdx = -1;
  rows.forEach(row => {
    if (dateColIdx !== -1) return;
    const ths = row.querySelectorAll('th');
    ths.forEach((th, idx) => {
      const t = th.innerText.trim().toLowerCase();
      if (t.includes('visit date') || t.includes('service date') || t === 'date') dateColIdx = idx;
    });
  });

  const now = new Date();
  const GRADIENT = 'linear-gradient(to right, #b7f5a0 0%, #fff176 25%, #ffd600 45%, #ff8f00 65%, #e53935 82%, #c62828 100%)';

  rows.forEach(row => {
    if (row.querySelector('th')) return;
    if (row.classList.contains('cc-evv-bar-row')) return;
    if (row.nextElementSibling && row.nextElementSibling.classList.contains('cc-evv-bar-row')) return;

    const cells = row.querySelectorAll('td');
    if (cells.length < 3) return;

    let visitDate = null;
    if (dateColIdx !== -1 && cells[dateColIdx]) {
      visitDate = parseDate(cells[dateColIdx].innerText.trim());
    }
    if (!visitDate) {
      Array.from(cells).forEach(cell => {
        if (visitDate) return;
        const m = cell.innerText.trim().match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/);
        if (m) visitDate = new Date(parseInt(m[3]), parseInt(m[1])-1, parseInt(m[2]));
      });
    }
    if (!visitDate) return;

    const visitMidnight = new Date(visitDate);
    visitMidnight.setHours(0,0,0,0);
    const hoursElapsed = (now - visitMidnight) / 3600000;
    if (hoursElapsed < 0) return;

    const MAX_HRS = 72;
    const pct = Math.min((hoursElapsed / MAX_HRS) * 100, 100);
    const isOverdue = hoursElapsed >= MAX_HRS;

    // ── Countdown label in the last cell ──────────────────────────
    const lastCell = cells[cells.length - 1];
    if (!lastCell.querySelector('.cc-evv-bar')) {
      const label = doc.createElement('div');
      label.className = 'cc-evv-bar';
      label.dataset.visitMidnight = visitMidnight.getTime();
      label.style.cssText = 'font-size:9px;font-family:monospace;font-weight:700;text-align:right;padding-top:2px;white-space:nowrap;';
      updateEVVLabel(label);
      lastCell.appendChild(label);
    }

    // ── Gradient bar row injected BELOW the data row ──────────────
    // This is the only reliable cross-browser way — a dedicated <tr>
    const barRow = doc.createElement('tr');
    barRow.className = 'cc-evv-bar-row';
    barRow.style.cssText = 'height:14px;padding:0;margin:0;';

    const barTd = doc.createElement('td');
    barTd.colSpan = cells.length;
    barTd.style.cssText = 'padding:0;margin:0;height:14px;border:none;position:relative;overflow:visible;';

    // Full gradient track
    const track = doc.createElement('div');
    track.style.cssText = [
      'width:100%', 'height:14px',
      'background:' + GRADIENT,
      'position:relative',
      'overflow:visible'
    ].join(';');

    // Bold vertical marker line — tall, black with white outline
    const marker = doc.createElement('div');
    marker.style.cssText = [
      'position:absolute',
      'top:-4px',
      'left:' + pct + '%',
      'width:5px',
      'height:22px',
      'background:#000',
      'transform:translateX(-50%)',
      'border-left:2px solid rgba(255,255,255,0.9)',
      'border-right:2px solid rgba(255,255,255,0.9)',
      'border-radius:2px',
      'z-index:10',
      'box-shadow:0 0 4px rgba(0,0,0,0.8)'
    ].join(';');
    track.appendChild(marker);

    // Overdue red overlay on right side past marker
    if (isOverdue) {
      const overdueOverlay = doc.createElement('div');
      overdueOverlay.style.cssText = 'position:absolute;top:0;right:0;width:100%;height:6px;background:rgba(127,0,0,0.35);';
      track.appendChild(overdueOverlay);
    }

    barTd.appendChild(track);
    barRow.appendChild(barTd);
    row.parentNode.insertBefore(barRow, row.nextSibling);
  });

  // ── Live-tick: update countdown labels every 60s ──────────────
  if (!window._ccEVVTick) {
    window._ccEVVTick = setInterval(() => {
      document.querySelectorAll('.cc-evv-bar[data-visit-midnight]').forEach(updateEVVLabel);
    }, 60000);
  }
}

function updateEVVLabel(lbl) {
  const remainingMs = (72 * 3600000) - (Date.now() - parseInt(lbl.dataset.visitMidnight));
  if (remainingMs <= 0) {
    const h = Math.floor(-remainingMs / 3600000);
    const m = Math.floor((-remainingMs % 3600000) / 60000);
    lbl.style.color = '#7f0000';
    lbl.textContent = '💥 ' + h + 'h ' + m + 'm OVERDUE';
  } else {
    const h = Math.floor(remainingMs / 3600000);
    const m = Math.floor((remainingMs % 3600000) / 60000);
    lbl.style.color = h < 12 ? '#b71c1c' : h < 24 ? '#e65100' : h < 48 ? '#f57f17' : '#555';
    lbl.textContent = '⏳ ' + h + 'h ' + m + 'm remaining';
  }
}

function buildEVVBarHTML(hoursElapsed) {
  const MAX_HOURS = 72;
  const pct = Math.min(hoursElapsed / MAX_HOURS * 100, 100);
  const isOverdue = hoursElapsed > MAX_HOURS;
  const hrs = Math.round(hoursElapsed);

  const gradient = 'linear-gradient(to right,#ffffff 0%,#fff176 35%,#ffd600 55%,#ff6f00 75%,#c62828 100%)';
  const trackStyle = 'display:block;width:100%;height:5px;background:' + gradient + ';position:relative;overflow:hidden;box-sizing:border-box;';

  if (isOverdue) {
    return '<div style="' + trackStyle + '">'
      + '<div style="position:absolute;right:0;top:0;height:5px;background:#7f0000;padding:0 3px;font-size:5px;font-family:monospace;font-weight:700;color:#fff;white-space:nowrap;line-height:5px;box-sizing:border-box;">💥' + hrs + 'h OVERDUE</div>'
      + '</div>';
  } else {
    return '<div style="' + trackStyle + '">'
      + '<div style="position:absolute;top:0;left:' + pct + '%;width:2px;height:5px;background:rgba(0,0,0,0.6);transform:translateX(-1px);"></div>'
      + '<div style="position:absolute;right:2px;top:0;font-size:5px;color:rgba(0,0,0,0.35);font-family:monospace;line-height:5px;white-space:nowrap;">' + hrs + 'h</div>'
      + '</div>';
  }
}

// ─── VISIT MAINTENANCE SCANNER ────────────────────────────────────

let vmScannerActive = false;
let _vmAllOverlaps = [];
let _vmAllDiffs = [];
let _vmTotalVisits = 0;
let _vmScanning = false;

function initVisitMaintenanceScanner() {
  if (vmScannerActive) return;
  vmScannerActive = true;

  // Mark as initialized
  const marker = document.createElement('div');
  marker.id = 'cc-vm-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  // Watch for search results to load
  const obs = new MutationObserver(() => {
    clearTimeout(window._ccVMTimer);
    window._ccVMTimer = setTimeout(() => {
      if (_vmScanning) return; // never interrupt an active scan
      const grid = document.querySelector('hhax-visit-table .ag-center-cols-container');
      if (grid && grid.children.length > 0 && !document.getElementById('cc-vm-panel')) {
        runVisitMaintenanceScan(false);
      }
    }, 1500);
  });
  const container = document.querySelector('hhax-visits-filter-result') || document.body;
  obs.observe(container, { childList: true, subtree: true });
}

function parseVMTime12h(str) {
  // Parse "08:56 PM" → minutes since midnight
  if (!str || str.includes('--')) return null;
  const m = str.match(/(\d+):(\d+)\s*(AM|PM)/i);
  if (!m) return null;
  let h = parseInt(m[1]), mn = parseInt(m[2]);
  const ampm = m[3].toUpperCase();
  if (ampm === 'PM' && h !== 12) h += 12;
  if (ampm === 'AM' && h === 12) h = 0;
  return h * 60 + mn;
}

function parseVMScheduleRange(str) {
  // Parse "09:00 PM - 12:00 AM" → {start, end} in minutes
  if (!str) return null;
  const parts = str.split('-').map(s => s.trim());
  if (parts.length < 2) return null;
  // Handle cross-midnight: combine back in case "-" splits AM/PM weirdly
  const full = str.trim();
  const m = full.match(/(\d+:\d+\s*(?:AM|PM))\s*[-–]\s*(\d+:\d+\s*(?:AM|PM))/i);
  if (!m) return null;
  let start = parseVMTime12h(m[1]);
  let end = parseVMTime12h(m[2]);
  if (start === null || end === null) return null;
  if (end <= start) end += 1440; // cross midnight
  return { start, end };
}

function scanVisitMaintenancePage() {
  const rows = Array.from(document.querySelectorAll('.ag-center-cols-container .ag-row'));
  const visits = [];
  const overlaps = [];
  const hourDiffs = [];

  rows.forEach(row => {
    try {
      // Date/Schedule column
      const dateCell = row.querySelector('[col-id="VisitDate"] hhax-grid-date-cell');
      if (!dateCell) return;
      const spans = Array.from(dateCell.querySelectorAll('span')).filter(s => s.textContent.trim());
      const dateStr = spans[0] ? spans[0].textContent.trim() : '';
      // Schedule range like "09:00 PM - 12:00 AM"
      const schedStr = spans[1] ? spans[1].textContent.trim() : '';
      // Scheduled duration like "3h 00m"
      const schedDurStr = spans[2] ? spans[2].textContent.trim() : '';

      // Visit Time column — actual EVV times
      const timeCell = row.querySelector('[col-id="VisitStartTime"] hhax-grid-time-cell');
      let actualStartStr = null, actualEndStr = null, actualDurStr = null;
      if (timeCell) {
        const boldSpans = Array.from(timeCell.querySelectorAll('.bold-text'));
        // Filter to ones that look like times (HH:MM AM/PM)
        const timeSpans = boldSpans.filter(s => /\d+:\d+\s*(AM|PM)/i.test(s.textContent));
        if (timeSpans.length >= 2) {
          actualStartStr = timeSpans[0].textContent.trim();
          actualEndStr = timeSpans[1].textContent.trim();
        }
        const durEl = timeCell.querySelector('.duration');
        if (durEl) actualDurStr = durEl.textContent.replace('Duration:', '').trim();
      }

      // Member (patient) — extract name AND admission ID
      const patientCell = row.querySelector('[col-id="Patient.PatientFirstName"] hhax-grid-patient-cell');
      let patientName = '', admissionId = '';
      if (patientCell) {
        const link = patientCell.querySelector('a');
        if (link) {
          patientName = link.textContent.trim();
          // PatientId from href: PatientId=19786071
          const pidM = (link.href || '').match(/PatientId=(\d+)/);
          if (pidM) admissionId = 'pid_' + pidM[1];
        }
        // Also grab Admsn. ID text like "FNE-900006" as fallback
        if (!admissionId) {
          const smallEls = patientCell.querySelectorAll('small');
          smallEls.forEach(sm => {
            if (sm.textContent.includes('Admsn') || sm.textContent.includes('FNE-') || sm.textContent.match(/\w+-\d+/)) {
              const nextSm = sm.nextElementSibling;
              if (nextSm) admissionId = nextSm.textContent.trim();
            }
          });
        }
        if (!admissionId) admissionId = patientName; // last resort
      }

      // Caregiver — extract name AND AideId from href
      const cgCell = row.querySelector('[col-id="Caregiver.CaregiverFirstName"] hhax-grid-caregiver-cell');
      let caregiverName = '', aideId = '';
      if (cgCell) {
        const link = cgCell.querySelector('a');
        if (link) {
          caregiverName = link.textContent.trim();
          // AideId from href: AideId=3891469
          const aidM = (link.href || '').match(/AideId=(\d+)/);
          if (aidM) aideId = 'aide_' + aidM[1];
        }
        if (!aideId) aideId = caregiverName; // last resort
      }

      // Visit Status — col-id confirmed as "VisitInfo.Status"
      let visitStatus = '';
      const statusCell = row.querySelector('[col-id="VisitInfo.Status"]');
      if (statusCell) visitStatus = statusCell.textContent.trim();

      // Raw numeric patientId from admissionId
      const rawPatientId = admissionId.replace('pid_', '');

      // Parse durations in minutes
      function parseDurToMins(s) {
        if (!s) return null;
        const mh = s.match(/(\d+)h\s*(\d+)m/);
        if (mh) return parseInt(mh[1]) * 60 + parseInt(mh[2]);
        const mm = s.match(/(\d+)m/);
        if (mm) return parseInt(mm[1]);
        return null;
      }

      const schedDurMins = parseDurToMins(schedDurStr);
      const actualDurMins = parseDurToMins(actualDurStr);
      const schedInterval = parseVMScheduleRange(schedStr);
      const actualStart = parseVMTime12h(actualStartStr);
      let actualEnd = parseVMTime12h(actualEndStr);
      if (actualEnd !== null && actualStart !== null && actualEnd <= actualStart) actualEnd += 1440;

      // Build visit object
      const visit = {
        dateStr, schedStr, schedDurMins, schedInterval,
        actualStartStr, actualEndStr, actualDurMins, actualStart, actualEnd,
        patientName, admissionId, rawPatientId, caregiverName, aideId,
        visitStatus,
        el: row
      };
      visits.push(visit);

      // ── Highlight logic ──────────────────────────────────────
      if (schedInterval && actualStart !== null && actualEnd !== null && actualDurMins !== null) {
        const inDiffMins = Math.abs(schedInterval.start - actualStart);
        const outDiffMins = Math.abs(schedInterval.end - actualEnd);
        const schedDur = schedInterval.end - schedInterval.start;
        const actualDur = actualEnd - actualStart;
        const durDiffMins = Math.abs(schedDur - actualDur);
        const maxDiff = Math.max(inDiffMins, outDiffMins);

        if (maxDiff > 15 || durDiffMins > 15) {
          let highlightColor = 'yellow';
          if (durDiffMins <= 15) {
            highlightColor = 'green';
          } else if (inDiffMins <= 15 && outDiffMins > 15) {
            highlightColor = 'yellow';  // purple retired — folded into yellow
          }

          // Push to diffs
          hourDiffs.push({
            caregiver: caregiverName,
            patient: patientName,
            date: dateStr,
            schedHrs: (schedDur / 60).toFixed(2),
            visitHrs: (actualDur / 60).toFixed(2),
            diffMins: Math.round(durDiffMins || maxDiff),
            over: actualDur > schedDur,
            highlightColor,
            el: row
          });

          // Apply row highlight
          if (highlightColor === 'purple') {
            row.style.setProperty('background', 'rgba(206,147,216,0.15)', 'important');
            row.style.setProperty('outline', '2px solid #ce93d8', 'important');
          } else if (highlightColor === 'green') {
            row.style.setProperty('background', 'rgba(102,187,106,0.15)', 'important');
            row.style.setProperty('outline', '2px solid #66bb6a', 'important');
          } else {
            row.style.setProperty('background', 'rgba(255,214,0,0.12)', 'important');
            row.style.setProperty('outline', '2px solid #ffd600', 'important');
          }
        }
      }
    } catch(e) {}
  });

  // ── Overlap detection ──
  // Group by caregiver + date
  const cgDayMap = {};
  // Group by patient + date (two caregivers at same time)
  const patDayMap = {};

  visits.forEach(v => {
    if (!v.aideId || !v.dateStr) return;
    const dateKey = v.dateStr.replace(/\W+/g,'');

    // Same caregiver overlaps — key by AIDE ID (not name, avoids false positives with same-name caregivers)
    const cgKey = v.aideId + '_' + dateKey;
    if (!cgDayMap[cgKey]) cgDayMap[cgKey] = [];
    if (v.schedInterval) cgDayMap[cgKey].push(v);

    // Same patient, two caregivers — key by ADMISSION/PATIENT ID (not name)
    if (v.admissionId) {
      const patKey = v.admissionId.replace(/\W+/g,'') + '_' + dateKey;
      if (!patDayMap[patKey]) patDayMap[patKey] = [];
      if (v.schedInterval) patDayMap[patKey].push(v);
    }
  });

  function detectOverlaps(map, type) {
    Object.values(map).forEach(group => {
      if (group.length < 2) return;
      for (let i = 0; i < group.length; i++) {
        for (let j = i + 1; j < group.length; j++) {
          const a = group[i], b = group[j];
          const oStart = Math.max(a.schedInterval.start, b.schedInterval.start);
          const oEnd = Math.min(a.schedInterval.end, b.schedInterval.end);
          const oMins = oEnd - oStart;
          if (oMins >= 8) {
            overlaps.push({
              caregiver: type === 'cg' ? a.caregiverName : `${a.caregiverName} & ${b.caregiverName}`,
              date: a.dateStr,
              client1: type === 'cg' ? a.patientName : a.patientName,
              time1: a.schedStr,
              visit1: a.actualStartStr && a.actualEndStr ? `${a.actualStartStr} - ${a.actualEndStr}` : null,
              client2: type === 'cg' ? b.patientName : b.patientName,
              time2: b.schedStr,
              visit2: b.actualStartStr && b.actualEndStr ? `${b.actualStartStr} - ${b.actualEndStr}` : null,
              overlapMins: Math.round(oMins),
              type,
              elA: a.el, elB: b.el
            });
            a.el.style.setProperty('outline', '2px solid #ff4444', 'important');
            a.el.style.setProperty('background', 'rgba(255,68,68,0.12)', 'important');
            b.el.style.setProperty('outline', '2px solid #ff4444', 'important');
            b.el.style.setProperty('background', 'rgba(255,68,68,0.12)', 'important');
          }
        }
      }
    });
  }

  detectOverlaps(cgDayMap, 'cg');
  detectOverlaps(patDayMap, 'pat');

  return { overlaps, hourDiffs, totalVisits: visits.length, visits };
}

function runVisitMaintenanceScan(resetAccumulated) {
  if (resetAccumulated) {
    _vmAllOverlaps = [];
    _vmAllDiffs = [];
    _vmTotalVisits = 0;
  }

  // Clear old highlights
  document.querySelectorAll('.ag-center-cols-container .ag-row').forEach(row => {
    row.style.removeProperty('background');
    row.style.removeProperty('outline');
  });

  const results = scanVisitMaintenancePage();

  // Accumulate results across pages
  _vmAllOverlaps = _vmAllOverlaps.concat(results.overlaps);
  _vmAllDiffs = _vmAllDiffs.concat(results.hourDiffs);
  _vmTotalVisits += results.totalVisits;

  // Remove old panel and show new
  const old = document.getElementById('cc-vm-panel');
  if (old) old.remove();

  injectApptPanel({
    overlaps: _vmAllOverlaps,
    hourDiffs: _vmAllDiffs,
    totalVisits: _vmTotalVisits,
    panelId: 'cc-vm-panel',
    title: '⚕ Care Crafter — Visit Maintenance'
  });

  // Add "Scan All Pages" button to footer
  const footer = document.getElementById('cc-vm-panel-footer');
  if (footer && !footer.querySelector('#cc-vm-scan-all')) {
    const scanAllBtn = document.createElement('button');
    scanAllBtn.id = 'cc-vm-scan-all';
    scanAllBtn.textContent = '📄 Scan All Pages';
    scanAllBtn.style.cssText = 'background:#1a3a1a;color:#69f0ae;border:1px solid #2a5a2a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;';
    scanAllBtn.addEventListener('click', () => scanAllVMPages());
    footer.insertBefore(scanAllBtn, footer.firstChild);
  }
}

async function scanAllVMPages() {
  if (_vmScanning) return;
  _vmScanning = true;
  _vmAllOverlaps = [];
  _vmAllDiffs = [];
  _vmTotalVisits = 0;

  const scanAllBtn = document.getElementById('cc-vm-scan-all');
  if (scanAllBtn) { scanAllBtn.textContent = '⏳ Scanning...'; scanAllBtn.disabled = true; }

  // Go to first page
  const firstBtn = document.querySelector('hhax-status-panel-pagination button[aria-label="Go to first page"]');
  if (firstBtn && !firstBtn.classList.contains('hhax-btn-disabled')) {
    firstBtn.click();
    await new Promise(r => setTimeout(r, 1500));
  }

  let pageNum = 1;
  while (true) {
    // Clear old highlights on this page
    document.querySelectorAll('.ag-center-cols-container .ag-row').forEach(row => {
      row.style.removeProperty('background');
      row.style.removeProperty('outline');
    });

    const results = scanVisitMaintenancePage();
    _vmAllOverlaps = _vmAllOverlaps.concat(results.overlaps);
    _vmAllDiffs = _vmAllDiffs.concat(results.hourDiffs);
    _vmTotalVisits += results.totalVisits;

    if (scanAllBtn) scanAllBtn.textContent = `⏳ Page ${pageNum}...`;

    // Try next page
    const nextBtn = document.querySelector('hhax-status-panel-pagination button[aria-label="Go to next page"]');
    if (!nextBtn || nextBtn.classList.contains('hhax-btn-disabled')) break;
    nextBtn.click();
    pageNum++;
    await new Promise(r => setTimeout(r, 1800));
  }

  _vmScanning = false;

  // Show accumulated results
  const old = document.getElementById('cc-vm-panel');
  if (old) old.remove();

  injectApptPanel({
    overlaps: _vmAllOverlaps,
    hourDiffs: _vmAllDiffs,
    totalVisits: _vmTotalVisits,
    panelId: 'cc-vm-panel',
    title: `⚕ Care Crafter — Visit Maintenance (All ${pageNum} pages)`
  });

  // Re-add scan all button
  const footer = document.getElementById('cc-vm-panel-footer');
  if (footer && !footer.querySelector('#cc-vm-scan-all')) {
    const btn2 = document.createElement('button');
    btn2.id = 'cc-vm-scan-all';
    btn2.textContent = '📄 Scan All Pages';
    btn2.style.cssText = 'background:#1a3a1a;color:#69f0ae;border:1px solid #2a5a2a;border-radius:5px;padding:4px 10px;font-size:11px;cursor:pointer;margin-right:8px;';
    btn2.addEventListener('click', () => scanAllVMPages());
    footer.insertBefore(btn2, footer.firstChild);
  }
}

// ─── START ────────────────────────────────────────────────────────
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

// ─── APPOINTMENTS: SCAN ALL & REMEMBER ───────────────────────────

function injectApptRememberBtn() {
  if (document.getElementById('cc-appt-remember-wrap')) return;

  // Find anchor — try above the grid or near the search button
  const anchor = document.querySelector('.hhax-calendar-search-panel, #ctl00_ContentPlaceHolder1_uxBtnSearch, .hhax-search-panel');
  const gridWrap = document.getElementById('divPatientCalendarGrid-container') ||
                   document.getElementById('divCaregiverCalendarGrid-container');
  const insertTarget = anchor ? anchor.parentNode : (gridWrap ? gridWrap.parentNode : null);
  const insertBefore = anchor ? anchor.nextSibling : gridWrap;
  if (!insertTarget) return;

  const wrap = document.createElement('div');
  wrap.id = 'cc-appt-remember-wrap';
  wrap.style.cssText = 'display:flex;align-items:center;gap:10px;padding:6px 0;margin-bottom:4px;flex-wrap:wrap;';

  const btn = document.createElement('button');
  btn.id = 'cc-appt-remember-btn';
  btn.textContent = '💾 Scan All & Remember';
  btn.title = 'Scan all visits on this appointments grid and save to billing memory for use on the Add Internal Batch Invoice page';
  btn.style.cssText = 'background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;border-radius:5px;padding:5px 13px;font-size:12px;font-weight:bold;cursor:pointer;';

  const statusLbl = document.createElement('span');
  statusLbl.id = 'cc-appt-remember-status';
  statusLbl.style.cssText = 'font-size:11px;color:#aaa;';

  chrome.storage.local.get(['_cc_billing_memory'], r => {
    if (r._cc_billing_memory) {
      const d      = r._cc_billing_memory;
      const unconf = d.visits.filter(v => !v.isConfirmed).length;
      const ageMs  = Date.now() - new Date(d.savedAt).getTime();
      const ageHrs = Math.floor(ageMs / 3600000);
      const staleWarn = ageMs > 6 * 3600000 ? ` ⏰ ${ageHrs}h old` : '';
      const range  = d.dateRange ? ` · ${d.dateRange}` : '';
      statusLbl.textContent = `Saved ${new Date(d.savedAt).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'})} ${new Date(d.savedAt).toLocaleDateString()}${range} · ${d.totalVisits} visits · ${unconf} unconfirmed${staleWarn}`;
      statusLbl.style.color = (unconf > 0 || ageMs > 6 * 3600000) ? '#ff8a80' : '#69f0ae';
    }
  });

  btn.addEventListener('click', () => scanApptAndRemember(btn, statusLbl));
  wrap.appendChild(btn);
  wrap.appendChild(statusLbl);
  insertTarget.insertBefore(wrap, insertBefore);
}

async function scanApptAndRemember(btn, statusLbl) {
  if (window._ccApptScanning) return;
  window._ccApptScanning = true;

  btn.textContent = '⏳ Scrolling...';
  btn.disabled = true;
  statusLbl.style.color = '#aaa';
  statusLbl.textContent = 'Scrolling to load all visits...';

  const patientGrid   = document.getElementById('divPatientCalendarGrid-container');
  const caregiverGrid = document.getElementById('divCaregiverCalendarGrid-container');
  const activeGrid = (patientGrid  && patientGrid.children.length > 0) ? patientGrid  :
                     (caregiverGrid && caregiverGrid.children.length > 0) ? caregiverGrid : null;

  if (!activeGrid) {
    btn.textContent = '💾 Scan All & Remember';
    btn.disabled = false;
    statusLbl.style.color = '#f59e0b';
    statusLbl.textContent = '⚠ No grid found — run a search first';
    window._ccApptScanning = false;
    return;
  }

  const scrollEl = activeGrid.querySelector('.cg-container-wrap') || activeGrid;

  // ── FIX 1 (CRITICAL): Collect visits AT EACH scroll step, not after scrolling back.
  // The Appointments grid uses a virtualizing renderer — DOM nodes are recycled as
  // you scroll. If we scroll back to the top and collect, we only capture the first
  // screenful. We must snapshot every viewport as we pass through it.
  const allRecords = [];
  const seenKeys   = new Set();

  function collectVisibleVisits() {
    activeGrid.querySelectorAll('.cg-visit-item').forEach(block => {
      const visitId = block.getAttribute('data-visit-id') || '';

      const rowContainer = block.closest('.cg-row-container');
      if (!rowContainer) return;

      const calCell = block.closest('[data-date-value]');
      if (!calCell) return;
      const rawDate = calCell.getAttribute('data-date-value');
      if (!rawDate) return;

      // ── FIX 3: Prefer data-patient-id on .cg-patient-cell; fall back to data-row-id
      const patientCellEl = rowContainer.querySelector('.cg-patient-cell[data-patient-id]');
      const patientId = (patientCellEl ? patientCellEl.getAttribute('data-patient-id') : null)
                        || rowContainer.getAttribute('data-row-id');
      if (!patientId) return;

      const cgDiv        = block.querySelector('[data-caregiver-id]');
      const caregiverId  = cgDiv ? (cgDiv.getAttribute('data-caregiver-id') || '') : '';
      const caregiverName = cgDiv ? ((cgDiv.querySelector('.cg-text-link, span') || {}).textContent || '').trim() : '';

      // Dedup key: visitId if available, otherwise patient+date+caregiver combo
      const dedupKey = visitId || (patientId + '_' + rawDate + '_' + caregiverId + '_' + caregiverName);
      if (seenKeys.has(dedupKey)) return;
      seenKeys.add(dedupKey);

      const dm = rawDate.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      const dateNorm = dm ? dm[1].padStart(2,'0') + '/' + dm[2].padStart(2,'0') + '/' + dm[3] : rawDate;

      let clientName = '', clientFne = '';
      const patCell = rowContainer.querySelector('.cg-patient-cell a.cg-word-break-string');
      if (patCell) {
        const full = patCell.textContent.trim();
        clientName = full.split('\n')[0].trim();
        const fneM = full.match(/(FNE-\d+)/i);
        if (fneM) clientFne = fneM[1].toUpperCase();
      }

      const confirmedMinute = parseInt(block.getAttribute('data-confirmedminute') || '0');
      const scheduledMinute = parseInt(block.getAttribute('data-scheduledminute') || '0');

      // ── EVV confirmation check: use THREE independent signals ──
      // The virtualizing grid recycles DOM nodes during scroll, so child elements
      // like .cg-visit-evv spans may not be rendered when the snapshot is taken.
      // We therefore treat any ONE of three signals as sufficient proof of confirmation:
      //   1. confirmedFromTotal — [data-visittotal-id] text shows C:XX:XX > 0
      //      (HHAeXchange only calculates confirmed minutes after full EVV in+out)
      //   2. confirmedMinute > 0 — data-confirmedminute attribute > 0 (same meaning)
      //   3. hasFullEVV — both .cg-visit-evv spans present with non-zero times
      //      (clock-in AND clock-out both recorded)
      // Using AND between confirmed-minutes and hasFullEVV was wrong: a confirmed
      // visit whose EVV spans weren't rendered yet would be stored as unconfirmed,
      // causing the billing page to block it even after it was fully confirmed.
      const evvSpans = block.querySelectorAll('.cg-visit-evv');
      const evvIn    = evvSpans.length >= 1 ? evvSpans[0].textContent.trim() : '';
      const evvOut   = evvSpans.length >= 2 ? evvSpans[1].textContent.trim() : '';
      const hasFullEVV = evvIn  !== '' && evvIn  !== '0000'
                      && evvOut !== '' && evvOut !== '0000';

      // [data-visittotal-id] "S:05:00  C:05:03" — confirmed minutes from total element
      const totalEl = block.querySelector('[data-visittotal-id]');
      let confirmedFromTotal = false;
      if (totalEl) {
        const cm = totalEl.textContent.match(/C:(\d+):(\d+)/);
        if (cm) confirmedFromTotal = (parseInt(cm[1]) * 60 + parseInt(cm[2])) > 0;
      }

      // Any one signal is sufficient — OR instead of AND
      const isConfirmed = confirmedFromTotal || confirmedMinute > 0 || hasFullEVV;

      allRecords.push({
        patientId, date: dateNorm, caregiverName, caregiverId,
        clientName, memberName: clientName, clientFne, fne: clientFne, visitId,
        schedMins:     scheduledMinute || null,
        confirmedMins: confirmedMinute || null,
        status:        isConfirmed ? 'Completed' : 'Prebilling',
        isConfirmed
      });
    });
  }

  // Collect initial viewport before any scrolling
  scrollEl.scrollTop = 0;
  await new Promise(r => setTimeout(r, 500));
  collectVisibleVisits();

  // Scroll down in steps — collect at EACH step so no virtualizer rows are missed
  const scrollStep = 300;
  let lastScrollTop = -1;
  let stuckCount = 0;

  while (true) {
    scrollEl.scrollTop += scrollStep;
    await new Promise(r => setTimeout(r, 200)); // 200ms gives virtualizer time to render

    collectVisibleVisits(); // snapshot every viewport as we pass through

    if (scrollEl.scrollTop === lastScrollTop) {
      stuckCount++;
      if (stuckCount >= 3) break; // reached bottom
    } else {
      stuckCount = 0;
    }
    lastScrollTop = scrollEl.scrollTop;

    const pct = Math.round((scrollEl.scrollTop / (scrollEl.scrollHeight - scrollEl.clientHeight || 1)) * 100);
    btn.textContent = `⏳ ${Math.min(pct, 99)}%...`;
    statusLbl.textContent = `Found ${allRecords.length} visits...`;
  }

  window._ccApptScanning = false;

  if (allRecords.length === 0) {
    btn.textContent = '💾 Scan All & Remember';
    btn.disabled = false;
    statusLbl.style.color = '#f59e0b';
    statusLbl.textContent = '⚠ No visits found — run a search first';
    return;
  }

  const unconfirmed  = allRecords.filter(v => !v.isConfirmed).length;
  const sortedDates  = allRecords.map(v => v.date).filter(Boolean).sort();
  const dateRangeStr = sortedDates.length
    ? sortedDates[0] + (sortedDates[sortedDates.length - 1] !== sortedDates[0] ? ' – ' + sortedDates[sortedDates.length - 1] : '')
    : '';

  // Merge into existing memory (don't overwrite) — a Prebilling scan may have
  // already populated memberName/clientFne for these same visitIds, and
  // clobbering the whole blob here was wiping that data out from under
  // "Export for Billing" on the Prebilling page.
  chrome.storage.local.get(['_cc_billing_memory'], r => {
    const mem = r._cc_billing_memory || { visits: [] };
    const byVisitId = {};
    mem.visits.forEach((v, i) => { if (v.visitId) byVisitId[v.visitId] = i; });

    allRecords.forEach(rec => {
      if (rec.visitId && rec.visitId in byVisitId) {
        Object.assign(mem.visits[byVisitId[rec.visitId]], rec);
      } else {
        if (rec.visitId) byVisitId[rec.visitId] = mem.visits.length;
        mem.visits.push(rec);
      }
    });

    const sortedAll = mem.visits.map(v => v.date).filter(Boolean).sort();
    mem.dateRange   = sortedAll.length
      ? sortedAll[0] + (sortedAll[sortedAll.length - 1] !== sortedAll[0] ? ' – ' + sortedAll[sortedAll.length - 1] : '')
      : '';
    mem.totalVisits = mem.visits.length;
    mem.savedAt     = new Date().toISOString();

  chrome.storage.local.set({ _cc_billing_memory: mem }, () => {
    btn.style.background  = '#1a3a1a';
    btn.style.color       = '#69f0ae';
    btn.style.borderColor = '#2a5a2a';
    btn.textContent = `✅ ${allRecords.length} visits saved`;
    btn.disabled = false;

    const sl = document.getElementById('cc-appt-remember-status');
    if (sl) {
      sl.style.color  = unconfirmed > 0 ? '#ff8a80' : '#69f0ae';
      sl.textContent  = `${allRecords.length} visits · ${unconfirmed} unconfirmed · ${dateRangeStr}`;
    }

    // Improvement: if the billing page is already open in this tab, auto-refresh overlay
    if (document.querySelector('.hhax-table-billing-grid')) {
      setTimeout(runBatchInvoiceOverlay, 600);
    }

    setTimeout(() => {
      btn.style.background  = '#0f3460';
      btn.style.color       = '#90caf9';
      btn.style.borderColor = '#2a4a8a';
      btn.textContent = '💾 Scan All & Remember';
    }, 5000);
  });
  });
}

// ─── BILLING PAGE OVERLAY ─────────────────────────────────────────

function normDate(d) { return (d || '').replace(/\D/g, ''); }

function ccMemoryAgeLabel(savedAt) {
  if (!savedAt) return '—';
  const mins = Math.round((Date.now() - new Date(savedAt).getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm old';
  return Math.round(mins / 60) + 'h old';
}

function parseHrsToMins(s) {
  // "04:00" or "4:00" → minutes
  if (!s) return null;
  const m = s.trim().match(/^(\d+):(\d+)$/);
  if (!m) return null;
  return parseInt(m[1]) * 60 + parseInt(m[2]);
}

function fmtMins(m) {
  // 90 → "+1h 30m", -15 → "-15m"
  const sign = m >= 0 ? '+' : '-';
  const abs = Math.abs(m);
  const h = Math.floor(abs / 60);
  const mn = abs % 60;
  return h > 0 ? `${sign}${h}h${mn > 0 ? ' ' + mn + 'm' : ''}` : `${sign}${mn}m`;
}


// ── Helper: execute __doPostBack in page context via background script ──
function ccDoPostBack(target) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action: 'doPostBack', target }, () => resolve());
  });
}
function initBatchInvoiceOverlay() {
  const marker = document.createElement('div');
  marker.id = 'cc-billing-init';
  marker.style.display = 'none';
  document.body.appendChild(marker);

  setTimeout(runBatchInvoiceOverlay, 1000);

  // Re-run on page postbacks (classic ASP full reload on paging). Ignore
  // mutations that originate from inside our own floater panel — otherwise
  // every DOM change we make (button text, status line, etc.) is treated as
  // a "grid changed" event and triggers a rebuild that overwrites the very
  // feedback we just showed the user, ~800ms later, before they can see it.
  const obs = new MutationObserver(muts => {
    if (window._ccBillingScanning) return; // don't interfere with active scan
    const ownPanel = document.getElementById('cc-billing-floater');
    const external = muts.some(m => !ownPanel || !ownPanel.contains(m.target));
    if (!external) return;
    clearTimeout(window._ccBillingTimer);
    window._ccBillingTimer = setTimeout(() => {
      if (document.querySelector('.hhax-table-billing-grid')) runBatchInvoiceOverlay();
    }, 800);
  });
  obs.observe(document.body, { childList: true, subtree: true });
}

// Normalize a member name for cross-page matching: uppercase, collapse spaces,
// strip punctuation. Appointments / Prebilling / Billing all print the name a
// little differently, so we key client-days on this.
function ccMemberKey(name) {
  return String(name || '').toUpperCase().replace(/[^A-Z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
}

// Read the current billing grid into row records.
// Signature of the current billing page's row set — used to detect whether
// clicking "Add to Batch & Go to Next Page" actually moved to a new page,
// since that's the only reliable "we're on the last page" signal available
// without confirmed info on how the last page renders differently.
function ccBillingPageSignature() {
  return Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr input.hidVisitID'))
    .map(el => el.value).join(',');
}

// Checks every row's checkbox EXCEPT rows already crossed out as unbillable
// (cc-billing-crossed from Import & Cross Out, cc-billing-flagged from the
// live blocking overlay) — deliberately never touches a "select all" master
// checkbox, since that would also select the red/unbillable rows.
function ccCheckBillableRowsOnPage() {
  let checked = 0, skipped = 0;
  document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
    const cb = tr.querySelector('input[type="checkbox"]');
    if (!cb || cb.disabled) return;
    const isBad = tr.classList.contains('cc-billing-crossed') || tr.classList.contains('cc-billing-flagged');
    if (isBad) { skipped++; return; }
    if (!cb.checked) cb.click();
    checked++;
  });
  return { checked, skipped };
}

// Repeatedly: check every billable row on the current page, click "Add to
// Batch & Go to Next Page", wait for the grid to actually refresh, repeat —
// until a click produces no page change (best available last-page signal)
// or nothing billable is left to check for two pages running.
async function ccAutoBatchAllPages(onProgress, abortState) {
  let pages = 0, totalChecked = 0, totalSkipped = 0, emptyStreak = 0;
  const MAX_PAGES = 300;
  while (pages < MAX_PAGES) {
    if (abortState && abortState.stop) return { pages, totalChecked, totalSkipped, stopped: 'user' };
    const before = ccBillingPageSignature();
    if (!before) return { pages, totalChecked, totalSkipped, stopped: 'no-grid' };

    const { checked, skipped } = ccCheckBillableRowsOnPage();
    pages++; totalChecked += checked; totalSkipped += skipped;
    if (onProgress) onProgress(pages, totalChecked, totalSkipped);

    if (checked === 0) {
      emptyStreak++;
      if (emptyStreak >= 2) return { pages, totalChecked, totalSkipped, stopped: 'nothing-billable' };
    } else {
      emptyStreak = 0;
    }

    const btn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnSaveAndNextKafka');
    if (!btn) return { pages, totalChecked, totalSkipped, stopped: 'no-button' };
    const barBefore = document.getElementById('cc-billing-bar');
    btn.click();

    // Wait for the grid's row set to actually change (ASP.NET postback).
    let changed = false;
    for (let i = 0; i < 75; i++) { // ~15s max
      await new Promise(r => setTimeout(r, 200));
      if (abortState && abortState.stop) return { pages, totalChecked, totalSkipped, stopped: 'user' };
      const after = ccBillingPageSignature();
      if (after && after !== before) { changed = true; break; }
    }
    if (!changed) return { pages, totalChecked, totalSkipped, stopped: 'last-page' };

    // The grid itself refreshes fast, but the extension's own "🧠 Care
    // Crafter Memory Active" bar + red-flagging pass takes a few seconds to
    // re-run on the freshly loaded page. injectBillingMemoryBar() always
    // removes the old #cc-billing-bar and creates a brand-new element, so
    // waiting for that element identity to change is a precise signal that
    // flagging genuinely finished — not a guessed fixed delay.
    if (onProgress) onProgress(pages, totalChecked, totalSkipped, true);
    let barRefreshed = false;
    for (let i = 0; i < 100; i++) { // ~20s max
      await new Promise(r => setTimeout(r, 200));
      if (abortState && abortState.stop) return { pages, totalChecked, totalSkipped, stopped: 'user' };
      const barNow = document.getElementById('cc-billing-bar');
      if (barNow && barNow !== barBefore) { barRefreshed = true; break; }
    }
    // If the bar never refreshed (e.g. this HHAeXchange instance has no
    // memory saved at all, so the bar never renders), fall back to a short
    // flat pause rather than blocking forever.
    if (!barRefreshed) await new Promise(r => setTimeout(r, 3000));
  }
  return { pages, totalChecked, totalSkipped, stopped: 'max-pages' };
}

// Confirms, then runs ccAutoBatchAllPages with a small live-progress widget
// (bottom-right corner, doesn't block the page) with a Stop button, since
// this creates real batch entries across every page — not something to run
// silently in the background without the user watching it happen.
function ccRunAutoBatchUI() {
  if (!confirm('This will check every BILLABLE row (skipping anything crossed out red) on every page and click ' +
    '"Add to Batch & Go to Next Page" repeatedly until the last page. This adds real entries to the batch. Continue?')) return;

  document.getElementById('cc-autobatch-widget')?.remove();
  const box = document.createElement('div');
  box.id = 'cc-autobatch-widget';
  box.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:2147483600;font-family:Arial,sans-serif;' +
    'background:#0f2a1a;color:#e0e0e0;border:1px solid #2a6a3a;border-radius:10px;padding:12px 16px;width:300px;' +
    'box-shadow:0 8px 40px rgba(0,0,0,0.6);';
  box.innerHTML = `
    <div style="font-weight:bold;font-size:12px;color:#69f0ae;margin-bottom:6px;">☑ Auto-Batch — starting...</div>
    <div id="cc-autobatch-line" style="font-size:11px;color:#aaa;">Page 0 · 0 added · 0 skipped (red)</div>
    <button id="cc-autobatch-stop" style="margin-top:8px;width:100%;background:#333;color:#ccc;border:none;border-radius:6px;padding:6px;font-size:11px;cursor:pointer;">Stop</button>
  `;
  document.body.appendChild(box);
  const abortState = { stop: false };
  box.querySelector('#cc-autobatch-stop').onclick = () => { abortState.stop = true; };

  ccAutoBatchAllPages((pages, checked, skipped, settling) => {
    box.querySelector('#cc-autobatch-line').textContent = settling
      ? `Page ${pages} done · waiting for 🧠 memory bar to reload...`
      : `Page ${pages} · ${checked} added · ${skipped} skipped (red)`;
  }, abortState).then(result => {
    const reasons = {
      'last-page': '✅ Done — reached the last page.',
      'nothing-billable': '✅ Done — no more billable rows found.',
      'user': '⏹ Stopped by user.',
      'no-grid': '⚠ Billing grid not found.',
      'no-button': '⚠ "Add to Batch & Go to Next Page" button not found on this page.',
      'max-pages': '⚠ Stopped — hit the 300-page safety limit.'
    };
    box.querySelector('div').textContent = reasons[result.stopped] || 'Done.';
    box.querySelector('#cc-autobatch-line').textContent =
      `${result.pages} page(s) · ${result.totalChecked} added to batch · ${result.totalSkipped} skipped (red)`;
    box.querySelector('#cc-autobatch-stop').textContent = 'Close';
    box.querySelector('#cc-autobatch-stop').onclick = () => box.remove();
  });
}

function ccCollectBillingRows() {
  const out = [];
  document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
    const tds = tr.querySelectorAll('td');
    if (tds.length < 5) return;
    const dateText = tds[1] ? tds[1].textContent.trim() : '';
    if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;
    const hid = tr.querySelector('input.hidVisitID');
    const fneM = tds[3] ? tds[3].textContent.match(/(FNE-\d+)/i) : null;
    out.push({
      tr,
      visitId: hid ? hid.value : null,
      date: (dateText.match(/(\d{2}\/\d{2}\/\d{4})/) || [])[1] || '',
      caregiver: tds[2] ? tds[2].textContent.trim() : '',
      fne: fneM ? fneM[1].toUpperCase() : '',
      member: tds[4] ? tds[4].textContent.trim() : '',
      visitHrs: tds[8] ? tds[8].textContent.trim() : ''
    });
  });
  return out;
}

// Import Appointments/Prebilling export(s) → cross out unbillable client-days.
// A client-day is unbillable if ANY of that client's visits that day is missed
// (no clock-in/out, from Appointments) or unconfirmed (from Prebilling). When
// so, EVERY billing row for that client on that day is struck out red.
function ccBillingImportCrossOut(files, statusEl, fileNames) {
  // Two independent key spaces: FNE code (stable, exact across pages) is
  // preferred; member-name key is a fallback for records with no FNE.
  const badDaysFne = new Set();   // FNE + '|' + normDate(date)
  const badDaysName = new Set();  // ccMemberKey(member) + '|' + normDate(date)
  const reasons = {};             // key -> Set of reason strings
  let filesLeft = files.length, parsedVisits = 0;

  const log = (...a) => console.log('[CC-IMPORT]', ...a);
  let badVisits = 0, fileErrors = [];
  log('starting import,', files.length, 'file(s)');

  Array.from(files).forEach(file => {
    const reader = new FileReader();
    reader.onload = e => {
      try {
        const data = JSON.parse(e.target.result);
        const visits = (data && data.visits) || [];
        log('file', file.name, '— visits array length:', visits.length, 'source field:', data.source);
        visits.forEach(v => {
          parsedVisits++;
          // Decide if this visit is "bad" from whichever source it came from.
          // Prebilling Review lists ALL visits in the search range, confirmed
          // and unconfirmed alike — being on the report is not itself a
          // problem, only isConfirmed:false actually means it can't be billed.
          let bad = false, why = '';
          if (v.status && v.status !== 'complete') { bad = true; why = ccMissedLabel(v.status); }            // appointments
          else if (v.isConfirmed === false) { bad = true; why = v.source === 'prebilling' ? 'Unconfirmed (Prebilling Review)' : 'Unconfirmed'; }
          else if (v.bad === true) { bad = true; why = v.badReason || 'Flagged'; }                           // future/explicit
          if (!bad) return;
          badVisits++;
          const dateKey = normDate(v.date);
          const fne = (v.fne || v.clientFne || '').toUpperCase().trim();
          const nameKey = ccMemberKey(v.member || v.memberName || v.clientName) + '|' + dateKey;
          if (fne) { const k = fne + '|' + dateKey; badDaysFne.add(k); (reasons[k] = reasons[k] || new Set()).add(why); }
          badDaysName.add(nameKey);
          (reasons[nameKey] = reasons[nameKey] || new Set()).add(why);
        });
      } catch (err) {
        fileErrors.push(file.name + ': ' + err.message);
        log('ERROR parsing', file.name, err);
      }
      if (--filesLeft === 0) applyCrossOut();
    };
    reader.onerror = () => { fileErrors.push(file.name + ': could not read file'); if (--filesLeft === 0) applyCrossOut(); };
    reader.readAsText(file);
  });

  // The file names the user picked, shown in the status line so it's always
  // clear which export is currently loaded — persisted via window._ccImportStatus
  // so it survives the floater's frequent background rebuilds.
  const fileLabel = fileNames ? 'File: ' + fileNames + ' — ' : '';

  function setStatus(text, color) {
    window._ccImportStatus = { text: fileLabel + text, color };
    if (statusEl) { statusEl.textContent = window._ccImportStatus.text; statusEl.style.color = color; }
  }

  function applyCrossOut() {
    try {
      log('parsed', parsedVisits, 'total visits,', badVisits, 'flagged bad,',
          badDaysFne.size, 'unique FNE-day keys,', badDaysName.size, 'unique name-day keys');
      if (fileErrors.length) {
        setStatus('⚠ ' + fileErrors.join(' · '), '#ff8a80');
        return;
      }
      // Persist the parsed rules so they auto-reapply on every billing page
      // (pagination, postbacks) without needing to re-upload the same files
      // every time. Reasons' Sets don't survive JSON — flatten to arrays.
      const reasonsArr = {};
      Object.keys(reasons).forEach(k => { reasonsArr[k] = [...reasons[k]]; });
      chrome.storage.local.set({
        _cc_import_crossout: {
          badDaysFne: [...badDaysFne], badDaysName: [...badDaysName], reasons: reasonsArr,
          fileLabel, parsedVisits, badVisits, savedAt: new Date().toISOString()
        }
      });
      const { struck, struckDays, rowsFound } = ccApplyCrossOutToPage(badDaysFne, badDaysName, reasons);
      log('billing grid rows found:', rowsFound, '— struck', struck, 'rows across', struckDays, 'client-days');
      if (!rowsFound) {
        setStatus('⚠ No billing rows on this page to mark. (Is the grid loaded?)', '#ff8a80');
        return;
      }
      setStatus(
        struck
          ? '🚫 Crossed out ' + struck + ' billing row(s) across ' + struckDays + ' unbillable client-day(s). (' + parsedVisits + ' visits imported, ' + badVisits + ' flagged bad — auto-applies on other pages too)'
          : '✓ Imported ' + parsedVisits + ' visits (' + badVisits + ' flagged bad) — none matched a client-day on THIS page.',
        struck ? '#ff8a80' : '#69f0ae'
      );
    } catch (err) {
      log('ERROR in applyCrossOut', err);
      setStatus('❌ ' + err.message, '#ff8a80');
    }
  }
}

// Shared row-crossing logic — used both right after an import, and to
// silently auto-reapply previously-imported rules on every subsequent
// billing page (pagination/postbacks) without re-uploading.
function ccApplyCrossOutToPage(badDaysFne, badDaysName, reasons) {
  const rows = ccCollectBillingRows();
  if (!rows.length) return { struck: 0, struckDays: 0, rowsFound: 0 };
  let struck = 0; const struckDays = new Set();
  rows.forEach(r => {
    const dateKey = normDate(r.date);
    const fneKey = r.fne ? (r.fne + '|' + dateKey) : null;
    const nameKey = ccMemberKey(r.member) + '|' + dateKey;
    const key = (fneKey && badDaysFne.has(fneKey)) ? fneKey
              : badDaysName.has(nameKey) ? nameKey
              : null;
    if (!key) return;
    struck++; struckDays.add(key);
    const tr = r.tr;
    tr.style.setProperty('background', 'rgba(255,68,68,0.16)', 'important');
    tr.style.setProperty('outline', '2px solid #ff4444', 'important');
    tr.classList.add('cc-billing-crossed');
    tr.querySelectorAll('td').forEach(td => td.style.setProperty('text-decoration', 'line-through', 'important'));
    const why = reasons[key] ? (reasons[key] instanceof Set ? [...reasons[key]] : reasons[key]).join('; ') : 'missed/unconfirmed';
    tr.title = '🚫 CANNOT BILL — ' + r.member + ' on ' + r.date +
               '\nAnother visit for this client that day is missed/unconfirmed (' + why + ').' +
               '\nThe whole client-day is unbillable.';
  });
  return { struck, struckDays: struckDays.size, rowsFound: rows.length };
}

// Called on every billing-page render (init, pagination, postbacks) to
// silently reapply whatever was last imported, so the user only has to
// upload the export files once per session instead of on every page.
function ccReapplyStoredCrossOut() {
  chrome.storage.local.get(['_cc_import_crossout'], r => {
    const d = r._cc_import_crossout;
    if (!d) return;
    const badDaysFne = new Set(d.badDaysFne || []);
    const badDaysName = new Set(d.badDaysName || []);
    const { struck, struckDays, rowsFound } = ccApplyCrossOutToPage(badDaysFne, badDaysName, d.reasons || {});
    if (!rowsFound) return;
    window._ccImportStatus = {
      text: (d.fileLabel || '') + (struck
        ? '🚫 Crossed out ' + struck + ' billing row(s) across ' + struckDays + ' unbillable client-day(s). (' + d.parsedVisits + ' visits imported, ' + d.badVisits + ' flagged bad — auto-applies on other pages too)'
        : '✓ Imported ' + d.parsedVisits + ' visits (' + d.badVisits + ' flagged bad) — none matched a client-day on THIS page.'),
      color: struck ? '#ff8a80' : '#69f0ae'
    };
    const statusEl = document.getElementById('cc-bf-import-status');
    if (statusEl) { statusEl.textContent = window._ccImportStatus.text; statusEl.style.color = window._ccImportStatus.color; }
  });
}

function runBatchInvoiceOverlay() {
  // Clean up previous run
  document.querySelectorAll('.cc-billing-warn, .cc-diff-cell, .cc-diff-header').forEach(e => e.remove());
  document.querySelectorAll('tr.cc-billing-flagged').forEach(tr => {
    tr.style.removeProperty('background');
    tr.style.removeProperty('outline');
    tr.classList.remove('cc-billing-flagged');
  });
  document.querySelectorAll('.cc-billing-chk-disabled').forEach(chk => {
    chk.disabled = false; chk.classList.remove('cc-billing-chk-disabled');
  });

  chrome.storage.local.get(['_cc_billing_memory'], result => {
    const mem = result._cc_billing_memory;
    injectBillingMemoryBar(mem);
    injectBillingFloater(mem);
    ccReapplyStoredCrossOut(); // auto-reapply last Import result on this page (pagination/postbacks)

    // Inject "Diff" column header
    const thead = document.querySelector('.hhax-table-billing-grid thead tr, .hhax-table-billing-grid tbody tr:first-child[style*="bold"]');
    const thVisitHrs = Array.from(document.querySelectorAll('.hhax-table-billing-grid th')).find(th => th.textContent.trim() === 'Visit Hrs');
    if (thVisitHrs && !document.querySelector('.cc-diff-header')) {
      const thDiff = document.createElement('th');
      thDiff.className = 'cc-diff-header';
      thDiff.textContent = 'Diff';
      thDiff.style.cssText = 'text-align:left;color:#90caf9;font-size:11px;white-space:nowrap;';
      thVisitHrs.parentNode.insertBefore(thDiff, thVisitHrs.nextSibling);
    }

    if (!mem || !mem.visits || !mem.visits.length) {
      // No memory — add empty diff cells so table stays aligned
      document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
        const tds = tr.querySelectorAll('td');
        if (tds.length < 5) return;
        const tdDiff = document.createElement('td');
        tdDiff.className = 'cc-diff-cell';
        tdDiff.style.cssText = 'font-size:10px;color:#555;';
        tdDiff.textContent = '—';
        const visitHrsTd = tds[8]; // Visit Hrs is col index 8 (0-based: chk,date,cg,admid,member,office,mco,visit,visitHrs...)
        if (visitHrsTd) visitHrsTd.parentNode.insertBefore(tdDiff, visitHrsTd.nextSibling);
      });
      return;
    }

    // Build TWO lookups:
    // 1. visitId → record (exact match via hidden input)
    // 2. patientId+dateNorm → [records] (fallback for unconfirmed blocking)
    const visitLookup = {};   // visitId → record
    const patDateLookup = {}; // patientId_date → [records]
    mem.visits.forEach(v => {
      if (v.visitId) visitLookup[v.visitId] = v;
      const key = v.patientId + '_' + normDate(v.date);
      if (!patDateLookup[key]) patDateLookup[key] = [];
      patDateLookup[key].push(v);
    });

    const diffRows = []; // for floater summary
    let missingFromMemory = 0; // rows where visitId not found in memory

    const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 5) return;

      const dateText = (tds[1] ? tds[1].textContent.trim() : '');
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;

      // PatientId from link
      const patientLink = tr.querySelector('a[href*="PatientId="], a[onclick*="PatientId="]');
      if (!patientLink) return;
      const src = patientLink.href || patientLink.getAttribute('onclick') || '';
      const pidM = src.match(/PatientId=(\d+)/);
      if (!pidM) return;
      const patientId = pidM[1];

      // VisitId from hidden input — exact match key
      const hidVisit = tr.querySelector('input.hidVisitID');
      const visitId = hidVisit ? hidVisit.value : null;

      // Caregiver name from col 2 (for display in tooltip)
      const cgName = tds[2] ? tds[2].textContent.trim() : '';

      // Actual visit hrs from col 8 (Visit Hrs: "04:00")
      const visitHrsTd = tds[8];
      const actualHrsStr = visitHrsTd ? visitHrsTd.textContent.trim() : '';
      const actualMins = parseHrsToMins(actualHrsStr);

      // Member name from col 4
      const memberName = tds[4] ? tds[4].textContent.trim() : '';

      // Exact record by visitId (same visit ID on appt page data-visit-id)
      const exactRecord = visitId ? visitLookup[visitId] : null;

      // All records for this patient+date (for unconfirmed blocking check)
      const patDateKey = patientId + '_' + normDate(dateText);
      const patDateMatched = patDateLookup[patDateKey];

      // ── Diff cell — use exactRecord for precise sched hrs ──
      const tdDiff = document.createElement('td');
      tdDiff.className = 'cc-diff-cell';
      tdDiff.style.cssText = 'font-size:11px;font-weight:bold;white-space:nowrap;';

      if (exactRecord && actualMins !== null && exactRecord.schedMins) {
        const schedMins = exactRecord.schedMins;
        const diffMins = actualMins - schedMins;
        const absDiff = Math.abs(diffMins);
        const schedLabel = `${Math.floor(schedMins/60)}h${schedMins%60>0?' '+schedMins%60+'m':''}`;
        tdDiff.title = `Sched: ${schedLabel} / Actual: ${actualHrsStr} / DCW ID: ${exactRecord.caregiverId||'?'}`;
        if (absDiff < 5) {
          tdDiff.style.color = '#69f0ae';
          tdDiff.textContent = '✓';
        } else {
          tdDiff.style.color = diffMins > 0 ? '#ff8a80' : '#ffd740';
          tdDiff.textContent = fmtMins(diffMins);
          if (absDiff >= 15) {
            diffRows.push({ caregiver: cgName, caregiverId: exactRecord.caregiverId, member: memberName, date: dateText, diff: diffMins, actual: actualHrsStr, sched: schedMins });
          }
        }
      } else {
        tdDiff.style.color = '#555';
        tdDiff.textContent = '—';
        if (!exactRecord) {
          missingFromMemory++;
          tdDiff.title = 'Visit not found in memory — re-scan Appointments page';
        } else {
          tdDiff.title = 'No scheduled hours saved for this visit';
        }
      }

      if (visitHrsTd) visitHrsTd.parentNode.insertBefore(tdDiff, visitHrsTd.nextSibling);

      // ── Flag unconfirmed rows ──
      // Cross-DCW blocking only needs patDateMatched (other DCWs on same patient+date).
      // exactRecord is used for "own visit unconfirmed" check, but absence of it must
      // NOT skip the cross-DCW check — if another DCW is unconfirmed we still block.
      if (!patDateMatched) return;

      // Use caregiverId from exactRecord when available; fall back to name from billing row.
      const thisCaregiversId = exactRecord ? exactRecord.caregiverId : null;

      // Compare by ID when both sides have one (most reliable).
      // Fall back to normalized-name comparison when IDs are missing so unconfirmed
      // DCWs without IDs are still caught.
      const normCgStr = s => (s || '').trim().toUpperCase().replace(/\s+/g, ' ');
      const unconfirmed = patDateMatched.filter(v => {
        if (v.isConfirmed) return false;
        if (thisCaregiversId && v.caregiverId) return v.caregiverId !== thisCaregiversId;
        // At least one side is missing an ID — fall back to name
        return normCgStr(v.caregiverName) !== normCgStr(cgName);
      });

      // Also block if THIS DCW's own visit is unconfirmed (requires exactRecord)
      const thisVisitUnconfirmed = exactRecord ? !exactRecord.isConfirmed : false;

      if (unconfirmed.length === 0 && !thisVisitUnconfirmed) return;

      tr.style.setProperty('background', 'rgba(255,68,68,0.13)', 'important');
      tr.style.setProperty('outline', '2px solid #ff4444', 'important');
      tr.classList.add('cc-billing-flagged');

      // FIX Bug 1: Build a complete warn message that shows BOTH issues when
      // both apply — this visit is unconfirmed AND another DCW is also blocking.
      const warnParts = [];
      if (thisVisitUnconfirmed) {
        warnParts.push(`⚠ This visit is unconfirmed\n   Patient: ${memberName}\n   DCW: ${cgName}${exactRecord.caregiverId ? ' (ID: ' + exactRecord.caregiverId + ')' : ''}`);
      }
      if (unconfirmed.length > 0) {
        const names  = [...new Set(unconfirmed.map(v => v.caregiverName))].filter(Boolean).join(', ') || 'Unknown DCW';
        const idList = [...new Set(unconfirmed.map(v => v.caregiverId).filter(Boolean))].join(', ');
        warnParts.push(`🚫 Cannot bill — another DCW is unconfirmed on this date\n   Patient: ${memberName}\n   Blocking DCW: ${names}${idList ? ' (ID: ' + idList + ')' : ''}`);
      }
      const warnMsg = warnParts.join('\n');

      const warn = document.createElement('span');
      warn.className = 'cc-billing-warn';
      warn.textContent = ' 🚫';
      warn.title = warnMsg;
      warn.style.cssText = 'cursor:help;font-size:13px;';
      tds[1].appendChild(warn);

      const chk = tr.querySelector('input[type="checkbox"]');
      if (chk) { chk.disabled = true; chk.classList.add('cc-billing-chk-disabled'); chk.title = warnMsg; }
    });

    // Update floater with diff summary + missing count
    window._ccBillingMissing = missingFromMemory;
    injectBillingMemoryBar(mem); // re-render bar with fresh missing count
    updateBillingFloater(mem, diffRows);
  });
}

function injectBillingMemoryBar(mem) {
  const old = document.getElementById('cc-billing-bar');
  if (old) old.remove();
  const bar = document.createElement('div');
  bar.id = 'cc-billing-bar';
  const resultsDiv = document.getElementById('ctl00_ContentPlaceHolder1_uxtblSearchResults');
  if (!resultsDiv) return;

  if (!mem || !mem.visits || !mem.visits.length) {
    bar.style.cssText = 'background:#1a1a0d;border:1px solid #f59e0b;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#f59e0b;display:flex;align-items:center;gap:8px;';
    bar.innerHTML = '<span style="font-size:16px;">⚠️</span><span><b>Care Crafter:</b> No visit memory saved. Go to <b>Appointments</b> page, run a search, then click <b>💾 Scan All & Remember</b>.</span>';
    resultsDiv.parentNode.insertBefore(bar, resultsDiv);
    return;
  }

  const dt       = new Date(mem.savedAt);
  const ageMs    = Date.now() - dt.getTime();
  const ageHrs   = Math.floor(ageMs / 3600000);
  const stale    = ageMs > 6 * 3600000; // >6 hours old
  const unconf   = mem.visits.filter(v => !v.isConfirmed).length;
  const missing  = window._ccBillingMissing || 0;
  const dateRange = mem.dateRange || '';

  // Check if any billing row dates fall outside memory's date coverage
  const memDateSet = new Set(mem.visits.map(v => normDate(v.date)));
  const billingDates = new Set();
  document.querySelectorAll('.hhax-table-billing-grid tbody tr').forEach(tr => {
    const tds = tr.querySelectorAll('td');
    if (tds.length < 2) return;
    const m = tds[1].textContent.match(/(\d{2}\/\d{2}\/\d{4})/);
    if (m) billingDates.add(normDate(m[1]));
  });
  const outOfRange = [...billingDates].filter(d => !memDateSet.has(d));
  const dateMismatch = outOfRange.length > 0;

  let parts = [];
  parts.push(`<b>Care Crafter Memory Active</b>`);
  parts.push(`${mem.totalVisits} visits`);
  if (dateRange) parts.push(`<span style="color:#aaa;">${dateRange}</span>`);
  parts.push(`saved ${dt.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})} on ${dt.toLocaleDateString()}`);
  if (unconf > 0) parts.push(`<span style="color:#ff6b6b;font-weight:bold;">${unconf} unconfirmed → 🚫 blocked</span>`);
  if (missing > 0) parts.push(`<span style="color:#ffd740;">⚠ ${missing} billing rows not in memory — re-scan Appointments</span>`);

  if (stale || dateMismatch) {
    bar.style.cssText = 'background:#1a1200;border:1px solid #f59e0b;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#f59e0b;display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
    let warn = '';
    if (stale)        warn += ` ⏰ Memory is ${ageHrs}h old — re-scan Appointments for accuracy.`;
    if (dateMismatch) warn += ` 📅 Billing dates not covered by memory (${outOfRange.length} date(s)) — re-scan to include them.`;
    bar.innerHTML = `<span style="font-size:16px;">🧠</span><span>${parts.join(' · ')}</span><span style="color:#f59e0b;font-size:11px;">${warn}</span>`;
  } else {
    bar.style.cssText = 'background:#0d1a0d;border:1px solid #2a5a2a;border-radius:6px;padding:8px 14px;margin-bottom:10px;font-size:12px;color:#69f0ae;display:flex;align-items:center;gap:8px;flex-wrap:wrap;';
    bar.innerHTML = `<span style="font-size:16px;">🧠</span><span>${parts.join(' · ')}</span>`;
  }

  resultsDiv.parentNode.insertBefore(bar, resultsDiv);
}

function injectBillingFloater(mem) {
  if (document.getElementById('cc-billing-floater')) return;

  const savedPos = JSON.parse(localStorage.getItem('_cc_billing_floater_pos') || 'null');
  let savedSize = JSON.parse(localStorage.getItem('_cc_billing_floater_size') || 'null');
  // A size saved while the panel was minimized (just the header, ~40px tall)
  // would otherwise get restored as a fixed height on the next load and make
  // the panel look like it vanished. Ignore anything unreasonably short.
  if (savedSize && savedSize.h < 100) { savedSize = null; localStorage.removeItem('_cc_billing_floater_size'); }

  const panel = document.createElement('div');
  panel.id = 'cc-billing-floater';
  panel.style.cssText = `
    position:fixed; z-index:999999;
    top:${savedPos ? savedPos.top + 'px' : '70px'};
    left:${savedPos ? savedPos.left + 'px' : 'auto'};
    right:${savedPos ? 'auto' : '16px'};
    width:${savedSize ? savedSize.w + 'px' : '340px'};
    min-width:240px; min-height:80px; max-height:80vh;
    background:#1a1a2e; color:#e0e0e0;
    border-radius:10px; box-shadow:0 4px 24px rgba(0,0,0,0.6);
    border:1px solid #334; font-family:'Segoe UI',monospace; font-size:12px;
    overflow:hidden; resize:both;
    ${savedSize ? `height:${savedSize.h}px;` : ''}
  `;

  panel.innerHTML = `
    <div id="cc-bf-header" style="background:linear-gradient(135deg,#0f3460,#16213e);
      padding:10px 14px;display:flex;justify-content:space-between;align-items:center;
      border-radius:10px 10px 0 0;cursor:move;user-select:none;">
      <span style="font-weight:bold;font-size:13px;">💊 Care Crafter — Billing</span>
      <div style="display:flex;gap:10px;align-items:center;">
        <span id="cc-bf-minimize" style="font-size:11px;color:#aaa;cursor:pointer;" title="Minimize">─</span>
        <span id="cc-bf-close" style="cursor:pointer;font-size:16px;color:#aaa;" title="Close">✕</span>
      </div>
    </div>
    <div id="cc-bf-body" style="overflow-y:auto;max-height:calc(80vh - 80px);padding:10px 14px;">
      <div id="cc-bf-content" style="color:#aaa;text-align:center;padding:16px 0;">
        <div style="font-size:20px;">🔍</div>
        <div style="margin-top:6px;font-size:11px;">Loading billing analysis...</div>
      </div>
    </div>
  `;

  document.body.appendChild(panel);

  // Event delegation — scan button survives innerHTML updates
  panel.querySelector('#cc-bf-body').addEventListener('click', e => {
    if (e.target.id === 'cc-bf-scan-all' || e.target.closest('#cc-bf-scan-all')) {
      const btn = document.getElementById('cc-bf-scan-all');
      const status = document.getElementById('cc-bf-scan-status');
      if (btn) { btn.textContent = '⏳ Starting...'; btn.disabled = true; btn.style.background = '#1a3a1a'; btn.style.color = '#69f0ae'; }
      if (status) status.textContent = 'Injecting scan into page...';
      // Run scan in MAIN world so it survives ASP.NET postbacks
      chrome.runtime.sendMessage({ action: 'runBillingScanInPage' }, () => {
        // Poll for results from MAIN world scan
        const poll = setInterval(() => {
          if (!window._ccPageScanResults?.done) return;
          clearInterval(poll);

          const r = window._ccPageScanResults;
          window._ccPageScanResults = null;

          chrome.storage.local.get(['_cc_billing_memory'], result => {
            const mem = result._cc_billing_memory;

            // Build lookups from memory
            const visitLookup   = {};
            const patDateLookup = {};
            if (mem && mem.visits) {
              mem.visits.forEach(v => {
                if (v.visitId) visitLookup[v.visitId] = v;
                const key = v.patientId + '_' + normDate(v.date);
                if (!patDateLookup[key]) patDateLookup[key] = [];
                patDateLookup[key].push(v);
              });
            }

            // Process each scanned row
            let totalBlocked = 0;
            const allDiffs = [];
            const seen = new Set();

            r.rows.forEach(row => {
              const exactRecord = row.visitId ? visitLookup[row.visitId] : null;
              const patDateKey  = row.patientId + '_' + normDate(row.date);
              const patDateMatched = patDateLookup[patDateKey];
              const thisId = exactRecord ? exactRecord.caregiverId : null;

              // Check blocked
              if (patDateMatched) {
                const unconf = patDateMatched.filter(v => {
                  if (v.isConfirmed) return false;
                  if (!thisId || !v.caregiverId) return v.caregiverName !== row.caregiver;
                  return v.caregiverId !== thisId;
                });
                const thisUnconf = exactRecord && !exactRecord.isConfirmed;
                if ((unconf.length > 0 || thisUnconf) && !seen.has(row.visitId)) {
                  seen.add(row.visitId);
                  totalBlocked++;
                }
              }

              // Check diff
              const actualMins = parseHrsToMins(row.visitHrs);
              if (exactRecord && actualMins !== null && exactRecord.schedMins) {
                const diffMins = actualMins - exactRecord.schedMins;
                if (Math.abs(diffMins) >= 15) {
                  allDiffs.push({
                    caregiver:   row.caregiver,
                    caregiverId: exactRecord.caregiverId,
                    member:      row.member,
                    date:        row.date,
                    diff:        diffMins,
                    actual:      row.visitHrs,
                    sched:       exactRecord.schedMins
                  });
                }
              }
            });

            window._ccBillingScanData = {
              totalRows: r.totalRows,
              pages:     r.pages,
              blocked:   totalBlocked,
              diffs:     allDiffs
            };

            updateBillingFloater(mem, allDiffs);
          });
        }, 1000);
        setTimeout(() => clearInterval(poll), 600000);
      });
    }
  });

  // ── Import button (delegated so it survives innerHTML updates) ──
  panel.querySelector('#cc-bf-body').addEventListener('click', e => {
    if (e.target.id === 'cc-bf-import' || e.target.closest('#cc-bf-import')) {
      const fi = document.getElementById('cc-bf-import-file');
      if (fi) fi.click();
    } else if (e.target.id === 'cc-bf-clear-memory' || e.target.closest('#cc-bf-clear-memory')) {
      if (!confirm('Clear all remembered visits (from Scan/Import)? You\'ll need to re-scan before the next billability check.')) return;
      chrome.storage.local.remove(['_cc_billing_memory'], () => {
        window._ccImportStatus = null;
        runBatchInvoiceOverlay();
      });
    } else if (e.target.id === 'cc-bf-autobatch' || e.target.closest('#cc-bf-autobatch')) {
      ccRunAutoBatchUI();
    }
  });
  panel.querySelector('#cc-bf-body').addEventListener('change', e => {
    if (e.target.id === 'cc-bf-import-file') {
      const n = e.target.files ? e.target.files.length : 0;
      const statusEl = document.getElementById('cc-bf-import-status');
      if (n > 0) {
        const names = Array.from(e.target.files).map(f => f.name).join(', ');
        window._ccImportStatus = { text: '⏳ Reading: ' + names + '...', color: '#90caf9' };
        if (statusEl) { statusEl.textContent = window._ccImportStatus.text; statusEl.style.color = window._ccImportStatus.color; }
        ccBillingImportCrossOut(e.target.files, statusEl, names);
      }
      e.target.value = '';
    }
  });

  // Save size — but never while minimized, or the collapsed (~40px) height
  // gets persisted and restores as a squashed, effectively invisible panel.
  let minimized = false;
  const ro = new ResizeObserver(() => {
    if (minimized) return;
    const h = panel.offsetHeight;
    if (h < 100) return;
    localStorage.setItem('_cc_billing_floater_size', JSON.stringify({ w: panel.offsetWidth, h }));
  });
  ro.observe(panel);

  // Draggable
  let isDragging = false, dragX = 0, dragY = 0;
  const header = panel.querySelector('#cc-bf-header');
  header.addEventListener('mousedown', e => {
    if (['cc-bf-close','cc-bf-minimize'].includes(e.target.id)) return;
    isDragging = true;
    dragX = e.clientX - panel.getBoundingClientRect().left;
    dragY = e.clientY - panel.getBoundingClientRect().top;
    panel.style.right = 'auto';
  });
  document.addEventListener('mousemove', e => {
    if (!isDragging) return;
    const left = e.clientX - dragX;
    const top  = e.clientY - dragY;
    panel.style.left = left + 'px';
    panel.style.top  = top  + 'px';
    localStorage.setItem('_cc_billing_floater_pos', JSON.stringify({ left, top }));
  });
  document.addEventListener('mouseup', () => { isDragging = false; });

  // Minimize
  panel.querySelector('#cc-bf-minimize').addEventListener('click', e => {
    e.stopPropagation();
    minimized = !minimized;
    const body = panel.querySelector('#cc-bf-body');
    if (minimized) {
      panel.dataset.fullH = panel.offsetHeight + 'px';
      body.style.overflow = 'hidden'; body.style.height = '0'; body.style.padding = '0';
      panel.style.height = 'auto'; panel.style.maxHeight = 'none'; panel.style.minHeight = '0'; panel.style.resize = 'none';
    } else {
      body.style.overflow = ''; body.style.height = ''; body.style.padding = '';
      panel.style.height = panel.dataset.fullH || ''; panel.style.maxHeight = '80vh'; panel.style.minHeight = '80px'; panel.style.resize = 'both';
    }
    panel.querySelector('#cc-bf-minimize').textContent = minimized ? '□' : '─';
  });

  panel.querySelector('#cc-bf-close').addEventListener('click', () => panel.remove());
}

function updateBillingFloater(mem, diffRows) {
  const content = document.getElementById('cc-bf-content');
  if (!content) return;

  if (!mem || !mem.visits) {
    content.innerHTML = `<div style="color:#f59e0b;text-align:center;padding:12px;">⚠ No memory loaded</div>`;
    return;
  }

  // ── Same-name DCW detection from memory ──
  // Group by caregiverName → collect unique caregiverIds
  const nameToIds = {};
  mem.visits.forEach(v => {
    if (!v.caregiverName) return;
    const name = v.caregiverName.trim();
    if (!nameToIds[name]) nameToIds[name] = new Set();
    if (v.caregiverId) nameToIds[name].add(v.caregiverId);
  });
  const duplicateNames = Object.entries(nameToIds).filter(([, ids]) => ids.size > 1);

  const flagged   = document.querySelectorAll('tr.cc-billing-flagged').length;
  const scanData  = window._ccBillingScanData || null;

  let html = '';

  // ── Stats row ──
  const totalScanned = scanData ? scanData.totalRows : '?';
  const blockedCount = scanData ? scanData.blocked : flagged;
  const diffCount    = scanData ? scanData.diffs.length : diffRows.length;
  const activeDiffs  = scanData ? scanData.diffs : diffRows;

  html += `
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:5px;margin-bottom:10px;">
      <div style="background:#0d1a0d;border:1px solid #2a5a2a;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#69f0ae;">${totalScanned}</div>
        <div style="font-size:9px;color:#aaa;">visits scanned</div>
      </div>
      <div style="background:#1a0f0f;border:1px solid #ff4444;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#ff6b6b;">${blockedCount}</div>
        <div style="font-size:9px;color:#aaa;">blocked rows</div>
      </div>
      <div style="background:#1a1600;border:1px solid #ffd740;border-radius:6px;padding:6px;text-align:center;">
        <div style="font-size:18px;font-weight:bold;color:#ffd740;">${diffCount}</div>
        <div style="font-size:9px;color:#aaa;">time diffs</div>
      </div>
    </div>`;

  // ── Same-name DCW warning ──
  if (duplicateNames.length > 0) {
    html += `<div style="background:#1a0d1a;border:1px solid #ce93d8;border-radius:6px;padding:8px 10px;margin-bottom:10px;">
      <div style="color:#ce93d8;font-weight:bold;font-size:11px;margin-bottom:6px;">⚠ SAME NAME — DIFFERENT DCW ID</div>`;
    duplicateNames.forEach(([name, ids]) => {
      // Count visits per caregiverId for this name
      const idCounts = {};
      mem.visits.filter(v => v.caregiverName && v.caregiverName.trim() === name).forEach(v => {
        const id = v.caregiverId || 'unknown';
        idCounts[id] = (idCounts[id] || 0) + 1;
      });
      html += `<div style="margin-bottom:6px;">
        <div style="color:#e0e0e0;font-weight:bold;font-size:11px;">${name}</div>`;
      Object.entries(idCounts).forEach(([id, count]) => {
        html += `<div style="display:flex;justify-content:space-between;padding:2px 8px;font-size:10px;color:#aaa;">
          <span>ID: <span style="color:#ce93d8;font-weight:bold;">${id}</span></span>
          <span style="color:#e0e0e0;">${count} visit${count>1?'s':''}</span>
        </div>`;
      });
      html += `</div>`;
    });
    html += `</div>`;
  }

  // ── Scan all pages button ──
  html += `<div style="margin-bottom:10px;">
    <button id="cc-bf-scan-all" style="width:100%;background:#0f3460;color:#90caf9;border:1px solid #2a4a8a;
      border-radius:6px;padding:7px;font-size:11px;font-weight:bold;cursor:pointer;">
      📄 Scan All Billing Pages
    </button>
    <div id="cc-bf-scan-status" style="font-size:10px;color:#888;text-align:center;margin-top:4px;">
      ${scanData ? `Last scan: ${scanData.totalRows} visits across ${scanData.pages} pages` : 'Scans all pages automatically'}
    </div>
  </div>`;

  // ── Import Appointments/Prebilling exports → cross out unbillable client-days ──
  // Status persists in window._ccImportStatus across floater rebuilds (the panel
  // rebuilds itself often — anything not persisted here gets wiped every time).
  const impSt = window._ccImportStatus;
  html += `<div style="margin-bottom:4px;">
    <button id="cc-bf-import" style="width:100%;background:#3a1a1a;color:#ff8a80;border:1px solid #7a2a2a;
      border-radius:6px;padding:7px;font-size:11px;font-weight:bold;cursor:pointer;">📥 Import Appointments/Prebilling &amp; Cross Out</button>
    <input type="file" id="cc-bf-import-file" accept=".json" multiple style="display:none;">
  </div>
  <div id="cc-bf-import-status" style="font-size:10px;color:${impSt ? impSt.color : '#888'};text-align:center;margin:2px 0 6px;">
    ${impSt ? impSt.text : 'Upload the Appointments and/or Prebilling export — any client-day with a missed or unconfirmed visit gets struck out here.'}
  </div>
  <button id="cc-bf-clear-memory" style="width:100%;background:transparent;color:#888;border:1px dashed #444;
    border-radius:6px;padding:5px;font-size:10px;cursor:pointer;margin-bottom:10px;"
    title="Wipes all remembered visits from Scan/Import so nothing stale lingers. You'll need to re-scan before the next check.">
    🗑 Clear Memory (${mem ? mem.visits.length : 0} visits, ${mem ? ccMemoryAgeLabel(mem.savedAt) : '—'})
  </button>`;

  // ── Auto-batch all pages (only on Add Internal Batch Invoice) ──
  if (document.getElementById('ctl00_ContentPlaceHolder1_uxBtnSaveAndNextKafka')) {
    html += `<div style="margin-bottom:10px;">
      <button id="cc-bf-autobatch" style="width:100%;background:#0f2a1a;color:#69f0ae;border:1px solid #2a6a3a;
        border-radius:6px;padding:7px;font-size:11px;font-weight:bold;cursor:pointer;">☑ Add All Billable to Batch (All Pages)</button>
      <div id="cc-bf-autobatch-status" style="font-size:10px;color:#888;text-align:center;margin-top:4px;">
        Checks every row EXCEPT red/crossed-out ones, clicks "Add to Batch &amp; Go to Next Page", repeats until the last page.
      </div>
    </div>`;
  }

  // ── Time diffs ──
  if (activeDiffs.length > 0) {
    html += `<div style="color:#ffd740;font-weight:bold;font-size:11px;margin-bottom:6px;">⚠ TIME DIFFERENCES ≥15min</div>`;
    activeDiffs.forEach(d => {
      const col   = d.diff > 0 ? '#ff8a80' : '#ffd740';
      const arrow = d.diff > 0 ? '↑ Over' : '↓ Under';
      const schedH = Math.floor(Math.abs(d.sched)/60);
      const schedM = d.sched % 60;
      html += `
        <div style="background:#1a1600;border-left:3px solid ${col};border-radius:4px;padding:6px 9px;margin-bottom:5px;">
          <div style="display:flex;justify-content:space-between;">
            <span style="color:#e0e0e0;font-weight:bold;font-size:11px;">${d.caregiver}</span>
            <span style="color:${col};font-size:11px;font-weight:bold;">${arrow} ${fmtMins(d.diff)}</span>
          </div>
          <div style="color:#888;font-size:10px;margin-top:1px;">${d.member} — ${d.date}</div>
          <div style="display:flex;gap:5px;margin-top:3px;">
            <span style="background:#111;padding:2px 5px;border-radius:3px;font-size:10px;color:#aaa;">S: ${schedH}h${schedM>0?' '+schedM+'m':''}</span>
            <span style="background:#111;padding:2px 5px;border-radius:3px;font-size:10px;color:${col};">A: ${d.actual}</span>
          </div>
        </div>`;
    });
  }

  if (blockedCount === 0 && activeDiffs.length === 0 && duplicateNames.length === 0) {
    html += `<div style="color:#69f0ae;text-align:center;padding:12px 0;">
      <div style="font-size:22px;">✅</div>
      <div style="margin-top:5px;font-weight:bold;">All Clear!</div>
      <div style="color:#aaa;font-size:10px;margin-top:3px;">No blocks, diffs, or duplicate names.</div>
    </div>`;
  }

  // Skip the DOM write entirely if nothing actually changed — the panel gets
  // asked to rebuild often (any grid mutation on this busy page), and writing
  // identical innerHTML every time is what caused the visible flicker.
  if (content.dataset.ccHtmlHash === String(html.length) + ':' + html.slice(0, 64)) return;
  content.dataset.ccHtmlHash = String(html.length) + ':' + html.slice(0, 64);
  content.innerHTML = html;
  // Note: scan button click handled by event delegation on #cc-bf-body
}

async function scanAllBillingPages(mem) {
  // Reset stuck flag
  window._ccBillingScanning = false;

  const scanBtn    = document.getElementById('cc-bf-scan-all');
  const scanStatus = document.getElementById('cc-bf-scan-status');

  window._ccBillingScanning = true;
  if (scanBtn) { scanBtn.textContent = '⏳ Scanning...'; scanBtn.disabled = true; scanBtn.style.background = '#1a3a1a'; scanBtn.style.color = '#69f0ae'; }

  const visitLookup   = {};
  const patDateLookup = {};
  if (mem && mem.visits) {
    mem.visits.forEach(v => {
      if (v.visitId) visitLookup[v.visitId] = v;
      const key = v.patientId + '_' + normDate(v.date);
      if (!patDateLookup[key]) patDateLookup[key] = [];
      patDateLookup[key].push(v);
    });
  }

  let pageNum = 1, totalRows = 0, totalBlocked = 0;
  const allDiffs = [];

  async function waitForPageChange(oldFirstId) {
    await new Promise(resolve => {
      let attempts = 0;
      const check = setInterval(() => {
        attempts++;
        const el  = document.querySelector('.hhax-table-billing-grid input.hidVisitID');
        const nid = el ? el.value : null;
        if ((nid && nid !== oldFirstId) || attempts >= 100) {
          clearInterval(check); resolve();
        }
      }, 200);
    });
    await new Promise(r => setTimeout(r, 500));
  }

  // Go to page 1 if not already there
  const currentPageEl = document.getElementById('ctl00_ContentPlaceHolder1_uxLblCurrent');
  const currentPage   = currentPageEl ? parseInt(currentPageEl.textContent.trim()) : 1;
  if (currentPage > 1) {
    const firstBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnFirst');
    if (firstBtn && firstBtn.style.display !== 'none') {
      const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
      firstBtn.click();
      await waitForPageChange(oldId);
    }
  }

  function scanCurrentPage() {
    const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
    rows.forEach(tr => {
      const tds = tr.querySelectorAll('td');
      if (tds.length < 5) return;
      const dateText = tds[1] ? tds[1].textContent.trim() : '';
      if (!dateText.match(/\d{2}\/\d{2}\/\d{4}/)) return;
      totalRows++;

      const hidVisit    = tr.querySelector('input.hidVisitID');
      const visitId     = hidVisit ? hidVisit.value : null;
      const exactRecord = visitId ? visitLookup[visitId] : null;
      const cgName      = tds[2] ? tds[2].textContent.trim() : '';
      const memberName  = tds[4] ? tds[4].textContent.trim() : '';

      const patientLink = tr.querySelector('a[href*="PatientId="], a[onclick*="PatientId="]');
      if (patientLink) {
        const src  = patientLink.href || patientLink.getAttribute('onclick') || '';
        const pidM = src.match(/PatientId=(\d+)/);
        if (pidM) {
          const patDateKey     = pidM[1] + '_' + normDate(dateText);
          const patDateMatched = patDateLookup[patDateKey];
          const thisId         = exactRecord ? exactRecord.caregiverId : null;
          if (patDateMatched) {
            const unconf = patDateMatched.filter(v => {
              if (v.isConfirmed) return false;
              if (!thisId || !v.caregiverId) return v.caregiverName !== cgName;
              return v.caregiverId !== thisId;
            });
            const thisUnconf = exactRecord && !exactRecord.isConfirmed;
            if (unconf.length > 0 || thisUnconf) totalBlocked++;
          }
        }
      }

      const visitHrsTd   = tds[8];
      const actualHrsStr = visitHrsTd ? visitHrsTd.textContent.trim() : '';
      const actualMins   = parseHrsToMins(actualHrsStr);
      if (exactRecord && actualMins !== null && exactRecord.schedMins) {
        const diffMins = actualMins - exactRecord.schedMins;
        if (Math.abs(diffMins) >= 15) {
          allDiffs.push({ caregiver: cgName, caregiverId: exactRecord.caregiverId, member: memberName, date: dateText, diff: diffMins, actual: actualHrsStr, sched: exactRecord.schedMins });
        }
      }
    });
  }

  while (true) {
    if (scanStatus) scanStatus.textContent = `Scanning page ${pageNum}...`;
    if (scanBtn)    scanBtn.textContent    = `⏳ Page ${pageNum}...`;

    scanCurrentPage();

    const nextBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnNext');
    if (!nextBtn || nextBtn.style.display === 'none') break;
    if (!nextBtn.href || !nextBtn.href.includes('doPostBack')) break;

    const oldFirstId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
    nextBtn.click();
    await waitForPageChange(oldFirstId);

    const newFirstId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
    if (!newFirstId || newFirstId === oldFirstId) break;

    pageNum++;
    if (pageNum > 300) break;
  }

  window._ccBillingScanData = { totalRows, blocked: totalBlocked, diffs: allDiffs, pages: pageNum };
  window._ccBillingScanning = false;

  if (scanStatus) scanStatus.textContent = `Done — ${totalRows} visits across ${pageNum} pages`;
  if (scanBtn) {
    scanBtn.textContent  = '📄 Scan All Billing Pages';
    scanBtn.disabled     = false;
    scanBtn.style.background = '#0f3460';
    scanBtn.style.color  = '#90caf9';
  }

  // Re-run overlay to refresh highlights and floater after scan
  setTimeout(runBatchInvoiceOverlay, 600);

  chrome.storage.local.get(['_cc_billing_memory'], result => {
    updateBillingFloater(result._cc_billing_memory, allDiffs);
  });
}

} // end initExtension
