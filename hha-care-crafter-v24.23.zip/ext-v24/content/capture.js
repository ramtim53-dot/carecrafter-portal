// ── AGENCY CAPTURE — main frame only ─────────────────────────
// Runs ONLY on the main page (not iframes) to capture agency name from footer

if (!window.location.href.includes('hhaexchange.com')) return;

function doCaptureAgency() {
  try {
    let agencyName = '';

    // Footer: "Support Center | Care Crafter Home Care LLC [ID# 103163] | APP2"
    const footerSpan = document.querySelector('.hhax-footer p span');
    if (footerSpan) {
      const txt = footerSpan.innerText || footerSpan.textContent || '';
      const m = txt.match(/\|\s*([^|[]+?)\s*\[ID#/);
      if (m && m[1].trim().length > 2) agencyName = m[1].trim();
      if (!agencyName) {
        agencyName = txt.replace(/Support Center/gi,'').replace(/\[ID#[^\]]*\]/g,'')
          .replace(/\|/g,'').replace(/APP\d+/g,'').replace(/\s+/g,' ').trim();
      }
    }

    if (!agencyName) {
      const el = document.getElementById('ctl00_uxlblCompanyName1');
      if (el) agencyName = el.innerText.trim();
    }

    if (!agencyName) {
      const tbr = document.querySelector('.top-bar-right');
      if (tbr) agencyName = tbr.innerText.replace(/\[ID#[^\]]*\]/g,'').replace(/\|.*$/,'').trim();
    }

    const entM = window.location.href.match(/ENT(\d+)/);
    const entNumber = entM ? 'ENT' + entM[1] : '';

    if (agencyName || entNumber) {
      chrome.storage.local.set({ _hha_agency: agencyName, _hha_ent: entNumber });
      console.log('[CareCrafter] ✅ Agency saved:', agencyName, entNumber);
    }
  } catch(e) { console.log('[CareCrafter] capture error:', e.message); }
}

if (document.readyState === 'complete') doCaptureAgency();
else window.addEventListener('load', doCaptureAgency);
setTimeout(doCaptureAgency, 1000);
setTimeout(doCaptureAgency, 3000);
