const _a = 'https://kgekaljkjgrjbxjxotbg.supabase.co';
const _b = 'sb_publishable_f41PbhJlO6JXYYnUugLvgA_VGmZeQgP';

chrome.alarms.create('_k', { periodInMinutes: 1 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === '_ac') _send(); });

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'checkCode') {
    _check(msg.code, sendResponse);
    return true;
  }
  if (msg.action === 'markCodeUsed') {
    _mark(msg.id, msg.machineId, msg.agencyName || '', msg.durationDays || 30, sendResponse);
    return true;
  }
  if (msg.action === 'scheduleAgencyCapture') {
    chrome.alarms.create('_ac', { delayInMinutes: 5 });
    sendResponse({ ok: true });
    return true;
  }
  if (msg.action === 'runBillingScanInPage') {
    // Inject the entire scan script into the page's MAIN world context
    // This survives ASP.NET postbacks unlike content script async functions
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: 'MAIN',
      func: () => {
        // Prevent duplicate scans
        if (window._ccPageScanRunning) return;
        window._ccPageScanRunning = true;

        async function runPageScan() {
          function normDate(d) { return (d||'').replace(/\D/g,''); }
          function parseHrsToMins(s) {
            if (!s) return null;
            const m = s.trim().match(/^(\d+):(\d+)$/);
            if (!m) return null;
            return parseInt(m[1])*60 + parseInt(m[2]);
          }
          function fmtMins(m) {
            const sign = m>=0?'+':'-'; const abs=Math.abs(m);
            const h=Math.floor(abs/60); const mn=abs%60;
            return h>0?`${sign}${h}h${mn>0?' '+mn+'m':''}`:` ${sign}${mn}m`;
          }

          // Get lookups stored by content script
          const visitLookup   = window._ccScanVisitLookup   || {};
          const patDateLookup = window._ccScanPatDateLookup || {};

          async function waitForPageChange(oldId) {
            await new Promise(resolve => {
              let attempts = 0;
              const check = setInterval(() => {
                attempts++;
                const el = document.querySelector('.hhax-table-billing-grid input.hidVisitID');
                const nid = el ? el.value : null;
                if ((nid && nid !== oldId) || attempts >= 100) {
                  clearInterval(check); resolve();
                }
              }, 200);
            });
            await new Promise(r => setTimeout(r, 500));
          }

          let pageNum = 1, totalRows = 0, totalBlocked = 0;
          const allDiffs = [];
          const seenBlocked = new Set();

          // Go to page 1
          const currentPageEl = document.getElementById('ctl00_ContentPlaceHolder1_uxLblCurrent');
          const currentPage = currentPageEl ? parseInt(currentPageEl.textContent.trim()) : 1;
          if (currentPage > 1) {
            const firstBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnFirst');
            if (firstBtn && firstBtn.style.display !== 'none') {
              const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
              firstBtn.click();
              await waitForPageChange(oldId);
            }
          }

          while (true) {
            const statusEl = document.getElementById('cc-bf-scan-status');
            const btnEl    = document.getElementById('cc-bf-scan-all');
            if (statusEl) statusEl.textContent = `Scanning page ${pageNum}...`;
            if (btnEl)    btnEl.textContent    = `⏳ Page ${pageNum}...`;

            // Scan and process current page
            const rows = Array.from(document.querySelectorAll('.hhax-table-billing-grid tbody tr'));
            rows.forEach(tr => {
              const tds = tr.querySelectorAll('td');
              if (tds.length < 5) return;
              const dateText = tds[1]?.textContent.trim();
              if (!dateText?.match(/\d{2}\/\d{2}\/\d{4}/)) return;
              totalRows++;

              const hidVisit    = tr.querySelector('input.hidVisitID');
              const visitId     = hidVisit?.value;
              const cgName      = tds[2]?.textContent.trim();
              const memberName  = tds[4]?.textContent.trim();
              const visitHrsStr = tds[8]?.textContent.trim();
              const patLink     = tr.querySelector('a[href*="PatientId="]');
              const pidM        = (patLink?.href||'').match(/PatientId=(\d+)/);
              const patientId   = pidM ? pidM[1] : null;

              const exactRecord    = visitId ? visitLookup[visitId] : null;
              const patDateKey     = patientId + '_' + normDate(dateText);
              const patDateMatched = patDateLookup[patDateKey];
              const thisId         = exactRecord ? exactRecord.caregiverId : null;

              // Check blocked
              if (patDateMatched && visitId && !seenBlocked.has(visitId)) {
                const unconf = patDateMatched.filter(v => {
                  if (v.isConfirmed) return false;
                  if (!thisId || !v.caregiverId) return v.caregiverName !== cgName;
                  return v.caregiverId !== thisId;
                });
                const thisUnconf = exactRecord && !exactRecord.isConfirmed;
                if (unconf.length > 0 || thisUnconf) {
                  seenBlocked.add(visitId);
                  totalBlocked++;
                  // Highlight row red
                  tr.style.setProperty('background','rgba(255,68,68,0.13)','important');
                  tr.style.setProperty('outline','2px solid #ff4444','important');
                  const warn = document.createElement('span');
                  warn.textContent = ' 🚫';
                  warn.style.cssText = 'cursor:help;font-size:13px;';
                  const names = unconf.map(v=>v.caregiverName).filter(Boolean).join(', ') || cgName;
                  warn.title = thisUnconf ? `This visit is unconfirmed` : `Cannot bill — ${names} has unconfirmed visit`;
                  tds[1]?.appendChild(warn);
                  const chk = tr.querySelector('input[type="checkbox"]');
                  if (chk) { chk.disabled = true; }
                }
              }

              // Check diff
              const actualMins = parseHrsToMins(visitHrsStr);
              if (exactRecord && actualMins !== null && exactRecord.schedMins) {
                const diffMins = actualMins - exactRecord.schedMins;
                if (Math.abs(diffMins) >= 15) {
                  allDiffs.push({
                    caregiver:   cgName,
                    caregiverId: exactRecord.caregiverId,
                    member:      memberName,
                    date:        dateText,
                    diff:        diffMins,
                    actual:      visitHrsStr,
                    sched:       exactRecord.schedMins
                  });
                }
                // Show diff in row
                const visitHrsTd = tds[8];
                if (visitHrsTd && !visitHrsTd.querySelector('.cc-inline-diff')) {
                  const badge = document.createElement('span');
                  badge.className = 'cc-inline-diff';
                  badge.style.cssText = `font-size:10px;font-weight:bold;margin-left:4px;color:${diffMins>0?'#ff8a80':'#ffd740'};`;
                  badge.textContent = Math.abs(diffMins) < 5 ? '' : (diffMins>0?'↑':'↓')+Math.abs(diffMins)+'m';
                  visitHrsTd.appendChild(badge);
                }
              }
            });

            // Next page
            const nextBtn = document.getElementById('ctl00_ContentPlaceHolder1_uxBtnNext');
            if (!nextBtn || nextBtn.style.display === 'none') break;
            if (!nextBtn.href?.includes('doPostBack')) break;

            const oldId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
            nextBtn.click();
            await waitForPageChange(oldId);

            const newId = document.querySelector('.hhax-table-billing-grid input.hidVisitID')?.value;
            if (!newId || newId === oldId) break;

            pageNum++;
            if (pageNum > 300) break;
          }

          // Store results for content script
          window._ccPageScanResults = { totalRows, pages: pageNum, blocked: totalBlocked, diffs: allDiffs, done: true };
          window._ccPageScanRunning = false;

          const statusEl = document.getElementById('cc-bf-scan-status');
          const btnEl    = document.getElementById('cc-bf-scan-all');
          if (statusEl) statusEl.textContent = `Done — ${totalRows} visits across ${pageNum} pages · ${totalBlocked} blocked · ${allDiffs.length} diffs`;
          if (btnEl)    { btnEl.textContent = '📄 Scan All Billing Pages'; btnEl.disabled = false; btnEl.style.background = '#0f3460'; btnEl.style.color = '#90caf9'; }
        }

        runPageScan().catch(e => { window._ccPageScanRunning = false; console.error('[CCScan]', e); });
      }
    }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.action === 'doPostBack') {
    // Execute __doPostBack in page context via scripting API
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: 'MAIN',
      func: (target) => { __doPostBack(target, ''); },
      args: [msg.target]
    }, () => sendResponse({ ok: true }));
    return true;
  }
});

function _check(code, cb) {
  fetch(_a + '/rest/v1/activation_codes?code=eq.' + encodeURIComponent(code) + '&select=id,code,used,duration_days', {
    headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b, 'Content-Type': 'application/json' }
  })
  .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
  .then(d => {
    if (!Array.isArray(d) || !d.length) cb({ ok: false, msg: 'Invalid activation code.' });
    else if (d[0].used) cb({ ok: false, msg: 'This code has already been used.' });
    else cb({ ok: true, id: d[0].id, durationDays: d[0].duration_days || 30 });
  })
  .catch(e => cb({ ok: false, msg: 'Failed: ' + e.message }));
}

function _mark(id, machineId, agencyName, durationDays, cb) {
  fetch(_a + '/rest/v1/activation_codes?id=eq.' + id, {
    method: 'PATCH',
    headers: {
      'apikey': _b, 'Authorization': 'Bearer ' + _b,
      'Content-Type': 'application/json', 'Prefer': 'return=minimal'
    },
    body: JSON.stringify({
      used: true,
      used_at: new Date().toISOString(),
      machine_id: machineId,
      agency_name: agencyName || null,
      duration_days: durationDays || 30
    })
  })
  .then(r => cb({ ok: r.ok }))
  .catch(e => cb({ ok: false, msg: e.message }));
}

async function _send() {
  try {
    const s = await new Promise(r => chrome.storage.local.get(['_hha_agency','_hha_ent','_xc','_xid'], r));
    if (!s._xc) return;

    // Look up record by code string
    const lr = await fetch(_a + '/rest/v1/activation_codes?code=eq.' + encodeURIComponent(s._xc) + '&select=id', {
      headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b }
    });
    const recs = await lr.json();
    if (!recs || !recs.length) return;

    // Only update ent_number since agency_name is already set at activation
    const body = {
      ent_number: s._hha_ent || null,
      machine_id: s._xid || null,
    };

    await fetch(_a + '/rest/v1/activation_codes?id=eq.' + recs[0].id, {
      method: 'PATCH',
      headers: { 'apikey': _b, 'Authorization': 'Bearer ' + _b, 'Content-Type': 'application/json', 'Prefer': 'return=minimal' },
      body: JSON.stringify(body)
    });
  } catch(e) {}
}
