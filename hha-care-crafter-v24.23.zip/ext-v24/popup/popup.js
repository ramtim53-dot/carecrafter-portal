const _dur30 = 30*24*60*60*1000;
const _dur1  = 1*24*60*60*1000;

// ── SUPABASE VIA BACKGROUND ──────────────────────────────────
async function _chk(code) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ action:'checkCode', code }, r => {
      if (chrome.runtime.lastError) resolve({ ok:false, msg:'Extension error' });
      else resolve(r);
    });
  });
}

async function _mid() {
  return new Promise(r => {
    chrome.storage.local.get('_xid', d => {
      if (d._xid) return r(d._xid);
      const id = '_' + Date.now().toString(36) + Math.random().toString(36).substr(2,8);
      chrome.storage.local.set({ _xid: id }, () => r(id));
    });
  });
}

async function _activate(code, agencyName) {
  const clean = code.trim().toUpperCase();
  // Accept both CC- (30 day) and CD- (1 day)
  if (!/^C[CD]-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(clean))
    return { ok:false, msg:'Invalid format. Use CC-XXXX-XXXX-XXXX or CD-XXXX-XXXX-XXXX' };

  const chk = await _chk(clean);
  if (!chk.ok) return chk;

  // Determine duration from prefix
  const isOneDay = clean.startsWith('CD-');
  const dur = isOneDay ? _dur1 : _dur30;
  const durationDays = isOneDay ? 1 : 30;
  const machineId = await _mid();

  // Mark code as used in Supabase
  await new Promise(resolve => {
    chrome.runtime.sendMessage({
      action: 'markCodeUsed',
      id: chk.id,
      machineId,
      agencyName: agencyName || '',
      durationDays
    }, resolve);
  });

  // Schedule agency data send after 5 min
  chrome.runtime.sendMessage({ action: 'scheduleAgencyCapture', codeId: chk.id });

  const exp = Date.now() + dur;
  await new Promise(r => chrome.storage.local.set({
    _xa: true, _xe: exp, _xc: clean,
    _hha_agency: agencyName || '',
    _dur_days: durationDays
  }, r));

  return { ok:true, expiry:exp, durationDays };
}

// ── INPUT FORMATTER ──────────────────────────────────────────
function _fmt(input) {
  input.addEventListener('input', () => {
    let v = input.value.toUpperCase().replace(/[^A-Z0-9]/g,'');
    let out = '';
    // Handle both CC and CD prefixes
    if (v.length >= 2) {
      const prefix = v.substring(0,2);
      if (prefix === 'CC' || prefix === 'CD') out = prefix;
      else out = v.substring(0,2);
    }
    if (v.length > 2) out += '-' + v.substring(2,6);
    if (v.length > 6) out += '-' + v.substring(6,10);
    if (v.length > 10) out += '-' + v.substring(10,14);
    input.value = out;
  });
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter') {
      const btn = input.id === 'codeInput'
        ? document.getElementById('activateBtn')
        : document.getElementById('renewBtn');
      btn && btn.click();
    }
  });
}

// ── TIMER HELPERS ────────────────────────────────────────────
function _remaining(expiry) {
  const ms = expiry - Date.now();
  if (ms <= 0) return null;
  return { ms, d:Math.floor(ms/86400000), h:Math.floor((ms%86400000)/3600000), m:Math.floor((ms%3600000)/60000), s:Math.floor((ms%60000)/1000) };
}

function _fmtCountdown(expiry) {
  const t = _remaining(expiry);
  if (!t) return null;
  if (t.d > 1)  return `${t.d}d ${t.h}h remaining`;
  if (t.d === 1) return `1d ${t.h}h ${t.m}m remaining`;
  if (t.h > 0)  return `${t.h}h ${t.m}m ${t.s}s remaining`;
  return `${t.m}m ${t.s}s remaining`;
}

function _expiredSince(expiry) {
  const ms = Date.now()-expiry;
  const d=Math.floor(ms/86400000), h=Math.floor((ms%86400000)/3600000);
  return d>0 ? `Expired ${d}d ${h}h ago` : `Expired ${h}h ago`;
}

async function _state() {
  return new Promise(r => {
    chrome.storage.local.get(['_xa','_xe','_dur_days'], d =>
      r({ active:d._xa||false, expiry:d._xe||null, durDays:d._dur_days||30 }));
  });
}

// ── INIT ─────────────────────────────────────────────────────
async function init() {
  const s = await _state();
  if (!s.active||!s.expiry) { showActivation(); return; }
  if (Date.now()>s.expiry) {
    await new Promise(r => chrome.storage.local.set({_xa:false},r));
    showExpired(s.expiry); return;
  }
  showMain(s.expiry, s.durDays);
}

// ── ACTIVATION ───────────────────────────────────────────────
function showActivation() {
  document.getElementById('activationScreen').style.display='block';
  document.getElementById('expiredScreen').style.display='none';
  document.getElementById('mainApp').style.display='none';
  const inp=document.getElementById('codeInput');
  const agencyInp=document.getElementById('agencyInput');
  const btn=document.getElementById('activateBtn');
  const err=document.getElementById('actError');
  _fmt(inp); setTimeout(()=>inp.focus(),100);
  btn.addEventListener('click', async ()=>{
    err.textContent='';
    if (!inp.value.trim()){err.textContent='Please enter your activation code.';return;}
    btn.disabled=true; btn.textContent='CHECKING...';
    const agencyName = agencyInp ? agencyInp.value.trim() : '';
    const res=await _activate(inp.value, agencyName);
    if (res.ok){
      btn.textContent='✓ ACTIVATED!';
      setTimeout(()=>showMain(res.expiry, res.durationDays),700);
    } else {
      err.textContent=res.msg;
      btn.disabled=false; btn.textContent='ACTIVATE';
      inp.focus(); inp.select();
    }
  });
}

// ── EXPIRED ──────────────────────────────────────────────────
function showExpired(oldExpiry) {
  document.getElementById('activationScreen').style.display='none';
  document.getElementById('expiredScreen').style.display='block';
  document.getElementById('mainApp').style.display='none';
  const sinceEl=document.getElementById('expiredSince');
  if (sinceEl&&oldExpiry) sinceEl.textContent=_expiredSince(oldExpiry);
  const inp=document.getElementById('renewInput');
  const agencyInp=document.getElementById('renewAgencyInput');
  const btn=document.getElementById('renewBtn');
  const err=document.getElementById('renewError');
  _fmt(inp); setTimeout(()=>inp.focus(),100);
  btn.addEventListener('click', async ()=>{
    err.textContent='';
    if (!inp.value.trim()){err.textContent='Please enter your new code.';return;}
    btn.disabled=true; btn.textContent='CHECKING...';
    const agencyName = agencyInp ? agencyInp.value.trim() : '';
    const res=await _activate(inp.value, agencyName);
    if (res.ok){
      btn.textContent='✓ REACTIVATED!';
      setTimeout(()=>showMain(res.expiry, res.durationDays),700);
    } else {
      err.textContent=res.msg;
      btn.disabled=false; btn.textContent='REACTIVATE';
      inp.focus(); inp.select();
    }
  });
}

// ── MAIN APP ─────────────────────────────────────────────────
function showMain(expiry, durDays) {
  document.getElementById('activationScreen').style.display='none';
  document.getElementById('expiredScreen').style.display='none';
  document.getElementById('mainApp').style.display='block';

  const timerEl=document.getElementById('licenseTimer');
  const footerEl=document.getElementById('footerExpiry');

  function updateTimer() {
    const t=_remaining(expiry);
    if (!t){chrome.storage.local.set({_xa:false},()=>showExpired(expiry));return;}
    const txt=_fmtCountdown(expiry);
    if (timerEl){
      timerEl.textContent=txt;
      timerEl.className='license-timer'+(t.d<=0?' danger':t.d<=5?' warn':'');
    }
    if (footerEl){
      footerEl.textContent=(durDays===1?'1-Day':'30-Day')+' • '+t.d+'d '+t.h+'h left';
      footerEl.style.color=t.d<=0?'var(--danger)':t.d<=5?'var(--warn)':'var(--success)';
    }
  }
  updateTimer();
  const tick=setInterval(updateTimer,1000);
  window.addEventListener('unload',()=>clearInterval(tick));
  initApp();
}

function initApp() {
  document.querySelectorAll('.tab').forEach(tab=>{
    tab.addEventListener('click',()=>{
      document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c=>c.style.display='none');
      tab.classList.add('active');
      const el=document.getElementById('tab-'+tab.dataset.tab);
      if (el) el.style.display='block';
    });
  });

  // Rate calculator
  const rateCode=document.getElementById('rateCode');
  const customGrp=document.getElementById('customRateGroup');
  rateCode.addEventListener('change',()=>{ customGrp.style.display=rateCode.value?'none':'block'; });
  document.getElementById('calcBtn').addEventListener('click',()=>{
    const hrs=parseFloat(document.getElementById('rateHours').value)||0;
    const rate=parseFloat(rateCode.value||document.getElementById('customRate').value)||0;
    if (!hrs||!rate) return;
    const total=hrs*rate;
    document.getElementById('resultAmount').textContent='$'+total.toFixed(2);
    document.getElementById('resultDetail').textContent=`${hrs}h × $${rate.toFixed(2)}/hr  |  Bi-weekly: $${(total*2).toFixed(2)}`;
    document.getElementById('calcResult').style.display='block';
  });

  // Distance checker
  const docInput=document.getElementById('docFileInput');
  const docBar=document.getElementById('docFileBar');
  const docName=document.getElementById('docFileName');
  const docOpen=document.getElementById('docOpenFullBtn');
  const docTab=document.getElementById('docNewTabBtn');
  const docMini=document.getElementById('docMiniResults');
  let storedFile=null;

  docInput.addEventListener('change',e=>{ if(e.target.files[0]) setDoc(e.target.files[0]); });
  function setDoc(f){
    storedFile=f; docName.textContent=f.name;
    docBar.style.display='flex'; docOpen.disabled=false;
    docMini.innerHTML='<div class="scan-item info"><span class="scan-icon">📄</span><span class="scan-text">File loaded — click Open Full Checker</span></div>';
  }
  docTab.addEventListener('click',()=>{
    alert('📊 Use the standalone file!\n\nOpen "distance-overlap-checker_2.html" directly in Chrome by double-clicking it.');
  });
  docOpen.addEventListener('click',()=>{
    if (!storedFile) return;
    docOpen.disabled=true; docOpen.textContent='⏳ Opening...';
    const reader=new FileReader();
    reader.onload=e=>{
      const bytes=new Uint8Array(e.target.result);
      let bin=''; for(let i=0;i<bytes.byteLength;i++) bin+=String.fromCharCode(bytes[i]);
      chrome.storage.local.set({_df:{name:storedFile.name,data:btoa(bin)}},()=>{
        chrome.tabs.create({url:chrome.runtime.getURL('distance-checker.html?fs=1')});
        docOpen.disabled=false; docOpen.textContent='🔍 Open Full Checker';
      });
    };
    reader.readAsArrayBuffer(storedFile);
  });

  // Scan
  document.getElementById('scanBtn').addEventListener('click',()=>{
    chrome.tabs.query({active:true,currentWindow:true},tabs=>{
      if (!tabs[0]) return;
      chrome.tabs.sendMessage(tabs[0].id,{action:'scanPage'},response=>{
        const el=document.getElementById('scanResults');
        if (chrome.runtime.lastError||!response){
          el.innerHTML='<div class="scan-item danger"><span class="scan-icon">❌</span><span class="scan-text">Navigate to HHAeXchange first.</span></div>';
          return;
        }
        const {overlaps=[],hourDiffs=[],totalVisits=0}=response.results||{};
        let html=`<div class="scan-item info"><span class="scan-icon">ℹ</span><span class="scan-text">Scanned ${totalVisits} rows</span></div>`;
        if (!overlaps.length&&!hourDiffs.length)
          html+='<div class="scan-item success"><span class="scan-icon">✓</span><span class="scan-text">No EVV issues detected</span></div>';
        overlaps.forEach(o=>{ html+=`<div class="scan-item danger"><span class="scan-icon">⚠</span><span class="scan-text"><b>${o.caregiver}</b> ${o.date}: ${o.client1} vs ${o.client2} (${Math.round(o.overlapMins)}min)</span></div>`; });
        hourDiffs.forEach(d=>{ html+=`<div class="scan-item danger"><span class="scan-icon">⏱</span><span class="scan-text"><b>${d.caregiver}</b> ${d.date}: ${d.diffMins}min diff</span></div>`; });
        el.innerHTML=html;
      });
    });
  });

  // AI
  document.getElementById('aiAskBtn').addEventListener('click', async ()=>{
    const prompt=document.getElementById('aiPrompt').value.trim();
    if (!prompt) return;
    const out=document.getElementById('aiOutput');
    out.textContent='Thinking...'; out.classList.add('visible');
    try {
      const res=await fetch('https://api.anthropic.com/v1/messages',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({model:'claude-sonnet-4-20250514',max_tokens:500,
          system:'You are a PA home care compliance assistant. Answer concisely.',
          messages:[{role:'user',content:prompt}]})
      });
      const data=await res.json();
      out.textContent=data.content?.[0]?.text||'No response.';
    } catch(e){ out.textContent='Error: '+e.message; }
  });
}

init();
